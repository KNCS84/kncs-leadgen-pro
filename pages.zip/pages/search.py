# pages/search.py
# KNCS LeadGen Pro — v9.6
# Lead acquisition, scrape risk monitoring, job monitor,
# source selector, and enrichment center.

from __future__ import annotations

from datetime import datetime
from textwrap import dedent
import time

import pandas as pd
import streamlit as st

# ─────────────────────────────────────────────────────────
# Safe imports: database
# ─────────────────────────────────────────────────────────
try:
    from database import (
        get_leads_missing_emails,
        get_leads_missing_websites,
        get_connection,
    )
except Exception:
    get_connection = None

    def get_leads_missing_emails(limit=100):
        return []

    def get_leads_missing_websites(limit=100):
        return []


# ─────────────────────────────────────────────────────────
# Safe imports: job manager
# ─────────────────────────────────────────────────────────
try:
    from engine.job_manager import (
        start_scrape_job,
        get_job_status_summary,
        get_recent_jobs,
        get_active_job_id,
        any_job_running,
        stop_job,
        STATUS_DONE,
        STATUS_FAILED,
        STATUS_RUNNING,
        STATUS_STOPPED,
    )
except Exception:
    def start_scrape_job(*args, **kwargs):
        return None

    def get_job_status_summary(*args, **kwargs):
        return {
            "found": False,
            "status": "unknown",
            "progress": 0,
            "leads": 0,
            "message": "Job unavailable",
        }

    def get_recent_jobs(limit=12):
        return []

    def get_active_job_id():
        return None

    def any_job_running():
        return False

    def stop_job(*args, **kwargs):
        return False

    STATUS_DONE = "done"
    STATUS_FAILED = "failed"
    STATUS_RUNNING = "running"
    STATUS_STOPPED = "stopped"


# ─────────────────────────────────────────────────────────
# Safe imports: enricher
# ─────────────────────────────────────────────────────────
try:
    from engine.enricher import reenrich_leads_missing_emails
except Exception:
    def reenrich_leads_missing_emails(limit=20, progress_callback=None):
        return {"emails_found": 0, "processed": 0, "updated": 0}


# ─────────────────────────────────────────────────────────
# Safe imports: scrape guard
# ─────────────────────────────────────────────────────────
try:
    from engine.scrape_guard import (
        get_risk_summary,
        get_risk_level,
        RISK_LEVELS,
    )
except Exception:
    RISK_LEVELS = {
        "safe": {
            "label": "SAFE",
            "color": "#10b981",
            "message": "No significant risk detected.",
        },
        "low": {
            "label": "LOW",
            "color": "#10b981",
            "message": "Low risk.",
        },
        "warning": {
            "label": "WARNING",
            "color": "#f59e0b",
            "message": "Use caution.",
        },
        "caution": {
            "label": "CAUTION",
            "color": "#fb923c",
            "message": "Higher block risk.",
        },
        "stop": {
            "label": "STOP",
            "color": "#ef4444",
            "message": "Do not scrape now.",
        },
        "blocked": {
            "label": "BLOCKED",
            "color": "#ef4444",
            "message": "Blocked by guard rules.",
        },
    }

    def get_risk_summary():
        return {
            "overall_risk": "safe",
            "overall_message": "Risk monitor unavailable.",
            "recommendations": [],
            "per_source": {},
        }

    def get_risk_level(source: str):
        return "safe"


# ─────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────
NOW = datetime.now()

LOCATION_PRESETS = {
    "Nigeria": [
        "Lagos", "Abuja", "Port Harcourt",
        "Benin City", "Enugu", "Owerri",
    ],
    "United Kingdom": [
        "London", "Manchester", "Liverpool",
        "Leeds", "Birmingham", "Glasgow",
    ],
    "United States": [
        "Chicago", "Houston", "Dallas",
        "Atlanta", "Miami", "New York",
    ],
    "Canada": ["Toronto", "Vancouver", "Montreal"],
    "Ghana": ["Accra", "Kumasi"],
    "South Africa": ["Johannesburg", "Cape Town"],
    "Kenya": ["Nairobi", "Mombasa"],
    "Australia": ["Sydney", "Melbourne", "Brisbane"],
    "UAE": ["Dubai", "Abu Dhabi"],
    "Custom": [],
}

BUSINESS_CATEGORIES = [
    "Restaurant", "Dental Clinic", "Estate Agent",
    "Construction", "Hair Salon", "Mortgage Broker",
    "Car Garage", "Law Firm", "Insurance",
    "Financial Advisor", "Hotel", "Pharmacy",
    "Gym", "School", "Event Center",
    "Custom Keyword",
]

MAX_RESULTS_OPTIONS = {
    "20 Leads  (Quick)": 20,
    "50 Leads  (Standard)": 50,
    "100 Leads (Deep)": 100,
    "200 Leads (Bulk)": 200,
}

SOURCE_OPTIONS = {
    "companies_house": {
        "label": "Companies House UK",
        "icon": "🇬🇧",
        "color": "#3b82f6",
        "desc": "Official UK registry. Free API. Zero block risk.",
    },
    "google_maps": {
        "label": "Google Maps",
        "icon": "🗺️",
        "color": "#5b8cff",
        "desc": "Strong phones, ratings, and local businesses worldwide.",
    },
    "b2bhint": {
        "label": "B2BHint",
        "icon": "🏢",
        "color": "#8b5cf6",
        "desc": "Corporate directory for company names and listings.",
    },
    "yelp": {
        "label": "Yelp",
        "icon": "⭐",
        "color": "#ef4444",
        "desc": "Best for UK and US service businesses.",
    },
    "yellowpages": {
        "label": "YellowPages",
        "icon": "📒",
        "color": "#10b981",
        "desc": "Good phone coverage for local businesses.",
    },
}

SOURCE_LAYOUT = [
    ["companies_house", "google_maps", "b2bhint"],
    ["yelp", "yellowpages"],
]


# ─────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────
def _truncate_text(value, max_len: int = 72) -> str:
    text = str(value or "").strip()
    if len(text) <= max_len:
        return text
    return text[: max_len - 1].rstrip() + "…"


def _safe_int(value, default: int = 0) -> int:
    try:
        if value is None:
            return default
        return int(value)
    except Exception:
        return default


def _fmt_money(value):
    try:
        v = float(value or 0)
        if v.is_integer():
            return f"₦{int(v):,}"
        return f"₦{v:,.2f}"
    except Exception:
        return "₦0"


def _safe_risk_meta(level: str) -> dict:
    if level in RISK_LEVELS:
        return RISK_LEVELS[level]
    return {
        "label": str(level).upper() if level else "UNKNOWN",
        "color": "#64748b",
        "message": "Unknown risk state.",
    }


def _safe_call(fn, default):
    try:
        return fn()
    except Exception as e:
        print(f"⚠️ dashboard helper error in {getattr(fn, '__name__', 'call')}: {e}")
        return default


def _short_timestamp(value) -> str:
    text = str(value or "").strip()
    if not text:
        return "N/A"
    return text[:16]


def _get_top_cities(limit: int = 3):
    if get_connection is None:
        return []

    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT place, COUNT(*) AS total
            FROM (
                SELECT
                    CASE
                        WHEN city IS NOT NULL AND TRIM(city) != '' THEN city
                        WHEN location IS NOT NULL AND TRIM(location) != '' THEN location
                        ELSE 'Unknown'
                    END AS place
                FROM leads
            )
            GROUP BY place
            ORDER BY total DESC, place ASC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(row) for row in cursor.fetchall()]
    except Exception as e:
        print(f"⚠️ top cities error: {e}")
        return []
    finally:
        try:
            if conn:
                conn.close()
        except Exception:
            pass


def section_header(title, subtitle=""):
    sub_html = (
        f'<div style="margin-top:6px;color:#94a3b8;font-size:13px;">{subtitle}</div>'
        if subtitle else ""
    )
    st.markdown(
        dedent(f"""
<div style="margin-bottom:16px;">
    <div style="font-size:22px;font-weight:800;color:white;letter-spacing:-0.5px;">
        {title}
    </div>
    {sub_html}
</div>
"""),
        unsafe_allow_html=True,
    )


def card_start():
    st.markdown('<div class="premium-card">', unsafe_allow_html=True)


def card_end():
    st.markdown('</div>', unsafe_allow_html=True)


def _render_metric_card(label: str, value: str, subtitle: str, accent: str, icon: str):
    st.markdown(
        f"""
        <div style="
            background: linear-gradient(180deg, rgba(20,26,39,0.96), rgba(14,19,31,0.96));
            border: 1px solid rgba(255,255,255,0.08);
            border-top: 3px solid {accent};
            border-radius: 18px;
            padding: 14px 14px 12px 14px;
            min-height: 108px;
            box-shadow: 0 12px 26px rgba(0,0,0,0.16);
        ">
            <div style="font-size:22px;margin-bottom:8px;">{icon}</div>
            <div style="color:#8b97ad;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;margin-bottom:6px;">
                {label}
            </div>
            <div style="color:#f4f7fb;font-size:30px;font-weight:800;line-height:1.0;margin-bottom:4px;">
                {value}
            </div>
            <div style="color:#93a0b7;font-size:12px;">
                {subtitle}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────
# HERO
# ─────────────────────────────────────────────────────────
def render_hero():
    st.markdown(
        dedent(f"""
<div style="margin-bottom:28px;">
    <div style="font-size:40px;font-weight:900;color:white;line-height:1;letter-spacing:-2px;">
        Lead Acquisition Engine
    </div>
    <div style="margin-top:12px;max-width:760px;color:#94a3b8;font-size:15px;line-height:1.8;">
        Launch intelligent lead discovery campaigns across Companies House, Google Maps, Yelp,
        B2BHint, and YellowPages. Scrape, enrich, and qualify high-intent opportunities.
        <br/>
        <span style="color:#cbd5e1;">Updated {NOW.strftime('%A, %d %B %Y, %H:%M:%S')}</span>
    </div>
</div>
"""),
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────
# SCRAPE RISK INDICATOR
# ─────────────────────────────────────────────────────────
def render_scrape_risk_card():
    """
    Display overall scrape risk status.
    """
    section_header(
        "Scrape Risk Monitor",
        "Real-time block detection and request tracking",
    )

    try:
        summary = get_risk_summary()
        overall_risk = summary.get("overall_risk", "safe")
        risk_def = _safe_risk_meta(overall_risk)
        label = risk_def.get("label", "SAFE")
        color = risk_def.get("color", "#10b981")
        message = summary.get("overall_message", "")
        recommendations = summary.get("recommendations", [])
        emoji = {
            "safe": "🟢",
            "low": "🟢",
            "warning": "🟡",
            "caution": "🟠",
            "stop": "⛔",
            "blocked": "⛔",
        }.get(overall_risk, "🛡️")

        st.markdown(
            dedent(f"""
<div style="
    background: linear-gradient(135deg, rgba(17,24,39,0.95), rgba(24,33,52,0.95));
    border: 1px solid rgba(255,255,255,0.07);
    border-left: 4px solid {color};
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 20px;
">
    <div style="display:flex;align-items:center;gap:16px;margin-bottom:8px;">
        <div style="font-size:40px;">{emoji}</div>
        <div>
            <div style="color:white;font-size:22px;font-weight:800;">{label}</div>
            <div style="color:#94a3b8;font-size:14px;margin-top:4px;">{message}</div>
        </div>
    </div>
</div>
"""),
            unsafe_allow_html=True,
        )

        for rec in recommendations:
            rec_text = str(rec)
            if any(x in rec_text for x in ["⛔", "🛑", "BLOCKED"]):
                st.error(rec_text)
            elif "🔴" in rec_text:
                st.error(rec_text)
            elif "🟠" in rec_text:
                st.warning(rec_text)
            elif "🟡" in rec_text:
                st.info(rec_text)
            else:
                st.success(rec_text)

        st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)

        with st.expander("📊 Source-by-Source Breakdown", expanded=False):
            per_source = summary.get("per_source", {})

            if not per_source:
                st.info("No scraping activity today yet.")
            else:
                for source, data in per_source.items():
                    s_level = data.get("level", "safe")
                    s_meta = _safe_risk_meta(s_level)
                    s_label = s_meta.get("label", "SAFE")
                    s_color = s_meta.get("color", "#10b981")
                    count = data.get("count", 0)
                    remaining = data.get("remaining", 0)
                    consecutive = data.get("consecutive_failures", 0)
                    blocks = data.get("recent_blocks", 0)

                    source_name = SOURCE_OPTIONS.get(source, {}).get("label", source)

                    extra = ""
                    if consecutive > 0:
                        extra += (
                            f'<div style="color:#ef4444;font-size:12px;margin-top:4px;">'
                            f'⚠️ {consecutive} consecutive failures</div>'
                        )
                    if blocks > 0:
                        extra += (
                            f'<div style="color:#dc2626;font-size:12px;margin-top:4px;">'
                            f'⛔ {blocks} block(s) detected</div>'
                        )

                    st.markdown(
                        dedent(f"""
<div style="
    background: rgba(255,255,255,0.02);
    border: 1px solid rgba(255,255,255,0.05);
    border-left: 3px solid {s_color};
    border-radius: 12px;
    padding: 16px;
    margin-bottom: 10px;
">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:14px;">
        <div>
            <div style="color:white;font-size:15px;font-weight:700;">{source_name}</div>
            <div style="color:#94a3b8;font-size:13px;margin-top:4px;">
                {count} requests today &bull; {remaining} remaining
            </div>
            {extra}
        </div>
        <div style="color:{s_color};font-size:16px;font-weight:800;">{s_label}</div>
    </div>
</div>
"""),
                        unsafe_allow_html=True,
                    )

    except Exception as e:
        st.error(f"Risk monitor error: {e}")


# ─────────────────────────────────────────────────────────
# RECENT CAMPAIGNS
# ─────────────────────────────────────────────────────────
def render_recent_campaigns():
    """
    Show recent jobs as niche + location cards.
    """
    section_header(
        "Recent Campaigns",
        "Your latest lead discovery operations",
    )

    jobs = get_recent_jobs(limit=12)

    if not jobs:
        st.info("No campaigns yet. Launch your first search above.")
        return

    campaigns = {}

    for job in jobs:
        keyword = job.get("keyword", "Unknown")
        location = job.get("location", "Unknown")
        key = f"{keyword} — {location}"

        if key not in campaigns:
            campaigns[key] = {
                "keyword": keyword,
                "location": location,
                "jobs": [],
                "total_leads": 0,
                "last_run": job.get("started_at", ""),
            }

        campaigns[key]["jobs"].append(job)
        campaigns[key]["total_leads"] += _safe_int(job.get("leads_found", 0))

    cols = st.columns(2)

    for idx, (name, data) in enumerate(list(campaigns.items())[:8]):
        col_idx = idx % 2
        total = data["total_leads"]
        job_count = len(data["jobs"])
        last_run_short = _short_timestamp(data["last_run"])
        latest_job = data["jobs"][0]
        status = str(latest_job.get("status", "unknown")).lower()
        source = latest_job.get("source", "")
        source_label = SOURCE_OPTIONS.get(source, {}).get("label", source)
        source_icon = SOURCE_OPTIONS.get(source, {}).get("icon", "🔎")

        status_colors = {
            "done": "#10b981",
            "running": "#5b8cff",
            "failed": "#ef4444",
            "stopped": "#f59e0b",
            "pending": "#64748b",
        }
        status_color = status_colors.get(status, "#64748b")

        with cols[col_idx]:
            st.markdown(
                dedent(f"""
<div style="
    background: linear-gradient(135deg, rgba(17,24,39,0.95), rgba(24,33,52,0.95));
    border: 1px solid rgba(255,255,255,0.07);
    border-top: 3px solid {status_color};
    border-radius: 14px;
    padding: 18px;
    margin-bottom: 16px;
">
    <div style="color:white;font-size:16px;font-weight:800;margin-bottom:4px;">
        {name}
    </div>
    <div style="color:#64748b;font-size:12px;margin-bottom:12px;">
        via {source_icon} {source_label}
    </div>
    <div style="display:flex;gap:16px;">
        <div style="flex:1;">
            <div style="color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">
                Leads
            </div>
            <div style="color:white;font-size:22px;font-weight:800;">{total}</div>
        </div>
        <div style="flex:1;">
            <div style="color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">
                Runs
            </div>
            <div style="color:white;font-size:22px;font-weight:800;">{job_count}</div>
        </div>
        <div style="flex:1;">
            <div style="color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">
                Status
            </div>
            <div style="color:{status_color};font-size:14px;font-weight:800;">
                {status.upper()}
            </div>
        </div>
    </div>
    <div style="margin-top:12px;padding-top:12px;border-top:1px solid rgba(255,255,255,0.05);">
        <div style="color:#64748b;font-size:12px;">
            Last run: {last_run_short}
        </div>
    </div>
</div>
"""),
                unsafe_allow_html=True,
            )


# ─────────────────────────────────────────────────────────
# SOURCE SELECTOR — 2-ROW LAYOUT
# ─────────────────────────────────────────────────────────
def render_source_selector():
    section_header(
        "Lead Sources",
        "Choose your acquisition channel",
    )

    if "selected_source" not in st.session_state:
        st.session_state["selected_source"] = "companies_house"

    current = st.session_state["selected_source"]
    if current not in SOURCE_OPTIONS:
        current = "companies_house"
        st.session_state["selected_source"] = current

    selected_risk = get_risk_level(current)
    selected_risk_def = _safe_risk_meta(selected_risk)

    if selected_risk in ["stop", "blocked"]:
        st.warning(
            f"⚠️ {SOURCE_OPTIONS[current]['label']} is {selected_risk_def['label']} — "
            f"{selected_risk_def.get('message', '')}"
        )

    for row in SOURCE_LAYOUT:
        cols = st.columns(len(row), gap="small")

        for col, source in zip(cols, row):
            cfg = SOURCE_OPTIONS[source]
            selected = current == source

            border = f"2px solid {cfg['color']}" if selected else "1px solid rgba(255,255,255,0.06)"
            bg = f"{cfg['color']}18" if selected else "rgba(255,255,255,0.02)"

            source_risk = get_risk_level(source)
            source_risk_def = _safe_risk_meta(source_risk)
            risk_color = source_risk_def.get("color", "#64748b")
            risk_label = source_risk_def.get("label", source_risk.upper())

            with col:
                st.markdown(
                    dedent(f"""
<div style="
    background: {bg};
    border: {border};
    border-radius: 16px;
    padding: 16px;
    min-height: 190px;
">
    <div style="font-size:28px;margin-bottom:10px;">{cfg['icon']}</div>
    <div style="color:white;font-size:14px;font-weight:800;margin-bottom:6px;line-height:1.25;">
        {cfg['label']}
    </div>
    <div style="color:#94a3b8;font-size:12px;line-height:1.45;margin-bottom:10px;">
        {_truncate_text(cfg['desc'], 72)}
    </div>
    <div style="color:{risk_color};font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;">
        {risk_label}
    </div>
</div>
"""),
                    unsafe_allow_html=True,
                )

                button_label = "Selected ✓" if selected else "Use"
                if st.button(
                    button_label,
                    key=f"src_{source}",
                    use_container_width=True,
                    disabled=selected,
                ):
                    st.session_state["selected_source"] = source
                    st.rerun()

        st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)

    return st.session_state["selected_source"]


# ─────────────────────────────────────────────────────────
# JOB MONITOR
# ─────────────────────────────────────────────────────────
def render_job_monitor():
    active_id = get_active_job_id()
    session_id = st.session_state.get("active_job_id")
    job_id = active_id or session_id

    if not job_id:
        return

    summary = get_job_status_summary(job_id)

    if not summary.get("found"):
        return

    status = summary.get("status", "unknown")
    progress = _safe_int(summary.get("progress", 0))
    leads = _safe_int(summary.get("leads", 0))
    message = summary.get("message", "")

    section_header(
        "Live Scraping Activity",
        "Real-time background job monitoring",
    )

    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Leads Found", leads)
    with c2:
        st.metric("Progress", f"{progress}%")
    with c3:
        st.metric("Status", status.upper())

    st.progress(progress / 100 if progress else 0)
    st.info(message)

    if status == STATUS_RUNNING:
        col1, col2 = st.columns([2, 1])
        with col1:
            st.success("Scraping runs in background. Navigate freely.")
        with col2:
            if st.button(
                "🛑 Stop Job",
                use_container_width=True,
                key="stop_job_main",
            ):
                stop_job(job_id)
                st.warning("Stop requested.")
                st.rerun()

        time.sleep(2)
        st.rerun()

    elif status == STATUS_DONE:
        st.success(f"✅ Complete — {leads} leads collected.")
        st.session_state["active_job_id"] = None

    elif status == STATUS_FAILED:
        st.error("❌ Job failed.")
        st.session_state["active_job_id"] = None

    elif status == STATUS_STOPPED:
        st.warning(f"⚫ Stopped. {leads} leads saved.")
        st.session_state["active_job_id"] = None


# ─────────────────────────────────────────────────────────
# SEARCH FORM
# ─────────────────────────────────────────────────────────
def render_search_form(selected_source):
    section_header(
        "Search Configuration",
        "Define your target business profile",
    )

    left, right = st.columns([1.5, 1], gap="large")

    keyword = ""
    location = ""
    country_name = ""
    max_results = 20

    with left:
        card_start()

        c1, c2 = st.columns(2)

        with c1:
            category = st.selectbox(
                "Business Type",
                BUSINESS_CATEGORIES,
            )
            if category == "Custom Keyword":
                keyword = st.text_input(
                    "Custom Keyword",
                    placeholder="e.g. laundry, mechanic",
                ).strip()
            else:
                keyword = category

        with c2:
            country = st.selectbox(
                "Country",
                list(LOCATION_PRESETS.keys()),
            )
            if country == "Custom":
                city = st.text_input("City")
                country_name = st.text_input("Country Name")
                location = (
                    f"{city}, {country_name}"
                    if city and country_name
                    else city or country_name
                )
            else:
                cities = LOCATION_PRESETS[country]
                city = (
                    st.selectbox("City", cities)
                    if cities
                    else st.text_input("City")
                )
                country_name = country
                location = f"{city}, {country}"

        c3, c4 = st.columns(2)

        with c3:
            max_label = st.selectbox(
                "Lead Volume",
                list(MAX_RESULTS_OPTIONS.keys()),
            )
            max_results = MAX_RESULTS_OPTIONS[max_label]

        with c4:
            do_email = st.checkbox("Find Emails", value=True)
            do_enrich = st.checkbox("Website Discovery", value=True)
            do_scripts = st.checkbox("Call Scripts", value=True)

        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)

        source_risk = get_risk_level(selected_source)

        if source_risk == "blocked":
            st.error(
                f"⛔ {SOURCE_OPTIONS[selected_source]['label']} is BLOCKED. Do not scrape today."
            )
            launch = False

        elif any_job_running():
            st.warning(
                "A job is already running. Wait for it to finish."
            )
            launch = False

        else:
            if source_risk in ["stop", "warning"]:
                st.warning(
                    f"⚠️ Risk: {selected_source.upper()} — consider switching to outreach if needed."
                )

            launch = st.button(
                "🚀 Launch Lead Discovery",
                type="primary",
                use_container_width=True,
            )

        card_end()

    with right:
        card_start()

        st.markdown(
            dedent("""
<div style="color:white;font-size:18px;font-weight:800;margin-bottom:16px;">
Campaign Summary
</div>
"""),
            unsafe_allow_html=True,
        )

        src_label = SOURCE_OPTIONS.get(selected_source, {}).get("label", selected_source)

        items = [
            ("Source", src_label),
            ("Keyword", keyword or "Not set"),
            ("Location", location or "Not set"),
            ("Volume", str(max_results)),
        ]

        for lbl, val in items:
            st.markdown(
                dedent(f"""
<div style="
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.05);
    border-radius: 12px;
    padding: 12px;
    margin-bottom: 10px;
">
    <div style="color:#64748b;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">
        {lbl}
    </div>
    <div style="color:white;font-size:15px;font-weight:700;">
        {val}
    </div>
</div>
"""),
                unsafe_allow_html=True,
            )

        card_end()

    if launch and keyword:
        safe_pages = min(5, max(1, max_results // 20))
        job_id = start_scrape_job(
            keyword=keyword,
            location=location,
            source=selected_source,
            max_results=max_results,
            max_pages=safe_pages,
            do_enrich=do_enrich,
            do_email=do_email,
            do_scripts=do_scripts,
        )
        st.session_state["active_job_id"] = job_id
        st.success("✅ Background job launched.")
        time.sleep(1)
        st.rerun()


# ─────────────────────────────────────────────────────────
# ENRICHMENT CENTER
# ─────────────────────────────────────────────────────────
def render_reenrichment():
    section_header(
        "Enrichment Center",
        "Improve contact coverage on existing leads",
    )

    missing_emails = get_leads_missing_emails(limit=500)
    missing_websites = get_leads_missing_websites(limit=500)

    c1, c2 = st.columns(2)

    with c1:
        st.markdown(
            dedent(f"""
<div class="premium-card">
    <div class="kpi-label">Missing Emails</div>
    <div class="kpi-value">{len(missing_emails)}</div>
    <div class="kpi-sub">Leads needing enrichment</div>
</div>
"""),
            unsafe_allow_html=True,
        )

    with c2:
        st.markdown(
            dedent(f"""
<div class="premium-card">
    <div class="kpi-label">Missing Websites</div>
    <div class="kpi-value">{len(missing_websites)}</div>
    <div class="kpi-sub">Leads missing web presence</div>
</div>
"""),
            unsafe_allow_html=True,
        )

    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)

    if not missing_emails and not missing_websites:
        st.success("✅ All leads already look reasonably enriched.")
        return

    total_queue = max(len(missing_emails), len(missing_websites))
    slider_max = max(5, min(100, total_queue))
    default_batch = min(20, slider_max)

    batch = st.slider(
        "Batch Size",
        5,
        slider_max,
        default_batch,
        5,
    )

    if st.button(
        "🔄 Start Re-Enrichment",
        use_container_width=True,
    ):
        progress_bar = st.progress(0)
        status_text = st.empty()

        def callback(i, total, name):
            pct = (i + 1) / max(total, 1)
            progress_bar.progress(pct)
            status_text.info(f"Processing {i + 1}/{total}: {name}")

        with st.spinner("Running enrichment pipeline..."):
            results = reenrich_leads_missing_emails(
                limit=batch,
                progress_callback=callback,
            )

        progress_bar.progress(1.0)
        found = results.get("emails_found", results.get("updated", 0))
        st.success(
            f"✅ Done — {found} new emails discovered."
        )


# ─────────────────────────────────────────────────────────
# JOB HISTORY
# ─────────────────────────────────────────────────────────
def render_job_history():
    section_header(
        "Job History",
        "Detailed scraping activity log",
    )

    jobs = get_recent_jobs(limit=20)

    if not jobs:
        st.info("No background jobs yet.")
        return

    df = pd.DataFrame(jobs)

    show_cols = [
        "id", "keyword", "location", "source",
        "status", "leads_found", "progress",
        "started_at",
    ]
    available = [c for c in show_cols if c in df.columns]

    if not available:
        st.info("No displayable job history columns yet.")
        return

    st.dataframe(
        df[available],
        use_container_width=True,
        hide_index=True,
        height=400,
    )


# ─────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────
def render_search_page():
    render_hero()

    render_scrape_risk_card()

    st.markdown("<div style='height:20px'></div>", unsafe_allow_html=True)

    render_job_monitor()

    st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)

    tabs = st.tabs([
        "🚀 New Campaign",
        "📋 Recent Campaigns",
        "🔄 Enrichment Center",
        "📊 Job History",
    ])

    with tabs[0]:
        selected_source = render_source_selector()
        st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)
        render_search_form(selected_source)

    with tabs[1]:
        render_recent_campaigns()

    with tabs[2]:
        render_reenrichment()

    with tabs[3]:
        render_job_history()


def render():
    render_search_page()
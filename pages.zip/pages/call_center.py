# pages/call_center.py
# KNCS LeadGen Pro — v9.7 Premium
# Country-aware call queue, WhatsApp verified vs estimated,
# market split filters, batch scoring with scope + progress bar.

from __future__ import annotations

from datetime import datetime
import html
import json
import re
from typing import Optional

import pandas as pd
import streamlit as st

# ─────────────────────────────────────────────────────────
# Sender constants
# ─────────────────────────────────────────────────────────
SENDER_NAME  = "Amechi"
COMPANY_NAME = "King Networks Consulting Services (KNCS)"
CTA_LINK     = ""

# ─────────────────────────────────────────────────────────
# Safe DB imports
# ─────────────────────────────────────────────────────────
try:
    from database import (
        get_connection,
        update_lead_status,
        get_dashboard_stats as _get_stats_raw,
        log_call,
        log_outreach_action,
        get_top_prospects,
        get_ai_call_ready_leads,
        get_whatsapp_ready_leads,
        get_whatsapp_verified_leads,
        get_whatsapp_estimated_leads,
        get_email_ready_leads,
        get_leads_by_priority,
        get_call_ready_leads,
        get_manual_review_leads,
        verify_whatsapp_manually,
    )
    # Alias — get_stats is get_dashboard_stats
    def get_stats() -> dict:
        try:
            return _get_stats_raw() or {}
        except Exception:
            return {}

    _DB_AVAILABLE = True

except Exception:
    _DB_AVAILABLE = False
    get_connection = None

    def get_stats() -> dict:
        return {}

    def update_lead_status(*a, **k) -> bool:
        return False

    def log_call(*a, **k) -> bool:
        return False

    def log_outreach_action(*a, **k) -> bool:
        return False

    def get_top_prospects(limit: int = 100) -> list:
        return []

    def get_ai_call_ready_leads(limit: int = 100) -> list:
        return []

    def get_whatsapp_ready_leads(limit: int = 100) -> list:
        return []

    def get_whatsapp_verified_leads(limit: int = 100) -> list:
        return []

    def get_whatsapp_estimated_leads(limit: int = 100) -> list:
        return []

    def get_email_ready_leads(limit: int = 100) -> list:
        return []

    def get_leads_by_priority(priority: str, limit: int = 100) -> list:
        return []

    def get_call_ready_leads(limit: int = 100) -> list:
        return []

    def get_manual_review_leads(limit: int = 50) -> list:
        return []

    def verify_whatsapp_manually(lead_id: int, verified: bool = True) -> bool:
        return False


# ─────────────────────────────────────────────────────────
# Safe scorer imports
# ─────────────────────────────────────────────────────────
try:
    from engine.scorer import (
        get_fit_label,
        get_channel_label,
        get_contact_completeness,
        score_unscored_leads_batch,
        score_and_save_lead,
    )
    _SCORER_AVAILABLE = True
except Exception:
    _SCORER_AVAILABLE = False

    def get_fit_label(fit_score: int) -> dict:
        if fit_score >= 8:
            return {"label": "⭐ HIGH FIT", "color": "#2ed573", "bg": "#eafff1"}
        if fit_score >= 5:
            return {"label": "✅ MEDIUM FIT", "color": "#FFA502", "bg": "#FFF3E0"}
        if fit_score >= 1:
            return {"label": "⚪ LOW FIT", "color": "#747D8C", "bg": "#F1F2F6"}
        return {"label": "❓ UNSCORED", "color": "#a4b0be", "bg": "#f1f2f6"}

    def get_channel_label(channel: str) -> dict:
        return {
            "whatsapp": {"label": "💬 WhatsApp", "color": "#25D366", "bg": "#e8fff2"},
            "ai_call":  {"label": "🤖 AI Call",  "color": "#5352ED", "bg": "#eeeeff"},
            "email":    {"label": "📧 Email",     "color": "#1E90FF", "bg": "#e8f4ff"},
            "manual":   {"label": "👤 Manual",    "color": "#747D8C", "bg": "#F1F2F6"},
            "unknown":  {"label": "❓ Unknown",   "color": "#a4b0be", "bg": "#f1f2f6"},
        }.get(channel or "unknown", {"label": "❓ Unknown", "color": "#a4b0be", "bg": "#f1f2f6"})

    def get_contact_completeness(lead: dict) -> dict:
        fields = {
            "Phone":   bool(lead.get("phone")),
            "Email":   bool(lead.get("email")),
            "Website": bool(lead.get("website")),
            "Address": bool(lead.get("address")),
        }
        filled = sum(1 for v in fields.values() if v)
        return {
            "percentage": (filled / len(fields) * 100),
            "fields": fields,
            "filled": filled,
            "total": len(fields),
        }

    def score_unscored_leads_batch(limit: int = 50, use_ai: bool = True) -> dict:
        return {"total": 0, "scored": 0, "high": 0, "medium": 0, "low": 0}

    def score_and_save_lead(lead_id: int) -> Optional[dict]:
        return None


# ─────────────────────────────────────────────────────────
# Safe WhatsApp message builder import
# ─────────────────────────────────────────────────────────
try:
    from engine.whatsapp_messages import build_whatsapp_message, build_wa_prefill_link
except Exception:
    def build_whatsapp_message(
        lead: dict,
        tone: str = "friendly",
        sender_name: str = "Amechi",
        company_name: str = "King Networks Consulting Services (KNCS)",
        cta_link: str = "",
    ) -> str:
        name = lead.get("business_name", "there")
        return (
            f"Hi {name}, I noticed your business could benefit from "
            f"a professional website.\n\n— {sender_name} ({company_name})"
        )

    def build_wa_prefill_link(wa_number_digits: str, message: str) -> str:
        from urllib.parse import quote
        digits = re.sub(r"\D", "", str(wa_number_digits or ""))
        return f"https://wa.me/{digits}?text={quote(message)}" if digits else ""


# ─────────────────────────────────────────────────────────
# Valid WA status values (no "unverified" contamination)
# ─────────────────────────────────────────────────────────
_VALID_WA_STATUSES = {
    "verified", "opted_in", "estimated", "business_confirmed", "unknown"
}

# ─────────────────────────────────────────────────────────
# Market / country constants
# ─────────────────────────────────────────────────────────
MARKET_ORDER = {
    "nigeria": 0, "africa": 1, "uk": 2, "europe": 3,
    "north_america": 4, "asia": 5, "middle_east": 6,
    "latam": 7, "oceania": 8, "other": 99,
}

COUNTRY_DIAL_CODES = {
    "nigeria": "234", "ghana": "233", "kenya": "254",
    "south africa": "27", "egypt": "20", "ethiopia": "251",
    "tanzania": "255", "uganda": "256", "rwanda": "250",
    "senegal": "221", "cameroon": "237", "ivory coast": "225",
    "cote d'ivoire": "225", "zimbabwe": "263", "zambia": "260",
    "mozambique": "258", "angola": "244", "botswana": "267",
    "namibia": "264", "malawi": "265", "sierra leone": "232",
    "liberia": "231", "gambia": "220", "guinea": "224",
    "mali": "223", "niger": "227", "chad": "235",
    "sudan": "249", "somalia": "252",
    "united kingdom": "44", "uk": "44", "england": "44",
    "scotland": "44", "wales": "44", "northern ireland": "44",
    "ireland": "353", "germany": "49", "france": "33",
    "italy": "39", "spain": "34", "portugal": "351",
    "netherlands": "31", "belgium": "32", "switzerland": "41",
    "austria": "43", "sweden": "46", "norway": "47",
    "denmark": "45", "finland": "358", "poland": "48",
    "czech republic": "420", "hungary": "36", "romania": "40",
    "greece": "30", "turkey": "90",
    "uae": "971", "united arab emirates": "971", "dubai": "971",
    "saudi arabia": "966", "qatar": "974", "kuwait": "965",
    "bahrain": "973", "oman": "968", "jordan": "962",
    "lebanon": "961", "israel": "972",
    "india": "91", "pakistan": "92", "bangladesh": "880",
    "sri lanka": "94", "indonesia": "62", "philippines": "63",
    "malaysia": "60", "singapore": "65", "thailand": "66",
    "vietnam": "84", "china": "86", "japan": "81",
    "south korea": "82", "hong kong": "852",
    "united states": "1", "usa": "1", "us": "1", "canada": "1",
    "brazil": "55", "mexico": "52", "colombia": "57",
    "argentina": "54", "peru": "51", "chile": "56",
    "venezuela": "58", "ecuador": "593", "bolivia": "591",
    "paraguay": "595", "uruguay": "598",
    "jamaica": "1876", "trinidad": "1868",
    "trinidad and tobago": "1868", "barbados": "1246",
    "panama": "507", "costa rica": "506",
    "australia": "61", "new zealand": "64",
}


# ─────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────

def _esc(value) -> str:
    return html.escape(str(value if value is not None else ""))


def _safe_int(value, default: int = 0) -> int:
    try:
        return int(value) if value is not None else default
    except Exception:
        return default


def _safe_float(value, default: float = 0.0) -> float:
    try:
        return float(value) if value is not None else default
    except Exception:
        return default


def _parse_json_list(value) -> list:
    if isinstance(value, list):
        return value
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return parsed
        except Exception:
            pass
        return [p.strip() for p in re.split(r"[|,;]\s*", text) if p.strip()]
    return [str(value)]


def _priority_rank(priority: str) -> int:
    return {
        "high": 0, "medium": 1, "low": 2,
        "unscored": 3, "": 3,
    }.get(str(priority or "").lower(), 3)


def _status_allowed(status: str) -> bool:
    return (status or "new").lower() not in {
        "deal_closed", "not_interested", "wrong_number"
    }


def _fmt_money(value) -> str:
    try:
        if isinstance(value, str) and value.strip().lower() in ("", "none", "null"):
            return "₦0"
        return f"₦{float(value or 0):,.0f}"
    except Exception:
        return "₦0"


def _norm(value) -> str:
    return str(value or "").strip().lower()


def _wa_status(lead: dict) -> str:
    """
    FIX: Never returns 'unverified' as WA status.
    verification_status = 'unverified' is not a WA status.
    """
    raw = _norm(lead.get("wa_status") or "")
    if raw in _VALID_WA_STATUSES:
        return raw

    # Legacy flag fallback
    if _safe_int(lead.get("wa_verified", 0)) or _safe_int(lead.get("whatsapp_verified", 0)):
        return "verified"
    if _safe_int(lead.get("whatsapp_ready", 0)):
        return "estimated"
    return "unknown"


def _normalize_phone_for_whatsapp(phone: str, country: str = "") -> str:
    if not phone:
        return ""
    digits = re.sub(r"[^\d]", "", str(phone).strip())
    if not digits or len(digits) < 6:
        return ""
    if len(digits) >= 10 and not digits.startswith("0"):
        return digits
    if digits.startswith("00"):
        return digits[2:]
    if digits.startswith("0"):
        country_lower = (country or "").lower().strip()
        dial_code = COUNTRY_DIAL_CODES.get(country_lower, "")
        if not dial_code:
            for name, code in COUNTRY_DIAL_CODES.items():
                if name in country_lower or country_lower in name:
                    dial_code = code
                    break
        if dial_code:
            return dial_code + digits[1:]
    return digits


def _wa_gate(lead: dict) -> dict:
    phone      = str(lead.get("phone") or "").strip()
    country    = str(lead.get("country") or "").strip()
    wa         = _wa_status(lead)
    phone_clean = _normalize_phone_for_whatsapp(phone, country)

    if not phone_clean:
        return {
            "can_check": False, "show_composer": False,
            "verified": False, "estimated": False,
            "wa_link": "", "phone_clean": "", "display_phone": "",
            "reason": "No valid phone number present.",
        }

    verified  = wa in {"verified", "opted_in"}
    estimated = wa in {"estimated", "business_confirmed"}

    return {
        "can_check":      True,
        "show_composer":  verified or estimated,
        "verified":       verified,
        "estimated":      estimated,
        "wa_link":        build_wa_prefill_link(
            phone_clean, "Hi, is this the business WhatsApp?"
        ),
        "phone_clean":    phone_clean,
        "display_phone":  phone,
        "reason": (
            "WhatsApp verified by agent or explicit confirmation."
            if verified else
            "WhatsApp estimated from market / heuristics — not verified."
            if estimated else
            "This number has not been confirmed as WhatsApp-active."
        ),
    }


def _lead_wa_badge(lead: dict) -> str:
    return {
        "verified":           "✅ WA Verified",
        "opted_in":           "✅ WA Opted-In",
        "estimated":          "💬 WA Estimated",
        "business_confirmed": "🟠 WA Business Confirmed",
    }.get(_wa_status(lead), "⚪ WA Unknown")


def _lead_sort_key(lead: dict):
    market  = _norm(lead.get("market")) or "other"
    wa      = _wa_status(lead)
    wa_rank = (
        0 if wa in {"verified", "opted_in"}
        else 1 if wa == "estimated"
        else 2
    )
    return (
        MARKET_ORDER.get(market, 99),
        wa_rank,
        _priority_rank(lead.get("lead_priority")),
        -_safe_int(lead.get("fit_score", 0)),
        -_safe_int(lead.get("urgency_score", 0)),
        -_safe_int(lead.get("reachability_score", 0)),
        -_safe_int(lead.get("opportunity_score", 0)),
        str(lead.get("business_name", "")).lower(),
    )


def _lead_matches_filters(
    lead: dict,
    country: str = "All",
    market: str = "All",
    channel: str = "All",
    wa_status: str = "All",
    min_fit: int = 0,
) -> bool:
    if min_fit and _safe_int(lead.get("fit_score", 0)) < min_fit:
        return False
    if country != "All" and _norm(lead.get("country")) != _norm(country):
        return False
    if market != "All" and _norm(lead.get("market")) != _norm(market):
        return False
    if channel != "All" and _norm(lead.get("best_channel")) != _norm(channel):
        return False
    if wa_status != "All" and _wa_status(lead) != _norm(wa_status):
        return False
    return True


def _merge_unique(*lists) -> list:
    out: list = []
    seen: set = set()
    for lst in lists:
        for lead in (lst or []):
            lead_id = lead.get("id")
            if not lead_id or lead_id in seen:
                continue
            seen.add(lead_id)
            if not str(lead.get("phone") or "").strip():
                continue
            if not _status_allowed(lead.get("contact_status")):
                continue
            out.append(lead)
    out.sort(key=_lead_sort_key)
    return out


def _render_link_button(
    url: str,
    label: str,
    icon: str = "💬",
    bg: str = "linear-gradient(135deg,#25d366,#128c7e)",
) -> None:
    if not url:
        return
    st.markdown(
        f'<a href="{url}" target="_blank" style="display:block;'
        f'text-align:center;background:{bg};color:white;'
        f'padding:12px 16px;border-radius:14px;font-weight:700;'
        f'font-size:14px;text-decoration:none;">'
        f'{icon} {label}</a>',
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────
# Data helpers
# ─────────────────────────────────────────────────────────

def get_pipeline_summary() -> dict:
    if get_connection is None:
        return {}
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT contact_status, COUNT(*) FROM leads GROUP BY contact_status"
        )
        return {row[0]: row[1] for row in cursor.fetchall()}
    except Exception:
        return {}
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def get_outreach_history(limit: int = 100) -> list:
    if get_connection is None:
        return []
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT o.id AS log_id, o.sent_at AS logged_at, o.channel,
                   o.status, o.message_text,
                   l.id AS lead_id, l.business_name, l.industry,
                   l.city, l.country, l.market, l.phone, l.email,
                   l.fit_score, l.lead_priority, l.best_channel,
                   l.opportunity_score
            FROM outreach_log o
            LEFT JOIN leads l ON o.lead_id = l.id
            ORDER BY o.sent_at DESC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(r) for r in cursor.fetchall()]
    except Exception:
        return []
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def get_deals_data() -> pd.DataFrame:
    if get_connection is None:
        return pd.DataFrame()
    conn = None
    try:
        conn = get_connection()
        return pd.read_sql_query(
            """
            SELECT r.business_name, r.amount, r.service_type,
                   r.payment_status, r.closed_at,
                   l.city, l.country, l.market, l.fit_score,
                   l.lead_priority, l.best_channel
            FROM revenue r
            LEFT JOIN leads l ON r.lead_id = l.id
            ORDER BY r.closed_at DESC
            LIMIT 100
            """,
            conn,
        )
    except Exception:
        return pd.DataFrame()
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def get_call_queue(limit: int = 200) -> list:
    sources = []
    for fn in [
        lambda: get_whatsapp_verified_leads(limit=100),
        lambda: get_whatsapp_estimated_leads(limit=100),
        lambda: get_ai_call_ready_leads(limit=100),
        lambda: get_call_ready_leads(limit=100),
        lambda: get_top_prospects(limit=100),
        lambda: get_leads_by_priority("high", limit=100),
        lambda: get_leads_by_priority("medium", limit=100),
        lambda: get_email_ready_leads(limit=100),
        lambda: get_manual_review_leads(limit=50),
    ]:
        try:
            sources.extend(fn() or [])
        except Exception:
            pass
    return _merge_unique(sources)[:limit]


def get_ai_prospects(limit: int = 100) -> list:
    sources = []
    for fn in [
        lambda: get_top_prospects(limit=limit),
        lambda: get_whatsapp_verified_leads(limit=limit),
        lambda: get_whatsapp_estimated_leads(limit=limit),
        lambda: get_ai_call_ready_leads(limit=limit),
        lambda: get_email_ready_leads(limit=limit),
        lambda: get_leads_by_priority("high", limit=limit),
        lambda: get_leads_by_priority("medium", limit=limit),
    ]:
        try:
            sources.extend(fn() or [])
        except Exception:
            pass
    return _merge_unique(sources)[:limit]


# ─────────────────────────────────────────────────────────
# Unscored lead fetcher — FIX: IS NULL not = 0
# ─────────────────────────────────────────────────────────

def _get_unscored_lead_ids(
    limit: int,
    score_scope: str = "all",
    country: str = "All",
    market: str = "All",
) -> list:
    """
    FIX: fit_score IS NULL (not = 0) — score of 0 is valid for bad leads.
    FIX: scope filter applied correctly for country/market.
    """
    if get_connection is None:
        return []

    scope = (score_scope or "all").lower().strip()
    conn  = None

    try:
        conn   = get_connection()
        cur    = conn.cursor()
        params = []

        where = """
            (fit_score IS NULL
             OR lead_priority IS NULL
             OR lead_priority IN ('', 'unscored'))
        """

        if scope == "country" and country and country != "All":
            where += " AND LOWER(COALESCE(country, '')) = LOWER(?)"
            params.append(country)

        if scope == "market" and market and market != "All":
            where += " AND LOWER(COALESCE(market, '')) = LOWER(?)"
            params.append(market)

        params.append(limit)
        cur.execute(
            f"SELECT id, business_name FROM leads WHERE {where} ORDER BY id ASC LIMIT ?",
            tuple(params),
        )

        out = []
        for r in cur.fetchall():
            try:
                out.append({"id": r["id"], "name": r["business_name"] or "Unknown"})
            except Exception:
                out.append({"id": r[0], "name": r[1] or "Unknown"})
        return out

    except Exception:
        return []
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


# ─────────────────────────────────────────────────────────
# Batch scoring with progress
# ─────────────────────────────────────────────────────────

def _score_with_progress_call_center(
    batch_size: int,
    score_scope: str = "all",
    country: str = "All",
    market: str = "All",
) -> dict:
    if batch_size <= 0:
        return {"total": 0, "scored": 0}

    lead_ids = _get_unscored_lead_ids(
        batch_size,
        score_scope=score_scope,
        country=country,
        market=market,
    )
    total = len(lead_ids)
    if total == 0:
        return {"total": 0, "scored": 0}

    st.markdown(
        "<div style='color:#94a3b8;font-size:12px;"
        "font-weight:700;text-transform:uppercase;"
        "letter-spacing:1px;margin-bottom:6px;'>"
        "📊 Scoring Progress</div>",
        unsafe_allow_html=True,
    )

    # FIX: initialise with float 0.0
    progress_bar  = st.progress(0.0)
    status_text   = st.empty()
    lead_feedback = st.empty()

    scored = 0
    high = medium = low = 0

    for i, item in enumerate(lead_ids, start=1):
        lead_id   = item["id"]
        lead_name = item["name"]

        # FIX: always float 0.0–1.0
        progress_frac = float(i - 1) / float(max(total, 1))
        progress_bar.progress(progress_frac)

        status_text.markdown(
            f"<div style='color:#cbd5e1;font-size:13px;'>"
            f"⏳ Scoring lead <b>{i}</b> of <b>{total}</b> — "
            f"{_esc(lead_name)}</div>",
            unsafe_allow_html=True,
        )

        try:
            res = score_and_save_lead(lead_id)
            if res:
                scored += 1
                fit      = _safe_int(res.get("fit_score", 0))
                audit    = _safe_int(res.get("website_audit_score", 0))
                # FIX: scorer now returns "high"/"medium"/"low"/"unscored"
                priority = str(res.get("lead_priority") or "unscored").lower()

                if priority == "high" or fit >= 8:
                    high += 1
                elif priority == "medium" or fit >= 6:
                    medium += 1
                else:
                    low += 1

                if fit >= 8:
                    dot, color = "🟢", "#22c55e"
                elif fit >= 6:
                    dot, color = "🟡", "#f59e0b"
                else:
                    dot, color = "🔴", "#ef4444"

                lead_feedback.markdown(
                    f"<div style='background:rgba(255,255,255,0.03);"
                    f"border:1px solid rgba(255,255,255,0.06);"
                    f"border-radius:10px;padding:8px 12px;"
                    f"font-size:12px;color:#cbd5e1;margin-top:4px;'>"
                    f"{dot} <b style='color:{color};'>{_esc(lead_name)}</b> — "
                    f"fit: <b>{fit}/10</b> | audit: <b>{audit}/10</b> | "
                    f"priority: <b>{_esc(priority)}</b>"
                    f"</div>",
                    unsafe_allow_html=True,
                )
            else:
                lead_feedback.markdown(
                    f"<div style='color:#ef4444;font-size:12px;padding:4px 0;'>"
                    f"⚠️ Skipped: {_esc(lead_name)} — scorer returned no result</div>",
                    unsafe_allow_html=True,
                )
        except Exception as exc:
            lead_feedback.markdown(
                f"<div style='color:#ef4444;font-size:12px;padding:4px 0;'>"
                f"⚠️ Error: {_esc(lead_name)} — {_esc(str(exc))}</div>",
                unsafe_allow_html=True,
            )

    # FIX: complete with float 1.0
    progress_bar.progress(1.0)
    status_text.markdown(
        f"<div style='color:#22c55e;font-size:13px;font-weight:700;'>"
        f"✅ Complete — {scored}/{total} leads scored</div>",
        unsafe_allow_html=True,
    )
    lead_feedback.empty()

    return {
        "total": total, "scored": scored,
        "high": high, "medium": medium, "low": low,
    }


# ─────────────────────────────────────────────────────────
# Call outcome logger
# FIX: get_connection None guard moved before use
# ─────────────────────────────────────────────────────────

def log_call_outcome(
    lead: dict,
    status: str,
    notes: str = "",
    deal_value: float = 0,
) -> None:
    lead_id = lead.get("id")
    if not lead_id:
        return

    now     = datetime.now().isoformat(timespec="seconds")
    channel = (lead.get("best_channel") or "manual").lower().strip()
    if channel not in {"whatsapp", "ai_call", "email", "manual"}:
        channel = "manual"

    try:
        update_lead_status(lead_id, status, notes)
    except Exception:
        pass
    try:
        log_call(lead_id=lead_id, status=status, notes=notes, duration=0)
    except Exception:
        pass
    try:
        log_outreach_action(
            lead_id=lead_id,
            channel=channel,
            message_text=notes,
            status=status,
        )
    except Exception:
        pass

    if status == "deal_closed" and deal_value and deal_value > 0:
        # FIX: guard before any use of get_connection
        if get_connection is None:
            return
        conn = None
        try:
            conn = get_connection()
            conn.execute(
                """
                INSERT INTO revenue
                    (lead_id, business_name, amount, service_type,
                     payment_status, closed_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    lead_id,
                    lead.get("business_name", "Unknown"),
                    deal_value,
                    "Website Design",
                    "confirmed",
                    now,
                ),
            )
            conn.commit()
        except Exception as exc:
            st.error(f"Error logging deal: {exc}")
        finally:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass


# ─────────────────────────────────────────────────────────
# UI helpers
# ─────────────────────────────────────────────────────────

def _render_page_css() -> None:
    """
    FIX: CSS injected inside a function — not at module level.
    Called once from render_call_center().
    """
    st.markdown(
        """
        <style>
            .kpi-label {
                color: #64748b; font-size: 10px; font-weight: 700;
                text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px;
            }
            .kpi-value {
                color: white; font-size: 26px; font-weight: 900;
                line-height: 1; margin-bottom: 6px;
            }
            .kpi-sub { color: #94a3b8; font-size: 12px; }
        </style>
        """,
        unsafe_allow_html=True,
    )


def section_header(title: str, subtitle: str = "") -> None:
    sub_html = (
        f'<div style="margin-top:6px;color:#94a3b8;font-size:13px;">'
        f'{_esc(subtitle)}</div>'
        if subtitle else ""
    )
    st.markdown(
        f'<div style="margin-bottom:16px;">'
        f'<div style="font-size:22px;font-weight:800;color:white;">'
        f'{_esc(title)}</div>'
        f'{sub_html}</div>',
        unsafe_allow_html=True,
    )


def card(content_html: str, border_color: str = "rgba(255,255,255,0.07)") -> None:
    st.markdown(
        f'<div style="background:linear-gradient(135deg,'
        f'rgba(17,24,39,0.95),rgba(24,33,52,0.95));'
        f'border:1px solid {border_color};border-radius:16px;'
        f'padding:20px;margin-bottom:16px;">'
        f'{content_html}</div>',
        unsafe_allow_html=True,
    )


def _kpi_card(icon: str, title: str, value, sub: str, color: str) -> None:
    st.markdown(
        f'<div style="background:linear-gradient(135deg,'
        f'rgba(17,24,39,0.95),rgba(24,33,52,0.95));'
        f'border:1px solid rgba(255,255,255,0.07);'
        f'border-top:3px solid {color};border-radius:16px;'
        f'padding:16px 14px;box-shadow:0 6px 20px rgba(0,0,0,0.2);margin-bottom:16px;">'
        f'<div style="font-size:26px;margin-bottom:10px;">{icon}</div>'
        f'<div style="color:#64748b;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;">{_esc(title)}</div>'
        f'<div style="font-size:22px;font-weight:900;color:white;'
        f'margin-top:6px;line-height:1;">{_esc(str(value))}</div>'
        f'<div style="font-size:11px;color:{color};margin-top:6px;'
        f'font-weight:600;">{_esc(sub)}</div></div>',
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────
# Hero / KPI sections
# ─────────────────────────────────────────────────────────

def render_hero() -> None:
    now = datetime.now()
    st.markdown(
        f'<div style="margin-bottom:28px;">'
        f'<div style="font-size:40px;font-weight:900;color:white;'
        f'line-height:1;letter-spacing:-2px;">Sales Call Center</div>'
        f'<div style="margin-top:12px;max-width:760px;color:#94a3b8;'
        f'font-size:15px;line-height:1.8;">'
        f'Work through your highest-fit prospects first. Ranked by AI fit score, '
        f'urgency, reachability, country/market and best outreach channel.<br/>'
        f'<span style="color:#cbd5e1;">'
        f'Updated {_esc(now.strftime("%A, %d %B %Y, %H:%M:%S"))}'
        f'</span></div></div>',
        unsafe_allow_html=True,
    )


def render_pipeline_kpis() -> None:
    pipeline = get_pipeline_summary()
    stats    = get_stats()
    # FIX: use stats for queue size — avoids 9 extra DB queries
    queue_count = _safe_int(stats.get("total_leads", 0))

    cards = [
        ("📋", "Queue",       queue_count,                                         "Leads total",      "#5b8cff"),
        ("💬", "WA Verified", _safe_int(stats.get("whatsapp_verified", 0)),        "Confirmed only",   "#25D366"),
        ("🟡", "WA Estimated",_safe_int(stats.get("whatsapp_estimated", 0)),       "Heuristic only",   "#f59e0b"),
        ("✅", "Interested",  _safe_int(pipeline.get("interested", 0)),            "Warm prospects",   "#10b981"),
        ("📞", "Called",      _safe_int(pipeline.get("called", 0)),               "Outreach done",    "#8b5cf6"),
        ("🔥", "Closed",      _safe_int(pipeline.get("deal_closed", 0)),          "Deals won",        "#ef4444"),
    ]
    cols = st.columns(6)
    for idx, (icon, title, value, sub, color) in enumerate(cards):
        with cols[idx]:
            _kpi_card(icon, title, value, sub, color)

    st.markdown(
        f"<div style='margin-top:8px;color:#94a3b8;font-size:12px;'>"
        f"Revenue tracked: <b style='color:white;'>"
        f"{_fmt_money(stats.get('total_revenue', 0))}</b></div>",
        unsafe_allow_html=True,
    )


def render_intelligence_kpis() -> None:
    stats = get_stats()
    cards = [
        ("⭐", "High Fit",      _safe_int(stats.get("high_fit_leads", 0)),              "Best prospects",    "#2ed573"),
        ("🤖", "AI Call Ready", _safe_int(stats.get("ai_call_ready", 0)),              "Voice call queue",  "#5352ED"),
        ("💬", "WhatsApp Ready",_safe_int(stats.get("whatsapp_ready", 0)),             "Quick outreach",    "#25D366"),
        ("📧", "Email Ready",   _safe_int(stats.get("email_ready", 0)),               "Cold email queue",  "#1E90FF"),
        ("👤", "Decision Makers",_safe_int(stats.get("leads_with_decision_maker", 0)),"Named contacts",    "#fb7185"),
        ("🧠", "Unscored",      _safe_int(stats.get("unscored_leads", 0)),             "Need scoring",      "#94a3b8"),
    ]
    cols = st.columns(6)
    for idx, (icon, title, value, sub, color) in enumerate(cards):
        with cols[idx]:
            _kpi_card(icon, title, value, sub, color)


# ─────────────────────────────────────────────────────────
# Scoring banner
# ─────────────────────────────────────────────────────────

def render_scoring_banner(
    queue_country: str = "All",
    queue_market: str = "All",
) -> None:
    stats    = get_stats()
    unscored = _safe_int(stats.get("unscored_leads", 0))
    if unscored <= 0:
        return

    st.info(
        f"🧠 **{unscored} leads still unscored.** "
        f"Score them to generate fit reason, opener, routing and better queues."
    )

    c1, c2, c3 = st.columns([1, 1, 1.2])
    with c1:
        batch_size = st.selectbox(
            "Score batch size",
            options=[5, 10, 20, 50, 100],
            index=1,
            key="cc_score_batch",
        )
    with c2:
        scope_label = st.selectbox(
            "Score scope",
            options=["All unscored", "Selected country", "Selected market"],
            index=0,
            key="cc_score_scope",
            help="Limit scoring to match the country/market filters above.",
        )
    with c3:
        if scope_label == "Selected country":
            st.caption(f"Country scope: **{queue_country}**")
        elif scope_label == "Selected market":
            st.caption(f"Market scope: **{queue_market}**")
        else:
            st.caption("Scope: **All unscored**")

    score_scope = (
        "country" if scope_label == "Selected country"
        else "market" if scope_label == "Selected market"
        else "all"
    )

    actual_limit = min(batch_size, unscored)
    btn_label    = f"🧠 Score Next {actual_limit} Leads"
    if score_scope == "country" and queue_country != "All":
        btn_label += f" (Country: {queue_country})"
    elif score_scope == "market" and queue_market != "All":
        btn_label += f" (Market: {queue_market})"

    if st.button(
        btn_label,
        use_container_width=True,
        type="primary",
        key="score_existing_leads_call_center",
    ):
        with st.spinner("Running scoring… (AI + enrichment)"):
            res = _score_with_progress_call_center(
                actual_limit,
                score_scope=score_scope,
                country=queue_country,
                market=queue_market,
            )

        if res.get("total", 0) == 0:
            st.warning("No unscored leads matched this scope.")
        else:
            st.success(
                f"✅ Scoring complete: {res.get('scored', 0)} of "
                f"{res.get('total', 0)} leads scored. "
                f"High: {res.get('high', 0)} | "
                f"Medium: {res.get('medium', 0)} | "
                f"Low: {res.get('low', 0)}"
            )
        st.rerun()


# ─────────────────────────────────────────────────────────
# WhatsApp verification
# ─────────────────────────────────────────────────────────

def render_whatsapp_verify_button(lead: dict, key_suffix: str = "") -> None:
    lead_id = lead.get("id")
    phone   = str(lead.get("phone") or "").strip()
    if not phone or not lead_id:
        return

    status = _wa_status(lead)
    if status in {"verified", "opted_in"} or _safe_int(lead.get("whatsapp_verified", 0)):
        st.success("✅ WhatsApp verified for this number")
        if st.button(
            "❌ Remove WhatsApp Verification",
            key=f"wa_unverify_{lead_id}{key_suffix}",
            use_container_width=True,
        ):
            try:
                verify_whatsapp_manually(lead_id, verified=False)
                st.rerun()
            except Exception as exc:
                st.error(f"Could not remove verification: {exc}")
    else:
        st.caption("Confirm this number is on WhatsApp before sending.")
        if st.button(
            "✅ Mark as WhatsApp Verified",
            key=f"wa_verify_{lead_id}{key_suffix}",
            use_container_width=True,
        ):
            try:
                verify_whatsapp_manually(lead_id, verified=True)
                st.rerun()
            except Exception as exc:
                st.error(f"Could not save verification: {exc}")


def render_whatsapp_manual_tools(
    lead: dict,
    wa_gate: dict,
    key_suffix: str = "",
) -> None:
    if not wa_gate.get("phone_clean"):
        return

    st.markdown(
        '<div style="margin-top:4px;margin-bottom:8px;color:#25D366;'
        'font-size:11px;font-weight:700;text-transform:uppercase;'
        'letter-spacing:1px;">🔐 WhatsApp Verification</div>',
        unsafe_allow_html=True,
    )
    st.caption(
        "Open WhatsApp to manually confirm whether this number is active, "
        "then mark it below."
    )

    c1, c2 = st.columns(2)
    with c1:
        _render_link_button(wa_gate.get("wa_link", ""), "Open WhatsApp to Check")
    with c2:
        render_whatsapp_verify_button(lead, key_suffix=key_suffix)


def render_whatsapp_composer(lead: dict, wa_gate: dict) -> None:
    lead_id     = lead.get("id", "unknown")
    phone_clean = wa_gate.get("phone_clean", "")
    verified    = wa_gate.get("verified", False)
    estimated   = wa_gate.get("estimated", False)
    badge       = (
        "✅ Verified" if verified
        else "⚠️ Estimated" if estimated
        else "⚪ Unknown"
    )

    st.markdown(
        '<div style="margin-top:14px;margin-bottom:8px;color:#25D366;'
        'font-size:11px;font-weight:700;text-transform:uppercase;'
        'letter-spacing:1px;">💬 WhatsApp Outreach</div>',
        unsafe_allow_html=True,
    )

    tone = st.selectbox(
        "Message tone",
        options=["friendly", "formal", "direct"],
        index=0,
        key=f"wa_tone_{lead_id}",
    )

    generated_msg = build_whatsapp_message(
        lead,
        tone=tone,
        sender_name=SENDER_NAME,
        company_name=COMPANY_NAME,
        cta_link=CTA_LINK,
    )

    final_msg = st.text_area(
        "Message preview (edit if needed)",
        value=generated_msg,
        height=220,
        key=f"wa_msg_{lead_id}",
    )

    wa_link = (
        build_wa_prefill_link(phone_clean, final_msg.strip())
        if phone_clean and final_msg.strip()
        else wa_gate.get("wa_link", "")
    )

    if wa_link:
        st.markdown(
            f'<a href="{wa_link}" target="_blank" '
            f'style="display:inline-block;'
            f'background:linear-gradient(135deg,#25d366,#128c7e);'
            f'color:white;padding:12px 24px;border-radius:14px;'
            f'font-weight:700;font-size:14px;text-decoration:none;'
            f'margin-top:4px;">💬 Open WhatsApp Chat {_esc(badge)}</a>',
            unsafe_allow_html=True,
        )
    else:
        st.warning("No valid phone number to open WhatsApp.")

    st.caption(
        f"From: {SENDER_NAME} ({COMPANY_NAME}) | "
        f"Tone: {tone} | Chars: {len(final_msg)}"
    )


# ─────────────────────────────────────────────────────────
# Call script fallback
# ─────────────────────────────────────────────────────────

def get_call_script_fallback(lead: dict) -> str:
    name     = lead.get("business_name", "your business")
    industry = lead.get("industry", "business")
    city     = lead.get("city", "your area")
    opener   = lead.get("recommended_opener") or ""
    country  = lead.get("country", "")
    market   = lead.get("market", "")
    return (
        f"{opener or f'Hi, is that the owner of {name}?'}\n\n"
        f"My name is {SENDER_NAME} — I help {industry} businesses in {city}"
        f"{f', {country}' if country else ''} get more customers through "
        f"a professional website.\n\n"
        f"I noticed {name} might benefit from:\n"
        f"→ Professional website design\n"
        f"→ Google presence and local SEO\n"
        f"→ WhatsApp enquiry button\n"
        f"→ Mobile-friendly layout\n\n"
        f"Could I take 2 minutes to share what I found?\n\n"
        f"[IF INTERESTED]\nGreat — I can show you a quick homepage concept and pricing.\n\n"
        f"[IF BUSY]\nNo problem. When is a better time to call?\n\n"
        f"[IF NO WEBSITE]\nI noticed you don't have a website yet — "
        f"that's usually where we can help fastest.\n"
        f"{f'({market})' if market else ''}"
    )


# ─────────────────────────────────────────────────────────
# Current lead card (left column)
# ─────────────────────────────────────────────────────────

def render_current_lead(lead: dict) -> None:
    if not lead:
        st.info("🎉 Queue Empty! Score your existing leads first.")
        return

    score        = _safe_int(lead.get("opportunity_score", 0))
    fit_score    = _safe_int(lead.get("fit_score", 0))
    audit_score  = _safe_int(lead.get("website_audit_score", 0))
    lead_priority = (lead.get("lead_priority") or "unscored").lower()
    wa            = _wa_status(lead)

    name     = lead.get("business_name", "Unknown")
    phone    = lead.get("phone") or "No phone"
    email    = lead.get("email") or "No email"
    website  = lead.get("website") or "No website"
    industry = lead.get("industry") or "Unknown"
    city     = lead.get("city") or ""
    country  = lead.get("country") or ""
    source   = lead.get("source") or "unknown"
    decision_maker  = lead.get("decision_maker_name") or lead.get("decision_maker_first") or "Not found"
    fit_reason      = lead.get("fit_reason") or "No fit reason available yet."
    best_channel    = lead.get("best_channel") or "manual"
    opener          = lead.get("recommended_opener") or ""
    pain_points     = _parse_json_list(lead.get("pain_points"))
    routing_reason  = lead.get("routing_reason") or ""

    fit_lbl  = get_fit_label(fit_score)
    ch_lbl   = get_channel_label(best_channel)
    wa_gate  = _wa_gate(lead)
    completeness = get_contact_completeness(lead)

    a_color = (
        "#ef4444" if audit_score <= 2 else
        "#f97316" if audit_score <= 4 else
        "#f59e0b" if audit_score <= 6 else
        "#22c55e" if audit_score <= 8 else
        "#3b82f6"
    )
    a_label = (
        "Critical" if audit_score <= 2 else
        "Poor"     if audit_score <= 4 else
        "Below Avg" if audit_score <= 6 else
        "Average"  if audit_score <= 8 else
        "Strong"
    )
    color = "#ef4444" if score >= 70 else "#f59e0b" if score >= 50 else "#38bdf8"
    heat  = "🔥 Hot Lead" if score >= 70 else "⚡ Warm Lead" if score >= 50 else "❄️ Cold Lead"

    priority_color = {
        "high": "#2ed573", "medium": "#FFA502",
        "low": "#747D8C", "unscored": "#94a3b8",
    }.get(lead_priority, "#94a3b8")
    priority_text = {
        "high": "HIGH PRIORITY", "medium": "MEDIUM PRIORITY",
        "low": "LOW PRIORITY", "unscored": "UNSCORED",
    }.get(lead_priority, "UNSCORED")

    wa_badge_color = (
        "#25D366" if wa in {"verified", "opted_in"}
        else "#f59e0b" if wa in {"estimated", "business_confirmed"}
        else "#64748b"
    )
    wa_badge_text = _lead_wa_badge(lead)

    # WA notice block
    if wa in {"verified", "opted_in"}:
        wa_notice = (
            '<div style="background:rgba(34,197,94,0.10);'
            'border:1px solid rgba(34,197,94,0.24);'
            'border-radius:14px;padding:14px;margin-bottom:12px;">'
            '<div style="color:#22c55e;font-size:13px;font-weight:800;">'
            '✅ WhatsApp verified for this lead</div></div>'
        )
    elif wa in {"estimated", "business_confirmed"}:
        wa_notice = (
            '<div style="background:rgba(245,158,11,0.10);'
            'border:1px solid rgba(245,158,11,0.24);'
            'border-radius:14px;padding:14px;margin-bottom:12px;">'
            '<div style="color:#f59e0b;font-size:13px;font-weight:800;">'
            '💬 WhatsApp estimated — please confirm before sending.</div></div>'
        )
    else:
        wa_notice = (
            '<div style="background:rgba(245,158,11,0.12);'
            'border:1px solid rgba(245,158,11,0.25);'
            'border-radius:14px;padding:14px;margin-bottom:12px;">'
            '<div style="color:#f59e0b;font-size:13px;font-weight:800;">'
            '📵 WhatsApp not confirmed — use verification panel on the right.</div>'
            f'<div style="color:#cbd5e1;font-size:13px;line-height:1.6;margin-top:6px;">'
            f'{_esc(wa_gate.get("reason", ""))}</div></div>'
        )

    # Pain points HTML
    if pain_points:
        pain_html = "<div style='display:flex;flex-wrap:wrap;gap:8px;'>"
        for p in pain_points[:6]:
            pain_html += (
                f'<span style="background:rgba(255,255,255,0.05);'
                f'border:1px solid rgba(255,255,255,0.08);color:#cbd5e1;'
                f'padding:5px 10px;border-radius:999px;font-size:11px;'
                f'font-weight:700;">{_esc(p)}</span>'
            )
        pain_html += "</div>"
    else:
        pain_html = (
            '<div style="color:#94a3b8;font-size:13px;">'
            'No pain points returned yet.</div>'
        )

    completeness_pct = _safe_float(completeness.get("percentage", 0))

    card(
        f'<div style="display:flex;justify-content:space-between;'
        f'align-items:flex-start;margin-bottom:20px;flex-wrap:wrap;gap:12px;">'
        f'<div>'
        f'<div style="font-size:24px;font-weight:900;color:white;margin-bottom:8px;">'
        f'{_esc(name)}</div>'
        f'<div style="display:flex;gap:8px;flex-wrap:wrap;">'
        f'<span style="background:rgba(91,140,255,0.13);'
        f'border:1px solid rgba(255,255,255,0.08);color:#cbd5e1;'
        f'padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700;">'
        f'📋 {_esc(source.replace("_", " ").title())}</span>'
        f'<span style="background:rgba(255,255,255,0.05);'
        f'border:1px solid rgba(255,255,255,0.08);color:#cbd5e1;'
        f'padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700;">'
        f'{_esc(industry)}</span>'
        f'<span style="background:{fit_lbl["bg"]};'
        f'border:1px solid {fit_lbl["color"]}44;color:{fit_lbl["color"]};'
        f'padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700;">'
        f'{fit_lbl["label"]} · {fit_score}/10</span>'
        f'<span style="background:{ch_lbl["bg"]};'
        f'border:1px solid {ch_lbl["color"]}44;color:{ch_lbl["color"]};'
        f'padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700;">'
        f'{ch_lbl["label"]}</span>'
        f'<span style="background:{priority_color}22;'
        f'border:1px solid {priority_color}44;color:{priority_color};'
        f'padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700;">'
        f'{_esc(priority_text)}</span>'
        f'<span style="background:rgba(255,255,255,0.05);'
        f'border:1px solid rgba(255,255,255,0.08);color:#cbd5e1;'
        f'padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700;">'
        f'{_esc(heat)}</span>'
        f'<span style="background:{wa_badge_color}22;'
        f'border:1px solid {wa_badge_color}44;color:{wa_badge_color};'
        f'padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700;">'
        f'{_esc(wa_badge_text)}</span>'
        f'</div></div>'
        f'<div style="text-align:right;">'
        f'<div style="font-size:48px;font-weight:900;color:{color};line-height:1;">'
        f'{score}</div>'
        f'<div style="color:#94a3b8;font-size:10px;letter-spacing:1px;font-weight:700;">'
        f'OPPORTUNITY SCORE</div>'
        f'<div style="margin-top:6px;color:{fit_lbl["color"]};font-size:13px;font-weight:800;">'
        f'FIT {fit_score}/10</div>'
        f'</div></div>'
        f'{wa_notice}'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;'
        f'padding:12px;margin-bottom:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">📋 Routing Decision</div>'
        f'<div style="color:#cbd5e1;font-size:13px;line-height:1.6;">'
        f'{_esc(routing_reason)}</div></div>'
        f'<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:14px;">'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Urgency</div>'
        f'<div style="color:white;font-size:18px;font-weight:800;">'
        f'{_safe_int(lead.get("urgency_score", 0))}/100</div></div>'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Reachability</div>'
        f'<div style="color:white;font-size:18px;font-weight:800;">'
        f'{_safe_int(lead.get("reachability_score", 0))}/100</div></div>'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Decision Maker</div>'
        f'<div style="color:white;font-size:14px;font-weight:700;">'
        f'{_esc(decision_maker)}</div></div>'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Contact</div>'
        f'<div style="color:white;font-size:18px;font-weight:800;">'
        f'{completeness_pct:.0f}%</div></div>'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);'
        f'border-top:3px solid {a_color};border-radius:14px;padding:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Website Audit</div>'
        f'<div style="color:{a_color};font-size:18px;font-weight:800;">{audit_score}/10</div>'
        f'<div style="color:#64748b;font-size:10px;margin-top:4px;">{_esc(a_label)}</div></div>'
        f'</div>'
        f'<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:14px;">'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">📞 Phone</div>'
        f'<div style="color:white;font-size:14px;font-weight:700;">{_esc(phone)}</div></div>'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">📧 Email</div>'
        f'<div style="color:white;font-size:13px;font-weight:600;word-break:break-all;">'
        f'{_esc(email)}</div></div>'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">📍 Location</div>'
        f'<div style="color:white;font-size:13px;font-weight:600;">'
        f'{_esc(city)} {_esc(country)}</div></div>'
        f'</div>'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;'
        f'padding:14px;margin-bottom:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">🌐 Website</div>'
        f'<div style="color:white;font-size:13px;font-weight:600;">{_esc(website)}</div></div>'
        f'<div style="background:rgba(17,24,39,0.55);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;'
        f'padding:14px;margin-bottom:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Why this lead</div>'
        f'<div style="color:white;font-size:13px;line-height:1.7;">{_esc(fit_reason)}</div></div>'
        f'<div style="background:rgba(37,211,102,0.08);'
        f'border:1px solid rgba(37,211,102,0.18);border-radius:14px;'
        f'padding:14px;margin-bottom:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">'
        f'Recommended Opener</div>'
        f'<div style="color:white;font-size:14px;line-height:1.7;font-weight:700;">'
        f'{_esc(opener or get_call_script_fallback(lead))}</div></div>'
        f'<div style="background:rgba(255,255,255,0.03);'
        f'border:1px solid rgba(255,255,255,0.06);border-radius:14px;'
        f'padding:14px;margin-bottom:14px;">'
        f'<div style="color:#94a3b8;font-size:10px;font-weight:700;'
        f'text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;">Pain Points</div>'
        f'{pain_html}</div>',
        border_color=color,
    )


# ─────────────────────────────────────────────────────────
# Call script
# ─────────────────────────────────────────────────────────

def render_call_script(lead: dict) -> None:
    section_header("AI-Powered Call Script", "Use the opener first, then follow the flow")
    opener = lead.get("recommended_opener") or get_call_script_fallback(lead)
    st.markdown(
        f'<div style="background:linear-gradient(135deg,'
        f'rgba(17,24,39,0.95),rgba(24,33,52,0.95));'
        f'border:1px solid rgba(255,255,255,0.07);'
        f'border-radius:16px;padding:20px;white-space:pre-wrap;'
        f'color:#e2e8f0;font-size:13px;line-height:1.8;">'
        f'{_esc(opener)}</div>',
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────
# Outcome logger
# ─────────────────────────────────────────────────────────

def render_outcome_logger(lead: dict, idx: int, queue: list) -> None:
    with st.container():
        section_header("Log Call Outcome", "Record what happened on this call")

        outcome = st.radio(
            "Outcome",
            options=[
                "📞 Called — No Answer",
                "🔄 Callback Requested",
                "✅ Interested",
                "❌ Not Interested",
                "💰 Deal Closed",
                "🚫 Wrong Number",
            ],
            label_visibility="collapsed",
            key=f"outcome_{lead.get('id', idx)}",
        )

        notes = st.text_area(
            "Call Notes",
            placeholder="What did they say? Objections? Next steps?",
            height=100,
            key=f"notes_{lead.get('id', idx)}",
        )

        deal_value = 0.0
        if "Deal Closed" in outcome:
            deal_value = float(
                st.number_input(
                    "Deal Value (₦)",
                    min_value=0,
                    value=300000,
                    step=10000,
                    key=f"deal_{lead.get('id', idx)}",
                )
            )

        status_map = {
            "📞 Called — No Answer": "called",
            "🔄 Callback Requested":  "callback",
            "✅ Interested":          "interested",
            "❌ Not Interested":      "not_interested",
            "💰 Deal Closed":         "deal_closed",
            "🚫 Wrong Number":        "wrong_number",
        }

        c1, c2, c3 = st.columns(3)
        with c1:
            if st.button(
                "💾 Save & Next",
                use_container_width=True,
                type="primary",
                key=f"save_{lead.get('id', idx)}",
            ):
                log_call_outcome(
                    lead=lead,
                    status=status_map.get(outcome, "called"),
                    notes=notes,
                    deal_value=deal_value,
                )
                st.session_state["call_idx"] = idx + 1
                st.success("✅ Outcome saved.")
                st.rerun()
        with c2:
            if st.button(
                "⏭️ Skip Lead",
                use_container_width=True,
                key=f"skip_{lead.get('id', idx)}",
            ):
                st.session_state["call_idx"] = idx + 1
                st.rerun()
        with c3:
            if st.button(
                "🔙 Previous",
                use_container_width=True,
                key=f"prev_{lead.get('id', idx)}",
            ):
                st.session_state["call_idx"] = max(0, idx - 1)
                st.rerun()


# ─────────────────────────────────────────────────────────
# Queue panel
# FIX: progress bar clamped to 0.0–1.0
# ─────────────────────────────────────────────────────────

def render_queue_panel(queue: list, idx: int) -> None:
    with st.container():
        section_header("Lead Queue", f"{len(queue)} leads ready to call")

        c1, c2 = st.columns(2)
        with c1:
            new_idx = st.number_input(
                "Jump to Lead #",
                min_value=1,
                max_value=max(len(queue), 1),
                value=idx + 1,
                step=1,
                key="queue_jump",
            )
            if new_idx - 1 != idx:
                st.session_state["call_idx"] = new_idx - 1
                st.rerun()
        with c2:
            st.metric("Progress", f"{idx + 1} / {len(queue)}")

        # FIX: clamp to 0.0–1.0 float
        progress_frac = max(0.0, min(1.0, float(idx + 1) / float(max(len(queue), 1))))
        st.progress(progress_frac)
        st.markdown("---")


# ─────────────────────────────────────────────────────────
# Prospect table / history / deals
# ─────────────────────────────────────────────────────────

def render_prospect_table() -> None:
    section_header("AI Prospect Queue", "Leads the AI thinks are best to call first")
    prospects = get_ai_prospects(limit=100)
    if not prospects:
        st.info("No scored prospects yet.")
        return
    st.dataframe(
        pd.DataFrame(prospects),
        use_container_width=True,
        hide_index=True,
        height=480,
    )


def render_call_history() -> None:
    section_header("Call History", "All outreach activity")
    rows = get_outreach_history(limit=100)
    if not rows:
        st.info("No calls logged yet.")
        return
    st.dataframe(
        pd.DataFrame(rows),
        use_container_width=True,
        hide_index=True,
        height=400,
    )


def render_deals_panel() -> None:
    section_header("Closed Deals", "Revenue from closed opportunities")
    df = get_deals_data()
    if df.empty:
        st.info("No deals closed yet.")
        return
    st.dataframe(df, use_container_width=True, hide_index=True, height=400)


# ─────────────────────────────────────────────────────────
# Main render — single entry point
# ─────────────────────────────────────────────────────────

def render_call_center() -> None:
    # FIX: CSS injected here, not at module level
    _render_page_css()

    render_hero()

    stats = get_stats()

    # FIX: isinstance guards for dict stats
    by_country = stats.get("by_country") or {}
    by_market  = stats.get("by_market") or {}
    if not isinstance(by_country, dict):
        by_country = {}
    if not isinstance(by_market, dict):
        by_market = {}

    country_options = ["All"] + sorted(
        {str(k).strip() for k in by_country.keys() if str(k).strip()}
    )
    market_options = ["All"] + sorted(
        {str(k).strip() for k in by_market.keys() if str(k).strip()}
    )
    wa_options      = ["All", "verified", "estimated", "business_confirmed", "opted_in", "unknown"]
    channel_options = ["All", "whatsapp", "ai_call", "email", "manual"]

    q1, q2, q3, q4 = st.columns(4)
    with q1:
        queue_country = st.selectbox(
            "Country Filter", country_options, index=0, key="queue_country"
        )
    with q2:
        queue_market = st.selectbox(
            "Market Filter", market_options, index=0, key="queue_market"
        )
    with q3:
        queue_channel = st.selectbox(
            "Channel Filter", channel_options, index=0, key="queue_channel"
        )
    with q4:
        queue_wa = st.selectbox(
            "WA Status Filter", wa_options, index=0, key="queue_wa"
        )

    render_pipeline_kpis()
    st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)
    render_intelligence_kpis()
    st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)

    render_scoring_banner(queue_country=queue_country, queue_market=queue_market)
    st.markdown("<div style='height:22px'></div>", unsafe_allow_html=True)

    tabs = st.tabs([
        "📞 Call Queue",
        "🧠 AI Prospects",
        "📋 Call History",
        "💰 Closed Deals",
    ])

    with tabs[0]:
        queue = get_call_queue()
        queue = [
            lead for lead in queue
            if _lead_matches_filters(
                lead,
                country=queue_country,
                market=queue_market,
                channel=queue_channel,
                wa_status=queue_wa,
            )
        ]

        st.caption(
            "Prospects ranked by AI fit score, urgency, reachability, "
            "country/market and best outreach channel."
        )

        if not queue:
            st.info(
                "🎉 Queue Empty! No call-ready prospects found. "
                "Score your existing leads first."
            )
        else:
            if "call_idx" not in st.session_state:
                st.session_state["call_idx"] = 0

            idx  = min(st.session_state["call_idx"], len(queue) - 1)
            lead = queue[idx]
            wa_gate = _wa_gate(lead)

            left, right = st.columns([1.5, 1], gap="large")

            with left:
                section_header(
                    f"Lead {idx + 1} of {len(queue)}",
                    "Current outreach target",
                )
                render_current_lead(lead)
                st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)
                render_call_script(lead)

            with right:
                # Verification panel always shown if phone present
                if wa_gate["can_check"]:
                    render_whatsapp_manual_tools(lead, wa_gate, key_suffix="_right")

                # Composer shown only for verified or estimated
                if wa_gate["show_composer"]:
                    render_whatsapp_composer(lead, wa_gate)

                # Call link
                raw_phone  = str(lead.get("phone") or "").strip()
                call_ready = _safe_int(lead.get("call_ready", 0))
                if raw_phone and call_ready:
                    phone_for_tel = _normalize_phone_for_whatsapp(
                        raw_phone, str(lead.get("country") or "")
                    )
                    if phone_for_tel:
                        st.markdown(
                            f'<a href="tel:+{phone_for_tel}" '
                            f'style="display:inline-block;background:#2563EB;'
                            f'color:white;padding:10px 20px;border-radius:14px;'
                            f'font-weight:700;font-size:13px;text-decoration:none;'
                            f'margin-bottom:12px;">'
                            f'📞 Call: {_esc(raw_phone)}</a>',
                            unsafe_allow_html=True,
                        )

                st.markdown("---")
                render_queue_panel(queue, idx)
                st.markdown("---")
                render_outcome_logger(lead, idx, queue)

    with tabs[1]:
        render_prospect_table()

    with tabs[2]:
        render_call_history()

    with tabs[3]:
        render_deals_panel()


def render() -> None:
    """Streamlit page entry point."""
    render_call_center()
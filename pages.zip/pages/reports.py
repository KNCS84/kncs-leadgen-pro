# pages/reports.py
# KNCS LeadGen Pro — v9.6
# Reports, exports, performance breakdowns, geography, markets,
# WhatsApp states, and revenue / outreach summaries.

from __future__ import annotations

from datetime import datetime
from textwrap import dedent
import html
import json

import pandas as pd
import streamlit as st

# ─────────────────────────────────────────────────────────
# Safe imports
# ─────────────────────────────────────────────────────────
try:
    from database import (
        get_connection,
        get_dashboard_stats,
        get_all_leads,
        get_top_prospects,
        get_whatsapp_ready_leads,
        get_whatsapp_verified_leads,
        get_whatsapp_estimated_leads,
        get_ai_call_ready_leads,
        get_email_ready_leads,
        get_call_ready_leads,
        get_manual_review_leads,
        get_leads_by_country,
        get_leads_by_market,
        get_outreach_history,
        get_lead_by_id,
    )
except Exception:
    get_connection = None

    def get_dashboard_stats():
        return {}

    def get_all_leads(*args, **kwargs):
        return []

    def get_top_prospects(limit=100):
        return []

    def get_whatsapp_ready_leads(limit=100):
        return []

    def get_whatsapp_verified_leads(limit=100):
        return []

    def get_whatsapp_estimated_leads(limit=100):
        return []

    def get_ai_call_ready_leads(limit=100):
        return []

    def get_email_ready_leads(limit=100):
        return []

    def get_call_ready_leads(limit=100):
        return []

    def get_manual_review_leads(limit=100):
        return []

    def get_leads_by_country(country, limit=100):
        return []

    def get_leads_by_market(market, limit=100):
        return []

    def get_outreach_history(lead_id):
        return []

    def get_lead_by_id(lead_id):
        return {}


# ─────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────
def _safe_int(value, default=0):
    try:
        if value is None:
            return default
        return int(value)
    except Exception:
        return default


def _safe_float(value, default=0.0):
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        return default


def _esc(value) -> str:
    return html.escape(str(value if value is not None else ""))


def _norm(value) -> str:
    return str(value or "").strip().lower()


def _fmt_money(value):
    try:
        v = float(value or 0)
        if v.is_integer():
            return f"₦{int(v):,}"
        return f"₦{v:,.2f}"
    except Exception:
        return "₦0"


def _short(value, length: int = 90) -> str:
    text = str(value or "").strip()
    if len(text) <= length:
        return text
    return text[: length - 1].rstrip() + "…"


def _parse_json_list(value):
    if isinstance(value, list):
        return value
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return parsed
        except Exception:
            pass
        return [p.strip() for p in text.split(",") if p.strip()]
    return [str(value)]


def _safe_call(fn, default):
    try:
        return fn()
    except Exception:
        return default


def _table_from_dict(data: dict, key_name: str, value_name: str) -> pd.DataFrame:
    rows = [
        {key_name: k, value_name: _safe_int(v)}
        for k, v in sorted((data or {}).items(), key=lambda x: _safe_int(x[1]), reverse=True)
        if str(k).strip()
    ]
    return pd.DataFrame(rows)


def _render_card(label: str, value: str, subtitle: str, accent: str, icon: str):
    st.markdown(
        dedent(f"""
        <div style="
            background:linear-gradient(180deg,rgba(20,26,39,0.96),rgba(14,19,31,0.96));
            border:1px solid rgba(255,255,255,0.08);
            border-top:3px solid {accent};
            border-radius:18px;
            padding:14px 14px 12px 14px;
            min-height:108px;
            box-shadow:0 12px 26px rgba(0,0,0,0.16);
        ">
            <div style="font-size:22px;margin-bottom:8px;">{icon}</div>
            <div style="color:#8b97ad;font-size:11px;letter-spacing:0.14em;
            text-transform:uppercase;margin-bottom:6px;">{label}</div>
            <div style="color:#f4f7fb;font-size:30px;font-weight:800;
            line-height:1.0;margin-bottom:4px;">{value}</div>
            <div style="color:#93a0b7;font-size:12px;">{subtitle}</div>
        </div>
        """),
        unsafe_allow_html=True,
    )


def _section(title: str, subtitle: str = ""):
    sub_html = (
        f'<div style="margin-top:6px;color:#94a3b8;font-size:13px;">{_esc(subtitle)}</div>'
        if subtitle else ""
    )
    st.markdown(
        dedent(f"""
        <div style="margin-bottom:16px;">
            <div style="font-size:22px;font-weight:800;color:white;letter-spacing:-0.5px;">
                {_esc(title)}
            </div>
            {sub_html}
        </div>
        """),
        unsafe_allow_html=True,
    )


def _get_revenue_rows(limit: int = 100) -> list[dict]:
    if get_connection is None:
        return []
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT
                id, lead_id, business_name, amount, service_type,
                payment_status, notes, closed_at
            FROM revenue
            ORDER BY datetime(closed_at) DESC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(r) for r in cursor.fetchall()]
    except Exception:
        return []
    finally:
        try:
            if conn:
                conn.close()
        except Exception:
            pass


def _get_call_rows(limit: int = 100) -> list[dict]:
    if get_connection is None:
        return []
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT
                id, lead_id, status, notes,
                duration_seconds, called_at
            FROM call_log
            ORDER BY datetime(called_at) DESC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(r) for r in cursor.fetchall()]
    except Exception:
        return []
    finally:
        try:
            if conn:
                conn.close()
        except Exception:
            pass


def _get_pipeline_rows(limit: int = 200) -> list[dict]:
    return _safe_call(lambda: get_all_leads(limit=limit), []) or []


def _wa_status(lead: dict) -> str:
    status = _norm(
        lead.get("wa_status")
        or lead.get("verification_status")
        or ("verified" if _safe_int(lead.get("whatsapp_verified", 0)) else "")
    )
    if status in {"verified", "opted_in", "estimated", "business_confirmed", "unknown"}:
        return status
    if _safe_int(lead.get("wa_verified", 0)) or _safe_int(lead.get("whatsapp_verified", 0)):
        return "verified"
    if _safe_int(lead.get("whatsapp_ready", 0)):
        return "estimated"
    return "unknown"


# ─────────────────────────────────────────────────────────
# Hero
# ─────────────────────────────────────────────────────────
def render_hero():
    stats = get_dashboard_stats() or {}
    now = datetime.now()

    total = _safe_int(stats.get("total_leads", 0))
    high_fit = _safe_int(stats.get("high_fit_leads", 0))
    unscored = _safe_int(stats.get("unscored_leads", 0))
    wa_verified = _safe_int(stats.get("whatsapp_verified", 0))
    wa_estimated = _safe_int(stats.get("whatsapp_estimated", 0))
    revenue = stats.get("total_revenue", 0) or 0

    st.markdown(
        dedent(f"""
        <div style="
            background:linear-gradient(180deg,rgba(17,24,39,0.96),rgba(10,14,24,0.96));
            border:1px solid rgba(255,255,255,0.08);
            border-radius:22px;
            padding:22px 24px;
            box-shadow:0 18px 40px rgba(0,0,0,0.20);
            margin-bottom:20px;
        ">
            <div style="display:flex;justify-content:space-between;gap:20px;align-items:flex-start;">
                <div>
                    <div style="color:#7f8aa3;text-transform:uppercase;letter-spacing:0.18em;font-size:11px;margin-bottom:8px;">
                        Reporting Center
                    </div>
                    <div style="color:#f4f7fb;font-size:34px;font-weight:800;margin:0;line-height:1.1;">
                        Lead performance, geography, WA states, and revenue
                    </div>
                    <div style="color:#93a0b7;font-size:14px;margin-top:10px;">
                        Snapshot generated live from SQLite • {now.strftime("%A, %d %B %Y, %H:%M:%S")}
                    </div>
                </div>
                <div style="text-align:right;min-width:220px;">
                    <div style="color:#7f8aa3;text-transform:uppercase;letter-spacing:0.18em;font-size:11px;margin-bottom:4px;">
                        Revenue Pipeline
                    </div>
                    <div style="color:#f4f7fb;font-size:34px;font-weight:800;line-height:1;">
                        {_fmt_money(revenue)}
                    </div>
                </div>
            </div>
        </div>
        """),
        unsafe_allow_html=True,
    )

    row1 = st.columns(6)
    with row1[0]:
        _render_card("Total Leads", f"{total:,}", "All leads in DB", "#4c7dff", "📊")
    with row1[1]:
        _render_card("High Fit", f"{high_fit:,}", "Priority prospects", "#22c55e", "🎯")
    with row1[2]:
        _render_card("Unscored", f"{unscored:,}", "Needs scoring", "#60a5fa", "🧠")
    with row1[3]:
        _render_card("WA Verified", f"{wa_verified:,}", "Confirmed WhatsApp", "#25d366", "✅")
    with row1[4]:
        _render_card("WA Estimated", f"{wa_estimated:,}", "Heuristic WA", "#f59e0b", "🟡")
    with row1[5]:
        _render_card("Revenue", _fmt_money(revenue), "Closed deals", "#8b5cf6", "💰")


# ─────────────────────────────────────────────────────────
# Summary sections
# ─────────────────────────────────────────────────────────
def render_quality_breakdown(stats: dict):
    _section("Lead Quality", "Scoring and outreach readiness")

    high_fit = _safe_int(stats.get("high_fit_leads", 0))
    medium_fit = _safe_int(stats.get("medium_fit_leads", 0))
    low_fit = _safe_int(stats.get("low_fit_leads", 0))
    unscored = _safe_int(stats.get("unscored_leads", 0))

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        _render_card("High Fit", f"{high_fit:,}", "Fit >= 8", "#22c55e", "⭐")
    with c2:
        _render_card("Medium Fit", f"{medium_fit:,}", "Fit 5–7", "#f59e0b", "🟡")
    with c3:
        _render_card("Low Fit", f"{low_fit:,}", "Fit 1–4", "#64748b", "⚪")
    with c4:
        _render_card("Unscored", f"{unscored:,}", "Pending AI or fallback", "#60a5fa", "🧠")

    st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)

    by_scoring = stats.get("by_scoring_status", {}) or {}
    if by_scoring:
        st.dataframe(
            _table_from_dict(by_scoring, "scoring_status", "leads"),
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.info("No scoring status breakdown yet.")


def render_geography_breakdown(stats: dict):
    _section("Geography", "Countries, markets and city concentration")

    by_country = stats.get("by_country", {}) or {}
    by_market = stats.get("by_market", {}) or {}
    top_countries = _table_from_dict(by_country, "country", "leads")
    top_markets = _table_from_dict(by_market, "market", "leads")

    left, right = st.columns(2)
    with left:
        st.markdown("#### Top Countries")
        if not top_countries.empty:
            st.dataframe(top_countries, use_container_width=True, hide_index=True, height=320)
        else:
            st.info("No country data yet.")
    with right:
        st.markdown("#### Top Markets")
        if not top_markets.empty:
            st.dataframe(top_markets, use_container_width=True, hide_index=True, height=320)
        else:
            st.info("No market data yet.")

    st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)

    top_cities = _safe_call(lambda: _get_top_countries(limit=0), [])  # intentional fallback placeholder
    cities = _safe_call(lambda: _get_top_cities(limit=5), []) or []
    if cities:
        st.markdown("#### Top Cities")
        st.dataframe(pd.DataFrame(cities), use_container_width=True, hide_index=True)
    else:
        st.info("No city data yet.")


def render_whatsapp_breakdown(stats: dict):
    _section("WhatsApp States", "Verified vs estimated vs unknown")

    wa_verified = _safe_int(stats.get("whatsapp_verified", 0))
    wa_estimated = _safe_int(stats.get("whatsapp_estimated", 0))
    wa_ready = _safe_int(stats.get("whatsapp_ready", 0))
    wa_opt_in = _safe_int(stats.get("wa_opt_in", 0))
    call_ready = _safe_int(stats.get("call_ready", 0))
    email_ready = _safe_int(stats.get("email_ready", 0))
    manual_review = _safe_int(stats.get("manual_review_needed", 0))

    c1, c2, c3, c4, c5, c6 = st.columns(6)
    with c1:
        _render_card("WA Verified", f"{wa_verified:,}", "Confirmed only", "#25d366", "✅")
    with c2:
        _render_card("WA Estimated", f"{wa_estimated:,}", "Heuristic only", "#f59e0b", "🟡")
    with c3:
        _render_card("WA Ready", f"{wa_ready:,}", "All WA-ready", "#22c55e", "💬")
    with c4:
        _render_card("WA Opt-In", f"{wa_opt_in:,}", "Explicit consent", "#0ea5e9", "📩")
    with c5:
        _render_card("Call Ready", f"{call_ready:,}", "Valid phone", "#3b82f6", "📞")
    with c6:
        _render_card("Manual Review", f"{manual_review:,}", "Research needed", "#fb7185", "🔍")

    st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)

    by_wa_status = stats.get("by_wa_status", {}) or {}
    if by_wa_status:
        st.dataframe(
            _table_from_dict(by_wa_status, "wa_status", "leads"),
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.info("No WhatsApp state breakdown yet.")


def render_channel_breakdown(stats: dict):
    _section("Channels", "Best channel and source coverage")

    by_channel = stats.get("by_channel", {}) or {}
    by_source = stats.get("by_source", {}) or {}

    left, right = st.columns(2)
    with left:
        st.markdown("#### Best Channel")
        if by_channel:
            st.dataframe(
                _table_from_dict(by_channel, "channel", "leads"),
                use_container_width=True,
                hide_index=True,
                height=320,
            )
        else:
            st.info("No channel data yet.")

    with right:
        st.markdown("#### Source Breakdown")
        if by_source:
            st.dataframe(
                _table_from_dict(by_source, "source", "leads"),
                use_container_width=True,
                hide_index=True,
                height=320,
            )
        else:
            st.info("No source data yet.")


def render_pipeline_breakdown(stats: dict):
    _section("Pipeline", "Status counts and outreach readiness")

    pipeline = stats.get("pipeline", {}) or {}
    if pipeline:
        st.dataframe(
            _table_from_dict(pipeline, "status", "leads"),
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.info("No pipeline data yet.")

    st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)

    ready_rows = [
        {"queue": "WhatsApp Ready", "count": _safe_int(stats.get("whatsapp_ready", 0))},
        {"queue": "WhatsApp Verified", "count": _safe_int(stats.get("whatsapp_verified", 0))},
        {"queue": "WhatsApp Estimated", "count": _safe_int(stats.get("whatsapp_estimated", 0))},
        {"queue": "AI Call Ready", "count": _safe_int(stats.get("ai_call_ready", 0))},
        {"queue": "Email Ready", "count": _safe_int(stats.get("email_ready", 0))},
        {"queue": "Call Ready", "count": _safe_int(stats.get("call_ready", 0))},
        {"queue": "Manual Review", "count": _safe_int(stats.get("manual_review_needed", 0))},
    ]
    st.dataframe(pd.DataFrame(ready_rows), use_container_width=True, hide_index=True)


def render_revenue_breakdown():
    _section("Revenue", "Closed deals and payments")

    revenue_rows = _get_revenue_rows(limit=200)
    if not revenue_rows:
        st.info("No revenue yet.")
        return

    df = pd.DataFrame(revenue_rows)
    if "amount" in df.columns:
        total = df["amount"].fillna(0).astype(float).sum()
    else:
        total = 0

    st.markdown(
        dedent(f"""
        <div style="
            background:linear-gradient(135deg,rgba(16,185,129,0.15),rgba(91,140,255,0.10));
            border:1px solid rgba(16,185,129,0.25);
            border-radius:16px;
            padding:20px;
            margin-bottom:18px;
        ">
            <div style="color:#94a3b8;font-size:12px;font-weight:700;
            text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">
                Total Revenue Closed
            </div>
            <div style="font-size:42px;font-weight:900;color:white;">
                {_fmt_money(total)}
            </div>
            <div style="color:#10b981;font-size:13px;margin-top:6px;font-weight:600;">
                From {len(df)} closed deal(s)
            </div>
        </div>
        """),
        unsafe_allow_html=True,
    )

    st.dataframe(df, use_container_width=True, hide_index=True, height=420)

    st.download_button(
        "📥 Export Revenue CSV",
        data=df.to_csv(index=False),
        file_name="revenue_report.csv",
        mime="text/csv",
        key="export_revenue_report",
    )


def render_outreach_breakdown():
    _section("Outreach History", "Calls, messages, and recent activity")

    call_rows = _get_call_rows(limit=100)
    if call_rows:
        call_df = pd.DataFrame(call_rows)
        st.markdown("#### Call Log")
        st.dataframe(call_df, use_container_width=True, hide_index=True, height=320)
    else:
        st.info("No call log entries yet.")

    st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)

    history = _safe_call(lambda: get_outreach_history(limit=100), []) or []
    if history:
        hist_df = pd.DataFrame(history)
        st.markdown("#### Outreach Log")
        st.dataframe(hist_df, use_container_width=True, hide_index=True, height=320)
    else:
        st.info("No outreach history yet.")


def render_exports():
    _section("Exports", "Download filtered lead queues")

    all_leads = _safe_call(lambda: get_all_leads(limit=5000), []) or []
    top_prospects = _safe_call(lambda: get_top_prospects(limit=500), []) or []
    wa_verified = _safe_call(lambda: get_whatsapp_verified_leads(limit=500), []) or []
    wa_estimated = _safe_call(lambda: get_whatsapp_estimated_leads(limit=500), []) or []
    ai_call_ready = _safe_call(lambda: get_ai_call_ready_leads(limit=500), []) or []
    email_ready = _safe_call(lambda: get_email_ready_leads(limit=500), []) or []
    call_ready = _safe_call(lambda: get_call_ready_leads(limit=500), []) or []
    manual_review = _safe_call(lambda: get_manual_review_leads(limit=500), []) or []

    def _df(rows):
        return pd.DataFrame(rows or [])

    tabs = st.tabs([
        "All Leads",
        "Top Prospects",
        "WA Verified",
        "WA Estimated",
        "AI Call",
        "Email",
        "Call Ready",
        "Manual Review",
    ])

    export_sets = [
        ("all_leads.csv", _df(all_leads)),
        ("top_prospects.csv", _df(top_prospects)),
        ("wa_verified.csv", _df(wa_verified)),
        ("wa_estimated.csv", _df(wa_estimated)),
        ("ai_call_ready.csv", _df(ai_call_ready)),
        ("email_ready.csv", _df(email_ready)),
        ("call_ready.csv", _df(call_ready)),
        ("manual_review.csv", _df(manual_review)),
    ]

    for tab, (fname, df) in zip(tabs, export_sets):
        with tab:
            if df.empty:
                st.info("No rows available.")
            else:
                st.dataframe(df, use_container_width=True, hide_index=True, height=320)
                st.download_button(
                    f"📥 Download {fname}",
                    data=df.to_csv(index=False),
                    file_name=fname,
                    mime="text/csv",
                    key=f"export_{fname}",
                )


def render_country_wa_tables():
    _section("Country + WA Tables", "Useful queue slices for operations")

    stats = get_dashboard_stats() or {}
    by_country = stats.get("by_country", {}) or {}
    by_market = stats.get("by_market", {}) or {}

    country_left, country_right = st.columns(2)
    with country_left:
        st.markdown("#### Country Split")
        if by_country:
            st.dataframe(
                _table_from_dict(by_country, "country", "leads"),
                use_container_width=True,
                hide_index=True,
                height=320,
            )
        else:
            st.info("No country split yet.")

    with country_right:
        st.markdown("#### Market Split")
        if by_market:
            st.dataframe(
                _table_from_dict(by_market, "market", "leads"),
                use_container_width=True,
                hide_index=True,
                height=320,
            )
        else:
            st.info("No market split yet.")


# ─────────────────────────────────────────────────────────
# Lead drilldowns
# ─────────────────────────────────────────────────────────
def render_lead_lookup():
    _section("Lead Lookup", "Inspect a lead and its outreach trail")

    if get_connection is None:
        st.info("Database connection unavailable.")
        return

    lead_id = st.number_input("Lead ID", min_value=1, step=1, value=1, key="report_lead_id")

    if st.button("Load Lead", use_container_width=True, key="load_report_lead"):
        lead = _safe_call(lambda: get_lead_by_id(int(lead_id)), {}) or {}
        if not lead:
            st.warning("No lead found with that ID.")
            return

        wa = _wa_status(lead)
        st.markdown(
            dedent(f"""
            <div style="
                background:linear-gradient(135deg,rgba(17,24,39,0.95),rgba(24,33,52,0.95));
                border:1px solid rgba(255,255,255,0.07);
                border-radius:16px;
                padding:18px 20px;
                margin-top:12px;
            ">
                <div style="color:white;font-size:18px;font-weight:800;margin-bottom:8px;">
                    {_esc(lead.get("business_name", "Unknown"))}
                </div>
                <div style="color:#94a3b8;font-size:13px;line-height:1.7;">
                    <b>Industry:</b> {_esc(lead.get("industry", ""))}<br/>
                    <b>Location:</b> {_esc(lead.get("city", ""))} {_esc(lead.get("country", ""))}<br/>
                    <b>Market:</b> {_esc(lead.get("market", ""))}<br/>
                    <b>Phone:</b> {_esc(lead.get("phone", ""))}<br/>
                    <b>Email:</b> {_esc(lead.get("email", ""))}<br/>
                    <b>Fit:</b> {_safe_int(lead.get("fit_score", 0))}/10<br/>
                    <b>Audit:</b> {_safe_int(lead.get("website_audit_score", 0))}/10<br/>
                    <b>Best Channel:</b> {_esc(lead.get("best_channel", ""))}<br/>
                    <b>WA Status:</b> {_esc(wa)}<br/>
                    <b>Routing Reason:</b> {_esc(lead.get("routing_reason", ""))}
                </div>
            </div>
            """),
            unsafe_allow_html=True,
        )

        history = _safe_call(lambda: get_outreach_history(int(lead_id)), []) or []
        if history:
            st.markdown("#### Outreach Trail")
            st.dataframe(pd.DataFrame(history), use_container_width=True, hide_index=True)
        else:
            st.info("No outreach logged for this lead yet.")


# ─────────────────────────────────────────────────────────
# Main render
# ─────────────────────────────────────────────────────────
def render_reports():
    render_hero()

    stats = get_dashboard_stats() or {}

    tabs = st.tabs([
        "📊 Overview",
        "🌍 Geography",
        "💬 Channels",
        "💰 Revenue",
        "📤 Exports",
        "🔎 Drilldown",
    ])

    with tabs[0]:
        render_quality_breakdown(stats)
        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        render_pipeline_breakdown(stats)

    with tabs[1]:
        render_geography_breakdown(stats)
        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        render_country_wa_tables()

    with tabs[2]:
        render_whatsapp_breakdown(stats)
        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        render_channel_breakdown(stats)
        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        render_outreach_breakdown()

    with tabs[3]:
        render_revenue_breakdown()

    with tabs[4]:
        render_exports()

    with tabs[5]:
        render_lead_lookup()


def render():
    render_reports()
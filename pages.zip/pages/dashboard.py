# pages/dashboard.py
# KNCS LeadGen Pro — v9.7 Premium
# Dashboard: country/market filters, WA verified vs estimated,
# batch scoring with correct progress (0.0–1.0), routing controls.

from __future__ import annotations

from datetime import datetime
from textwrap import dedent
import html
import json
from typing import Dict, List, Optional

import pandas as pd
import streamlit as st

# ─────────────────────────────────────────────────────────
# Safe imports (DB)
# ─────────────────────────────────────────────────────────
try:
    from database import (
        get_dashboard_stats,
        get_connection,
        apply_routing_update,
        get_top_prospects,
        get_whatsapp_ready_leads,
        get_whatsapp_verified_leads,
        get_whatsapp_estimated_leads,
        get_ai_call_ready_leads,
        get_email_ready_leads,
        get_leads_by_priority,
        get_unrouted_leads,
        get_leads_by_country,
        get_leads_by_market,
        get_manual_review_leads,
    )
    _DB_AVAILABLE = True
except Exception as _db_err:
    _DB_AVAILABLE = False
    get_connection = None
    apply_routing_update = None

    def get_dashboard_stats() -> dict:
        return {}

    def get_top_prospects(limit: int = 8) -> list:
        return []

    def get_whatsapp_ready_leads(limit: int = 8) -> list:
        return []

    def get_whatsapp_verified_leads(limit: int = 8) -> list:
        return []

    def get_whatsapp_estimated_leads(limit: int = 8) -> list:
        return []

    def get_ai_call_ready_leads(limit: int = 8) -> list:
        return []

    def get_email_ready_leads(limit: int = 8) -> list:
        return []

    def get_leads_by_priority(priority: str, limit: int = 8) -> list:
        return []

    def get_unrouted_leads(limit: int = 200) -> list:
        return []

    def get_leads_by_country(country: str, limit: int = 100) -> list:
        return []

    def get_leads_by_market(market: str, limit: int = 100) -> list:
        return []

    def get_manual_review_leads(limit: int = 50) -> list:
        return []


# ─────────────────────────────────────────────────────────
# Safe imports (Scorer)
# ─────────────────────────────────────────────────────────
try:
    from engine.scorer import score_and_save_lead, score_unscored_leads_batch
    _SCORER_AVAILABLE = True
except Exception:
    _SCORER_AVAILABLE = False

    def score_and_save_lead(lead_id: int) -> Optional[dict]:
        return None

    def score_unscored_leads_batch(limit: int = 50, use_ai: bool = True) -> dict:
        return {"total": 0, "scored": 0, "high": 0, "medium": 0, "low": 0}


# ─────────────────────────────────────────────────────────
# Safe imports (Router)
# ─────────────────────────────────────────────────────────
try:
    from engine.router import assign_channel as _router_assign_channel
    _ROUTER_AVAILABLE = True
except Exception:
    _ROUTER_AVAILABLE = False

    def _router_assign_channel(lead: dict) -> dict:
        return {}


# ─────────────────────────────────────────────────────────
# Safe imports (Jobs)
# ─────────────────────────────────────────────────────────
try:
    from engine.job_manager import (
        get_recent_jobs,
        get_running_job,
        get_job_status_summary,
    )
except Exception:
    def get_recent_jobs(limit: int = 5) -> list:
        return []

    def get_running_job() -> dict:
        return {}

    def get_job_status_summary(job_id) -> dict:
        return {
            "found": False,
            "status": "unknown",
            "progress": 0,
            "leads": 0,
            "message": "Job unavailable",
            "is_done": False,
            "is_running": False,
        }


# ─────────────────────────────────────────────────────────
# Utility helpers
# ─────────────────────────────────────────────────────────
def _safe_int(value, default: int = 0) -> int:
    """Convert any value to int safely."""
    try:
        return int(value) if value is not None else default
    except (ValueError, TypeError):
        return default


def _safe_float(value, default: float = 0.0) -> float:
    """Convert any value to float safely."""
    try:
        return float(value) if value is not None else default
    except (ValueError, TypeError):
        return default


def _safe_call(fn, default):
    """Call fn() and return default on any exception."""
    try:
        return fn()
    except Exception:
        return default


def _esc(value) -> str:
    """HTML-escape a value safely."""
    return html.escape(str(value if value is not None else ""))


def _truncate_text(value, max_len: int = 120) -> str:
    text = str(value or "").strip()
    if len(text) <= max_len:
        return text
    return text[: max_len - 1].rstrip() + "…"


def _parse_json_list(value) -> list:
    if isinstance(value, list):
        return value
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return parsed
        except Exception:
            pass
        return [p.strip() for p in text.split(",") if p.strip()]
    return [str(value)]


def _fmt_money(value) -> str:
    """Format a number as ₦ currency string."""
    try:
        # Guard against string sentinels like "none", "null", etc.
        if isinstance(value, str):
            value = value.strip().lower()
            if value in ("", "none", "null", "n/a"):
                return "₦0"
        v = float(value or 0)
        if v == int(v):
            return f"₦{int(v):,}"
        return f"₦{v:,.2f}"
    except (ValueError, TypeError):
        return "₦0"


def _norm(value) -> str:
    """Normalize to lowercase stripped string."""
    return str(value or "").strip().lower()


def _lead_wa_status(lead: dict) -> str:
    """
    Return canonical WA status string for a lead.
    Checks: wa_status → verification_status → wa_verified flag → whatsapp_verified flag
    Returns: verified | opted_in | estimated | business_confirmed | unknown
    """
    status = _norm(
        lead.get("wa_status")
        or lead.get("verification_status")
        or ""
    )
    if status in {"verified", "opted_in", "estimated", "business_confirmed", "unknown"}:
        return status

    # Legacy flag fallback
    if _safe_int(lead.get("wa_verified", 0)) or _safe_int(lead.get("whatsapp_verified", 0)):
        return "verified"
    if _safe_int(lead.get("whatsapp_ready", 0)):
        return "estimated"
    return "unknown"


def _lead_matches_filters(
    lead: dict,
    country: str = "All",
    market: str = "All",
    channel: str = "All",
    wa_status: str = "All",
    min_fit: int = 0,
    min_audit: int = 0,
) -> bool:
    """Return True if lead passes all active filters."""
    if min_fit and _safe_int(lead.get("fit_score", 0)) < min_fit:
        return False
    if min_audit and _safe_int(lead.get("website_audit_score", 0)) < min_audit:
        return False
    if country != "All" and _norm(lead.get("country")) != _norm(country):
        return False
    if market != "All" and _norm(lead.get("market")) != _norm(market):
        return False
    if channel != "All" and _norm(lead.get("best_channel")) != _norm(channel):
        return False
    lead_wa = _lead_wa_status(lead)
    if wa_status != "All" and lead_wa != _norm(wa_status):
        return False
    return True


def _apply_filters(
    rows: list,
    country: str,
    market: str,
    channel: str,
    wa_status: str,
    min_fit: int,
) -> list:
    """Filter a list of lead dicts using the provided filter values."""
    return [
        r for r in (rows or [])
        if _lead_matches_filters(
            r,
            country=country,
            market=market,
            channel=channel,
            wa_status=wa_status,
            min_fit=min_fit,
        )
    ]


# ─────────────────────────────────────────────────────────
# DB query helpers
# ─────────────────────────────────────────────────────────
def _get_top_cities(limit: int = 3) -> list:
    if get_connection is None:
        return []
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT place, COUNT(*) AS total
            FROM (
                SELECT
                    CASE
                        WHEN city IS NOT NULL AND TRIM(city) != '' THEN city
                        WHEN location IS NOT NULL AND TRIM(location) != '' THEN location
                        ELSE 'Unknown'
                    END AS place
                FROM leads
            )
            GROUP BY place
            ORDER BY total DESC, place ASC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(row) for row in cursor.fetchall()]
    except Exception:
        return []
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def _get_top_countries(limit: int = 5) -> list:
    if get_connection is None:
        return []
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT COALESCE(NULLIF(TRIM(country), ''), 'Unknown') AS country_name,
                   COUNT(*) AS total
            FROM leads
            GROUP BY country_name
            ORDER BY total DESC, country_name ASC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(row) for row in cursor.fetchall()]
    except Exception:
        return []
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def _get_top_markets(limit: int = 5) -> list:
    if get_connection is None:
        return []
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT COALESCE(NULLIF(TRIM(market), ''), 'Unknown') AS market_name,
                   COUNT(*) AS total
            FROM leads
            GROUP BY market_name
            ORDER BY total DESC, market_name ASC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(row) for row in cursor.fetchall()]
    except Exception:
        return []
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def _get_unscored_lead_ids(limit: int) -> list:
    """
    Return leads that genuinely need scoring.
    Uses IS NULL on fit_score and lead_priority to avoid
    treating score=0 (valid for bad leads) as unscored.
    """
    if get_connection is None:
        return []
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT id, business_name FROM leads
            WHERE fit_score IS NULL
               OR lead_priority IS NULL
               OR lead_priority = ''
            ORDER BY id ASC
            LIMIT ?
            """,
            (limit,),
        )
        return [
            {"id": row[0], "name": row[1] or "Unknown"}
            for row in cursor.fetchall()
        ]
    except Exception:
        return []
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


# ─────────────────────────────────────────────────────────
# Label helpers
# ─────────────────────────────────────────────────────────
def _get_priority_label(priority: str) -> tuple:
    p = (priority or "unscored").lower()
    labels = {
        "high": ("HIGH", "#2ed573"),
        "hot": ("HIGH", "#2ed573"),        # legacy alias
        "medium": ("MEDIUM", "#FFA502"),
        "warm": ("MEDIUM", "#FFA502"),     # legacy alias
        "low": ("LOW", "#747D8C"),
    }
    return labels.get(p, ("UNSCORED", "#94a3b8"))


def _get_channel_label(channel: str) -> tuple:
    c = (channel or "manual").lower()
    return {
        "whatsapp": ("WhatsApp", "#25D366"),
        "ai_call": ("AI Call", "#5352ED"),
        "email": ("Email", "#1E90FF"),
        "manual": ("Manual", "#747D8C"),
    }.get(c, ("Unknown", "#94a3b8"))


# ─────────────────────────────────────────────────────────
# Card render helpers
# ─────────────────────────────────────────────────────────
def _render_metric_card(
    label: str,
    value: str,
    subtitle: str,
    accent: str,
    icon: str,
) -> None:
    st.markdown(
        dedent(f"""
        <div style="
            background:linear-gradient(180deg,rgba(20,26,39,0.96),rgba(14,19,31,0.96));
            border:1px solid rgba(255,255,255,0.08);
            border-top:3px solid {accent};
            border-radius:18px;
            padding:14px 14px 12px 14px;
            min-height:108px;
            box-shadow:0 12px 26px rgba(0,0,0,0.16);
        ">
            <div style="font-size:22px;margin-bottom:8px;">{icon}</div>
            <div style="color:#8b97ad;font-size:11px;letter-spacing:0.14em;
            text-transform:uppercase;margin-bottom:6px;">{_esc(label)}</div>
            <div style="color:#f4f7fb;font-size:30px;font-weight:800;
            line-height:1.0;margin-bottom:4px;">{_esc(value)}</div>
            <div style="color:#93a0b7;font-size:12px;">{_esc(subtitle)}</div>
        </div>
        """),
        unsafe_allow_html=True,
    )


def _render_small_card(
    title: str,
    value: str,
    subtitle: str,
    accent: str,
    icon: str,
) -> None:
    st.markdown(
        dedent(f"""
        <div style="
            background:linear-gradient(180deg,rgba(20,26,39,0.96),rgba(14,19,31,0.96));
            border:1px solid rgba(255,255,255,0.08);
            border-top:3px solid {accent};
            border-radius:16px;
            padding:16px 14px;
            min-height:108px;
            box-shadow:0 12px 26px rgba(0,0,0,0.16);
        ">
            <div style="font-size:24px;margin-bottom:10px;">{icon}</div>
            <div style="color:#64748b;font-size:10px;font-weight:700;
            text-transform:uppercase;letter-spacing:1px;">{_esc(title)}</div>
            <div style="font-size:24px;font-weight:900;color:white;
            margin-top:6px;line-height:1;">{_esc(value)}</div>
            <div style="font-size:11px;color:{accent};margin-top:6px;
            font-weight:600;">{_esc(subtitle)}</div>
        </div>
        """),
        unsafe_allow_html=True,
    )


def _render_spotlight_card(lead: dict, channel_color: str) -> None:
    """Render a detailed spotlight card for a single lead."""
    fit_score      = _safe_int(lead.get("fit_score", 0))
    urgency        = _safe_int(lead.get("urgency_score", 0))
    reachability   = _safe_int(lead.get("reachability_score", 0))
    priority_label, _ = _get_priority_label(lead.get("lead_priority"))
    channel_lbl, _    = _get_channel_label(lead.get("best_channel"))

    decision_maker = (
        lead.get("decision_maker_name")
        or lead.get("decision_maker_first")
        or "Not found"
    )

    fit_reason = lead.get("fit_reason") or "No fit reason returned yet."
    opener     = lead.get("recommended_opener") or "No opener yet."
    pain_points = _parse_json_list(lead.get("pain_points"))

    name    = lead.get("business_name", "Unknown")
    industry = lead.get("industry", "Unknown")
    city    = lead.get("city", "")
    country = lead.get("country", "")
    market  = lead.get("market", "")
    phone   = lead.get("phone", "") or "—"
    wa_status = _lead_wa_status(lead)

    # Version-safe container
    try:
        card = st.container(border=True)
    except TypeError:
        card = st.container()

    wa_badge = {
        "verified":           " · ✅ WA Verified",
        "opted_in":           " · ✅ WA Opted-In",
        "estimated":          " · 💬 WA Estimated",
        "business_confirmed": " · 🟠 WA Business Confirmed",
    }.get(wa_status, " · ⚪ WA Unknown")

    with card:
        st.markdown(
            f"<div style='height:4px;background:{channel_color};"
            f"border-radius:6px;margin:0 0 10px 0;'></div>",
            unsafe_allow_html=True,
        )
        st.markdown(f"### {_esc(name)}")
        st.caption(
            f"{_esc(industry)} • {_esc(city)} {_esc(country)}"
            f"{(' • ' + _esc(market)) if market else ''}"
        )
        st.markdown(
            f"**Priority:** `{priority_label}`  |  "
            f"**Channel:** `{channel_lbl}{wa_badge}`"
        )
        st.markdown(
            f"**Decision Maker:** {_esc(decision_maker)}  \n"
            f"**Phone:** {_esc(phone)}"
        )

        m1, m2, m3 = st.columns(3)
        m1.metric("Fit", f"{fit_score}/10")
        m2.metric("Urgency", f"{urgency}/100")
        m3.metric("Reach", f"{reachability}/100")

        with st.expander("💡 Why this lead", expanded=True):
            st.write(_truncate_text(fit_reason, 200))
        with st.expander("💬 Recommended Opener", expanded=True):
            st.write(_truncate_text(opener, 200))
        if pain_points:
            with st.expander("🔴 Pain Points", expanded=False):
                for p in pain_points[:4]:
                    st.write(f"• {p}")


# ─────────────────────────────────────────────────────────
# Routing health section
# ─────────────────────────────────────────────────────────
def _render_routing_health(stats: dict) -> None:
    wa_verified   = _safe_int(stats.get("whatsapp_verified", 0))
    wa_estimated  = _safe_int(stats.get("whatsapp_estimated", 0))
    call_ready    = _safe_int(stats.get("call_ready", 0))
    email_ready   = _safe_int(stats.get("email_ready", 0))
    manual_needed = _safe_int(stats.get("manual_review_needed", 0))
    unrouted      = _safe_int(stats.get("unrouted_leads", 0))
    total         = _safe_int(stats.get("total_leads", 0))

    # Hide section if nothing to show
    if not any([wa_verified, wa_estimated, call_ready, email_ready, manual_needed, unrouted]):
        return

    st.markdown(
        "<div style='color:#f4f7fb;font-size:22px;font-weight:800;"
        "margin-bottom:2px;'>Routing Health</div>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<div style='color:#93a0b7;font-size:13px;margin-bottom:14px;'>"
        "WhatsApp verification, country/market split and channel assignment coverage."
        "</div>",
        unsafe_allow_html=True,
    )

    cols = st.columns(6)
    cards = [
        ("💬", "WA Verified",  wa_verified,   "Agent confirmed",  "#25D366"),
        ("🟡", "WA Estimated", wa_estimated,  "Heuristic ready",  "#f59e0b"),
        ("📞", "Call Ready",   call_ready,    "Valid phone",       "#3b82f6"),
        ("📧", "Email Ready",  email_ready,   "Valid email",       "#0ea5e9"),
        ("🔍", "Manual Review",manual_needed, "Research needed",  "#fb7185"),
        ("⚠️", "Unrouted",    unrouted,      "Needs route run",  "#f59e0b"),
    ]
    for i, (icon, label, val, sub, color) in enumerate(cards):
        with cols[i]:
            _render_small_card(label, str(val), sub, color, icon)

    if total > 0 and wa_verified > 0:
        pct = round((wa_verified / total) * 100, 1)
        st.caption(
            f"WhatsApp verification coverage: {wa_verified}/{total} "
            f"leads ({pct}%) manually confirmed by agents."
        )
    st.write("")


# ─────────────────────────────────────────────────────────
# Routing batch helper
# ─────────────────────────────────────────────────────────
def _route_unrouted_batch(limit: int) -> dict:
    if not _ROUTER_AVAILABLE:
        return {"total": 0, "routed": 0, "error": "router_unavailable"}
    if get_connection is None:
        return {"total": 0, "routed": 0, "error": "db_unavailable"}
    if apply_routing_update is None:
        return {"total": 0, "routed": 0, "error": "db_update_unavailable"}

    leads = get_unrouted_leads(limit=limit) or []
    total = len(leads)
    if total == 0:
        return {"total": 0, "routed": 0}

    routed = 0
    for lead in leads:
        lead_id = lead.get("id")
        if not lead_id:
            continue
        try:
            updates = _router_assign_channel(lead) or {}
            if updates and apply_routing_update(lead_id, updates):
                routed += 1
        except Exception:
            continue

    return {"total": total, "routed": routed}


# ─────────────────────────────────────────────────────────
# Core: score + route with visible progress
# ─────────────────────────────────────────────────────────
def _score_with_progress(
    unscored_count: int,
    unrouted_count: int,
    batch_size: int,
) -> dict:
    """
    Score up to `batch_size` unscored leads sequentially with a
    Streamlit progress bar (values always in 0.0–1.0 range).
    Then route any unrouted leads.
    Returns a result summary dict.
    """
    result: dict = {
        "scored_total": 0,
        "scored_done": 0,
        "routed_total": 0,
        "routed_done": 0,
        "router_used": _ROUTER_AVAILABLE,
        "high": 0,
        "medium": 0,
        "low": 0,
    }

    score_limit = min(batch_size, unscored_count) if unscored_count > 0 else 0

    # ── Scoring path: prefer per-lead progress when scorer is available ──
    if score_limit > 0:
        if _SCORER_AVAILABLE:
            lead_ids = _get_unscored_lead_ids(score_limit)
            total = len(lead_ids)
            result["scored_total"] = total

            if total > 0:
                st.markdown(
                    "<div style='color:#94a3b8;font-size:12px;"
                    "font-weight:700;text-transform:uppercase;"
                    "letter-spacing:1px;margin-bottom:6px;'>"
                    "📊 Scoring Progress</div>",
                    unsafe_allow_html=True,
                )

                progress_bar = st.progress(0.0)  # FIX: float 0.0 not int
                status_text  = st.empty()
                lead_feedback = st.empty()

                scored_count = 0
                high = medium = low = 0

                for i, lead_info in enumerate(lead_ids):
                    lead_id   = lead_info["id"]
                    lead_name = lead_info["name"]

                    # FIX: always pass float 0.0–1.0 to st.progress
                    progress_frac = float(i) / float(max(total, 1))
                    progress_bar.progress(progress_frac)

                    status_text.markdown(
                        f"<div style='color:#cbd5e1;font-size:13px;'>"
                        f"⏳ Scoring lead <b>{i + 1}</b> of <b>{total}</b> — "
                        f"{_esc(lead_name)}</div>",
                        unsafe_allow_html=True,
                    )

                    try:
                        res = score_and_save_lead(lead_id)
                        if res:
                            scored_count += 1
                            fit      = _safe_int(res.get("fit_score", 0))
                            audit    = _safe_int(res.get("website_audit_score", 0))
                            # FIX: scorer uses "high"/"medium"/"low" not "hot"/"warm"
                            priority = str(
                                res.get("lead_priority", "unscored") or "unscored"
                            ).lower()

                            if priority in ("high", "hot") or fit >= 8:
                                high += 1
                            elif priority in ("medium", "warm") or fit >= 6:
                                medium += 1
                            else:
                                low += 1

                            if fit >= 8:
                                dot, color = "🟢", "#22c55e"
                            elif fit >= 6:
                                dot, color = "🟡", "#f59e0b"
                            else:
                                dot, color = "🔴", "#ef4444"

                            lead_feedback.markdown(
                                f"<div style='background:rgba(255,255,255,0.03);"
                                f"border:1px solid rgba(255,255,255,0.06);"
                                f"border-radius:10px;padding:8px 12px;"
                                f"font-size:12px;color:#cbd5e1;margin-top:4px;'>"
                                f"{dot} <b style='color:{color};'>{_esc(lead_name)}</b> — "
                                f"fit: <b>{fit}/10</b> | "
                                f"audit: <b>{audit}/10</b> | "
                                f"priority: <b>{_esc(priority)}</b>"
                                f"</div>",
                                unsafe_allow_html=True,
                            )
                    except Exception as e:
                        lead_feedback.markdown(
                            f"<div style='color:#ef4444;font-size:12px;"
                            f"padding:4px 0;'>⚠️ Failed: {_esc(lead_name)} "
                            f"— {_esc(str(e))}</div>",
                            unsafe_allow_html=True,
                        )

                # FIX: complete progress with float 1.0
                progress_bar.progress(1.0)
                status_text.markdown(
                    f"<div style='color:#22c55e;font-size:13px;font-weight:700;'>"
                    f"✅ Scoring complete — {scored_count}/{total} leads scored"
                    f"</div>",
                    unsafe_allow_html=True,
                )
                lead_feedback.empty()

                result["scored_done"] = scored_count
                result["high"]   = high
                result["medium"] = medium
                result["low"]    = low

        else:
            # Scorer not available: fall back to batch function
            score_res = score_unscored_leads_batch(limit=score_limit, use_ai=True) or {}
            result["scored_total"] = _safe_int(score_res.get("total", 0))
            result["scored_done"]  = _safe_int(score_res.get("scored", 0))
            result["high"]   = _safe_int(score_res.get("high", 0))
            result["medium"] = _safe_int(score_res.get("medium", 0))
            result["low"]    = _safe_int(score_res.get("low", 0))

    # ── Routing sweep ──────────────────────────────────────
    if unrouted_count > 0:
        route_limit = min(400, unrouted_count)

        st.markdown(
            "<div style='color:#94a3b8;font-size:12px;"
            "font-weight:700;text-transform:uppercase;"
            "letter-spacing:1px;margin:12px 0 6px 0;'>"
            "🔀 Routing Unrouted Leads</div>",
            unsafe_allow_html=True,
        )
        route_bar  = st.progress(0.0)   # FIX: float 0.0
        route_text = st.empty()

        route_text.markdown(
            f"<div style='color:#cbd5e1;font-size:13px;'>"
            f"⏳ Routing {route_limit} unrouted leads...</div>",
            unsafe_allow_html=True,
        )

        route_res = _route_unrouted_batch(limit=route_limit) or {}

        # FIX: float 1.0
        route_bar.progress(1.0)
        route_text.markdown(
            f"<div style='color:#22c55e;font-size:13px;font-weight:700;'>"
            f"✅ Routing complete — "
            f"{route_res.get('routed', 0)}/{route_res.get('total', route_limit)} "
            f"leads routed</div>",
            unsafe_allow_html=True,
        )

        result["routed_total"] = _safe_int(route_res.get("total", route_limit))
        result["routed_done"]  = _safe_int(route_res.get("routed", 0))
        if route_res.get("error"):
            result["route_error"] = route_res["error"]

    return result


# ─────────────────────────────────────────────────────────
# Main dashboard render — SINGLE DEFINITION
# ─────────────────────────────────────────────────────────
def render_dashboard() -> None:
    """Full dashboard render. Called once by render()."""

    st.markdown(
        dedent("""
        <style>
            .block-container { padding-top: 1.4rem; padding-bottom: 2rem; }
            div[data-testid="stDataFrame"] { border-radius: 14px; overflow: hidden; }
            div[data-testid="stExpander"] {
                background: rgba(255,255,255,0.02);
                border: 1px solid rgba(255,255,255,0.06);
                border-radius: 12px;
            }
        </style>
        """),
        unsafe_allow_html=True,
    )

    now = datetime.now()

    # ── Load data ──────────────────────────────────────────
    running_job = _safe_call(get_running_job, {}) or {}
    stats       = _safe_call(get_dashboard_stats, {}) or {}

    # Core KPIs
    total_leads          = _safe_int(stats.get("total_leads", 0))
    hot_leads            = _safe_int(stats.get("hot_leads", 0))
    leads_with_email     = _safe_int(stats.get("leads_with_email", 0))
    leads_with_phone     = _safe_int(stats.get("leads_with_phone", 0))
    deals_closed         = _safe_int(stats.get("deals_closed", 0))
    total_revenue        = stats.get("total_revenue", 0) or 0

    high_fit_leads       = _safe_int(stats.get("high_fit_leads", 0))
    medium_fit_leads     = _safe_int(stats.get("medium_fit_leads", 0))
    low_fit_leads        = _safe_int(stats.get("low_fit_leads", 0))
    unscored_leads       = _safe_int(stats.get("unscored_leads", 0))
    unrouted_leads       = _safe_int(stats.get("unrouted_leads", 0))

    whatsapp_ready_count    = _safe_int(stats.get("whatsapp_ready", 0))
    whatsapp_verified_count = _safe_int(stats.get("whatsapp_verified", 0))
    whatsapp_estimated_count= _safe_int(stats.get("whatsapp_estimated", 0))
    ai_call_ready_count     = _safe_int(stats.get("ai_call_ready", 0))
    email_ready_count       = _safe_int(stats.get("email_ready", 0))
    whatsapp_sent_count     = _safe_int(stats.get("whatsapp_sent", 0))
    decision_maker_count    = _safe_int(stats.get("leads_with_decision_maker", 0))

    # Dict stats — default to {} if not present or wrong type
    by_country  = stats.get("by_country") or {}
    by_market   = stats.get("by_market") or {}
    by_wa_status = stats.get("by_wa_status") or {}
    by_source   = stats.get("by_source") or {}

    if not isinstance(by_country, dict):
        by_country = {}
    if not isinstance(by_market, dict):
        by_market = {}

    # ── Filter controls ────────────────────────────────────
    country_options = ["All"] + sorted(
        {str(k).strip() for k in by_country.keys() if str(k).strip()}
    )
    market_options = ["All"] + sorted(
        {str(k).strip() for k in by_market.keys() if str(k).strip()}
    )
    wa_options      = ["All", "verified", "estimated", "business_confirmed", "opted_in", "unknown"]
    channel_options = ["All", "whatsapp", "ai_call", "email", "manual"]

    f1, f2, f3, f4, f5, f6 = st.columns([1.2, 1.2, 1, 1, 1, 1.1])
    with f1:
        selected_country = st.selectbox("Country", country_options, index=0, key="db_country")
    with f2:
        selected_market = st.selectbox("Market", market_options, index=0, key="db_market")
    with f3:
        selected_channel = st.selectbox("Channel", channel_options, index=0, key="db_channel")
    with f4:
        selected_wa = st.selectbox("WA Status", wa_options, index=0, key="db_wa")
    with f5:
        min_fit = st.selectbox("Min Fit", [0, 4, 5, 6, 7, 8], index=0, key="db_min_fit")
    with f6:
        batch_size = st.selectbox(
            "Score Batch", [5, 10, 20, 50, 100], index=1, key="db_batch_size"
        )

    # ── Apply filters to lead lists ────────────────────────
    filter_kwargs = dict(
        country=selected_country,
        market=selected_market,
        channel=selected_channel,
        wa_status=selected_wa,
        min_fit=min_fit,
    )

    top_prospects      = _apply_filters(_safe_call(lambda: get_top_prospects(limit=8), []) or [], **filter_kwargs)
    whatsapp_verified  = _apply_filters(_safe_call(lambda: get_whatsapp_verified_leads(limit=8), []) or [], **filter_kwargs)
    whatsapp_estimated = _apply_filters(_safe_call(lambda: get_whatsapp_estimated_leads(limit=8), []) or [], **filter_kwargs)
    ai_call_ready      = _apply_filters(_safe_call(lambda: get_ai_call_ready_leads(limit=8), []) or [], **filter_kwargs)
    email_ready        = _apply_filters(_safe_call(lambda: get_email_ready_leads(limit=8), []) or [], **filter_kwargs)
    manual_review      = _apply_filters(_safe_call(lambda: get_manual_review_leads(limit=8), []) or [], **filter_kwargs)
    recent_campaigns   = _safe_call(lambda: get_recent_jobs(limit=6), []) or []

    top_cities    = _get_top_cities(limit=3)
    top_countries = _get_top_countries(limit=5)
    top_markets   = _get_top_markets(limit=5)

    high_intent_pct = round((high_fit_leads / total_leads) * 100) if total_leads else 0

    # ── Hero banner ────────────────────────────────────────
    st.markdown(
        dedent(f"""
        <div style="
            background:linear-gradient(180deg,rgba(17,24,39,0.96),rgba(10,14,24,0.96));
            border:1px solid rgba(255,255,255,0.08);
            border-radius:22px;
            padding:22px 24px;
            box-shadow:0 18px 40px rgba(0,0,0,0.20);
            margin-bottom:20px;
        ">
            <div style="display:flex;justify-content:space-between;
            gap:20px;align-items:flex-start;">
                <div>
                    <div style="color:#7f8aa3;text-transform:uppercase;
                    letter-spacing:0.18em;font-size:11px;margin-bottom:8px;">
                        Executive Dashboard
                    </div>
                    <div style="color:#f4f7fb;font-size:34px;font-weight:800;
                    margin:0;line-height:1.1;">
                        Lead engine generated {total_leads:,} opportunities
                    </div>
                    <div style="color:#93a0b7;font-size:14px;margin-top:10px;">
                        {high_intent_pct}% classified as high-intent &bull;
                        Live refresh &bull;
                        {_esc(now.strftime("%A, %d %B %Y, %H:%M:%S"))}
                    </div>
                </div>
                <div style="text-align:right;min-width:220px;">
                    <div style="color:#7f8aa3;text-transform:uppercase;
                    letter-spacing:0.18em;font-size:11px;margin-bottom:4px;">
                        Revenue Pipeline
                    </div>
                    <div style="color:#f4f7fb;font-size:34px;font-weight:800;
                    line-height:1;">
                        {_fmt_money(total_revenue)}
                    </div>
                </div>
            </div>
        </div>
        """),
        unsafe_allow_html=True,
    )

    # ── KPI Row 1 ──────────────────────────────────────────
    st.markdown(
        "<div style='color:#f4f7fb;font-size:22px;font-weight:800;"
        "margin-bottom:2px;'>Overview</div>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<div style='color:#93a0b7;font-size:13px;margin-bottom:14px;'>"
        "Core performance metrics from your live lead database.</div>",
        unsafe_allow_html=True,
    )

    row1 = st.columns(6)
    metrics_row1 = [
        ("Total Leads",  f"{total_leads:,}",       "All opportunities",   "#4c7dff", "📊"),
        ("Hot Leads",    f"{hot_leads:,}",          "High-intent",         "#ff4d4d", "🔥"),
        ("Emails",       f"{leads_with_email:,}",   "Reachable contacts",  "#19d38c", "✉️"),
        ("Phones",       f"{leads_with_phone:,}",   "Direct outreach",     "#3ec7ff", "📞"),
        ("Deals",        f"{deals_closed:,}",       "Closed",              "#8b5cf6", "💰"),
        ("Revenue",      _fmt_money(total_revenue), "Tracked",             "#f59e0b", "💼"),
    ]
    for col, (label, val, sub, accent, icon) in zip(row1, metrics_row1):
        with col:
            _render_metric_card(label, val, sub, accent, icon)

    st.write("")

    # ── KPI Row 2 ──────────────────────────────────────────
    row2 = st.columns(6)
    metrics_row2 = [
        ("High Fit",     f"{high_fit_leads:,}",          "Priority prospects", "#22c55e", "🎯"),
        ("Medium Fit",   f"{medium_fit_leads:,}",        "Warm prospects",     "#14b8a6", "🟡"),
        ("Low Fit",      f"{low_fit_leads:,}",           "Lower priority",     "#64748b", "⚪"),
        ("Unscored",     f"{unscored_leads:,}",          "Waiting scoring",    "#60a5fa", "🧠"),
        ("WA Verified",  f"{whatsapp_verified_count:,}", "Confirmed only",     "#25d366", "✅"),
        ("WA Estimated", f"{whatsapp_estimated_count:,}","Heuristic only",     "#f59e0b", "🟡"),
    ]
    for col, (label, val, sub, accent, icon) in zip(row2, metrics_row2):
        with col:
            _render_metric_card(label, val, sub, accent, icon)

    st.write("")

    # ── KPI Row 3 ──────────────────────────────────────────
    row3 = st.columns(6)
    metrics_row3 = [
        ("WhatsApp Ready", f"{whatsapp_ready_count:,}",  "All WA-ready",        "#25d366", "💬"),
        ("AI Call Ready",  f"{ai_call_ready_count:,}",   "Call queue",          "#a855f7", "📲"),
        ("Email Ready",    f"{email_ready_count:,}",     "Cold email queue",    "#0ea5e9", "📨"),
        ("WA Sent",        f"{whatsapp_sent_count:,}",   "Already contacted",   "#16a34a", "✅"),
        ("Decision Makers",f"{decision_maker_count:,}",  "Named contacts",      "#fb7185", "👤"),
        ("Live Time",      now.strftime("%H:%M"),         "Dashboard clock",     "#e879f9", "🕒"),
    ]
    for col, (label, val, sub, accent, icon) in zip(row3, metrics_row3):
        with col:
            _render_metric_card(label, val, sub, accent, icon)

    st.write("")

    # ── Routing health ─────────────────────────────────────
    _render_routing_health(stats)

    # ── Scoring / routing backlog banner ───────────────────
    needs_work = (unscored_leads > 0) or (unrouted_leads > 0)
    if needs_work:
        st.markdown(
            dedent(f"""
            <div style="
                background:linear-gradient(135deg,rgba(17,24,39,0.95),rgba(24,33,52,0.95));
                border:1px solid rgba(91,124,255,0.35);
                border-radius:18px;
                padding:18px 20px;
                margin-bottom:12px;
            ">
                <div style="color:white;font-size:18px;font-weight:800;margin-bottom:4px;">
                    Scoring + Routing Backlog
                </div>
                <div style="color:#94a3b8;font-size:13px;line-height:1.6;">
                    Unscored: <b>{unscored_leads}</b> &bull;
                    Unrouted: <b>{unrouted_leads}</b><br>
                    Click below to score <b>{batch_size}</b> leads per run
                    and route any unrouted leads.
                </div>
            </div>
            """),
            unsafe_allow_html=True,
        )

        if st.button(
            f"🧠 Score Next {batch_size} Leads",
            use_container_width=True,
            type="primary",
            key="score_existing_leads_dashboard",
        ):
            result = _score_with_progress(
                unscored_count=unscored_leads,
                unrouted_count=unrouted_leads,
                batch_size=batch_size,
            )

            st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)

            scored = result.get("scored_done", 0)
            s_total = result.get("scored_total", 0)
            routed = result.get("routed_done", 0)

            st.success(
                f"Done: scored {scored}/{s_total} leads; routed {routed} leads."
            )
            if result.get("route_error"):
                st.warning(f"Routing notice: {result['route_error']}")

            st.rerun()

    st.write("")

    # ── AI Prospect Queue spotlight ────────────────────────
    st.markdown(
        "<div style='color:#f4f7fb;font-size:22px;font-weight:800;"
        "margin-bottom:2px;'>AI Prospect Queue</div>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<div style='color:#93a0b7;font-size:13px;margin-bottom:14px;'>"
        "Best leads to call first — ranked by fit, priority, reachability and channel."
        "</div>",
        unsafe_allow_html=True,
    )

    if top_prospects:
        spotlight = top_prospects[:3]
        cols = st.columns(len(spotlight))
        for idx, lead in enumerate(spotlight):
            _, channel_color = _get_channel_label(lead.get("best_channel"))
            with cols[idx]:
                _render_spotlight_card(lead, channel_color)
    else:
        st.info("No scored prospects yet. Run scoring to generate them.")

    st.write("")

    # ── Live scraping monitor ──────────────────────────────
    if running_job:
        job_summary = (
            _safe_call(lambda: get_job_status_summary(running_job.get("id")), {}) or {}
        )

        st.markdown(
            "<div style='color:#f4f7fb;font-size:22px;font-weight:800;"
            "margin-bottom:2px;'>Live Scraping Activity</div>",
            unsafe_allow_html=True,
        )
        st.markdown(
            "<div style='color:#93a0b7;font-size:13px;margin-bottom:14px;'>"
            "Current active job — updates in real time.</div>",
            unsafe_allow_html=True,
        )

        c1, c2, c3 = st.columns([2, 1, 1])
        with c1:
            st.write(f"**{job_summary.get('message', 'Running...')}**")
            st.caption(
                f"{running_job.get('source', '')} • "
                f"{running_job.get('keyword', '')} • "
                f"{running_job.get('location', '')}"
            )
        with c2:
            st.metric("Progress", f"{_safe_int(job_summary.get('progress', 0))}%")
        with c3:
            st.metric("Leads Found", f"{_safe_int(job_summary.get('leads', 0))}")

        # FIX: always pass float 0.0–1.0
        prog_pct = _safe_int(job_summary.get("progress", 0))
        st.progress(max(0.0, min(1.0, prog_pct / 100.0)))

        current_lead = running_job.get("current_lead", "")
        if current_lead:
            st.caption(f"Processing: {_esc(current_lead)}")

        st.write("")

    # ── Footer ─────────────────────────────────────────────
    st.caption(
        f"Last refreshed: {now.strftime('%A, %d %B %Y, %H:%M:%S')} "
        f"• All figures read live from SQLite."
    )


# ─────────────────────────────────────────────────────────
# Streamlit page entry point — ONE definition only
# ─────────────────────────────────────────────────────────
def render() -> None:
    """Entry point called by app.py page router."""
    render_dashboard()
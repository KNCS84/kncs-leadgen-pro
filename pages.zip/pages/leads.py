# pages/leads.py
# FULL REPLACEMENT — v9.1
# Segment view fixed + KPI icons fixed + empty bars removed
# Safe during active scraping: avoids dataframe rendering when jobs are running

from datetime import datetime
from textwrap import dedent
import re

import pandas as pd
import streamlit as st

from database import (
    get_all_leads,
    update_lead_status,
    update_lead_email,
    get_connection,
)
from engine.scorer import get_contact_completeness
from engine.enricher import (
    find_email_multi_source,
    enrich_lead,
)
from engine.job_manager import any_job_running

# ─────────────────────────────────────────────────────────
# PAGE STYLE
# ─────────────────────────────────────────────────────────

st.markdown(
    """
    <style>
        .premium-card {
            background: linear-gradient(135deg, rgba(17,24,39,0.95), rgba(24,33,52,0.95));
            border: 1px solid rgba(255,255,255,0.07);
            border-radius: 16px;
            padding: 18px 20px;
            margin-bottom: 16px;
            box-shadow: 0 10px 26px rgba(0,0,0,0.18);
        }
        .kpi-label {
            color: #64748b;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 6px;
        }
        .kpi-value {
            color: white;
            font-size: 26px;
            font-weight: 900;
            line-height: 1;
            margin-bottom: 6px;
        }
        .kpi-sub {
            color: #94a3b8;
            font-size: 12px;
        }
    </style>
    """,
    unsafe_allow_html=True,
)

# ─────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────

def safe_key(lead_id, suffix):
    clean = re.sub(r"[^a-zA-Z0-9]", "_", suffix)[:20]
    return f"lead_{lead_id}_{clean}"


def _safe_int(value, default=0):
    try:
        if value is None:
            return default
        return int(value)
    except Exception:
        return default


def _safe_float(value, default=0.0):
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        return default


def _is_scraping_active() -> bool:
    try:
        return bool(any_job_running())
    except Exception:
        return False


def score_color(score):
    if score >= 70:
        return "#ef4444"
    if score >= 50:
        return "#f59e0b"
    return "#38bdf8"


def source_color(source):
    return {
        "google_maps":     "#5b8cff",
        "b2bhint":         "#8b5cf6",
        "yelp":            "#ef4444",
        "yellowpages":     "#10b981",
        "companies_house": "#3b82f6",
    }.get(source, "#64748b")


def source_icon(source):
    return {
        "google_maps":     "🗺️",
        "b2bhint":         "🏢",
        "yelp":            "⭐",
        "yellowpages":     "📒",
        "companies_house": "🇬🇧",
    }.get(source, "📋")


def section_header(title, subtitle=""):
    sub_html = (
        f'<div style="margin-top:6px;color:#94a3b8;'
        f'font-size:13px;">{subtitle}</div>'
        if subtitle else ""
    )
    st.markdown(
        dedent(f"""
<div style="margin-bottom:16px;">
<div style="font-size:22px;font-weight:800;
color:white;letter-spacing:-0.5px;">
{title}
</div>
{sub_html}
</div>
"""),
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────
# HERO
# ─────────────────────────────────────────────────────────

def render_hero():
    now = datetime.now()
    st.markdown(
        dedent(f"""
<div style="margin-bottom:28px;">
<div style="font-size:40px;font-weight:900;
color:white;line-height:1;letter-spacing:-2px;">
Lead Intelligence Workspace
</div>
<div style="margin-top:12px;max-width:700px;
color:#94a3b8;font-size:15px;line-height:1.8;">
Manage, enrich, filter and qualify your business leads
with a premium CRM workflow designed for high-volume
outreach and deal conversion.
<br/>
<span style="color:#cbd5e1;">Updated {now.strftime("%A, %d %B %Y, %H:%M:%S")}</span>
</div>
</div>
"""),
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────
# KPI STRIP — Fixed icons (emoji + colored border-top)
# ─────────────────────────────────────────────────────────

def render_kpis(leads):
    total = len(leads)
    hot = sum(1 for l in leads if (l.get("opportunity_score") or 0) >= 70)
    emails = sum(1 for l in leads if l.get("email"))
    phones = sum(1 for l in leads if l.get("phone"))
    called = sum(1 for l in leads if l.get("contacted") == 1)

    enriched = sum(
        1
        for l in leads
        if str(l.get("enrichment_status", "")).lower() in (
            "done", "complete", "completed", "enriched"
        )
    )

    cards = [
        ("🎯", "Total Leads", f"{total:,}",    "All leads",          "#5b8cff"),
        ("🔥", "Hot Leads",   f"{hot:,}",      "High-intent",        "#ef4444"),
        ("📧", "Emails",      f"{emails:,}",   "Reachable contacts", "#10b981"),
        ("📞", "Phones",      f"{phones:,}",   "Direct outreach",    "#38bdf8"),
        ("📲", "Called",      f"{called:,}",   "Outreach done",      "#8b5cf6"),
        ("✅", "Enriched",    f"{enriched:,}", "Processed leads",    "#f59e0b"),
    ]

    cols = st.columns(6)

    for idx, (icon, title, value, sub, color) in enumerate(cards):
        with cols[idx]:
            st.markdown(
                dedent(f"""
<div style="background:linear-gradient(135deg,
rgba(17,24,39,0.95),rgba(24,33,52,0.95));
border:1px solid rgba(255,255,255,0.07);
border-top:3px solid {color};
border-radius:16px;padding:16px 14px;
box-shadow:0 6px 20px rgba(0,0,0,0.2);
margin-bottom:16px;">
<div style="font-size:26px;margin-bottom:10px;">
{icon}
</div>
<div style="color:#64748b;font-size:10px;
font-weight:700;text-transform:uppercase;
letter-spacing:1px;">{title}</div>
<div style="font-size:24px;font-weight:900;
color:white;margin-top:6px;line-height:1;">
{value}
</div>
<div style="font-size:11px;color:{color};
margin-top:6px;font-weight:600;">{sub}</div>
</div>
"""),
                unsafe_allow_html=True,
            )


# ─────────────────────────────────────────────────────────
# FILTERS — No empty bar (no card_start before header)
# ─────────────────────────────────────────────────────────

def render_filters(all_leads):
    section_header(
        "Lead Filters",
        "Refine your workspace",
    )

    st.markdown(
        dedent("""
<div style="background:linear-gradient(135deg,
rgba(17,24,39,0.95),rgba(24,33,52,0.95));
border:1px solid rgba(255,255,255,0.07);
border-radius:16px;padding:18px 20px;
margin-bottom:16px;">
"""),
        unsafe_allow_html=True,
    )

    c1, c2, c3, c4, c5 = st.columns(5)

    with c1:
        search = st.text_input(
            "Search Business",
            placeholder="Type name...",
            key="leads_search",
        )
    with c2:
        min_score = st.slider(
            "Min Score", 0, 100, 0, 5,
            key="leads_min_score",
        )
    with c3:
        source = st.selectbox(
            "Source",
            [
                "All",
                "companies_house",
                "google_maps",
                "b2bhint",
                "yelp",
                "yellowpages",
            ],
            key="leads_source",
        )
    with c4:
        status = st.selectbox(
            "Status",
            [
                "All", "new", "called",
                "interested", "callback",
                "deal_closed",
            ],
            key="leads_status",
        )
    with c5:
        email_f = st.selectbox(
            "Email",
            ["All", "Has Email", "Missing Email"],
            key="leads_email_filter",
        )

    st.markdown("</div>", unsafe_allow_html=True)

    leads = all_leads

    if search:
        leads = [
            l for l in leads
            if search.lower() in (l.get("business_name", "")).lower()
        ]
    if min_score > 0:
        leads = [
            l for l in leads
            if (l.get("opportunity_score", 0) or 0) >= min_score
        ]
    if source != "All":
        leads = [l for l in leads if l.get("source") == source]
    if status != "All":
        leads = [l for l in leads if l.get("contact_status") == status]
    if email_f == "Has Email":
        leads = [l for l in leads if l.get("email")]
    elif email_f == "Missing Email":
        leads = [l for l in leads if not l.get("email")]

    return leads


# ─────────────────────────────────────────────────────────
# SEGMENT VIEW — Fully restored
# ─────────────────────────────────────────────────────────

def build_segments(leads: list) -> dict:
    """
    Group leads by industry + city.
    Handles None/empty values safely.
    """
    segments = {}

    for lead in leads:
        industry = (lead.get("industry") or "Unknown").strip()
        if industry.lower() in ("", "unknown", "none"):
            industry = "Unknown Niche"

        city = (lead.get("city") or lead.get("location", "") or "Unknown Location").strip()
        if not city:
            city = "Unknown Location"

        if "," in city:
            city = city.split(",")[0].strip()

        key = f"{industry}||{city}"

        if key not in segments:
            segments[key] = {
                "industry": industry,
                "city": city,
                "leads": [],
            }

        segments[key]["leads"].append(lead)

    return dict(
        sorted(
            segments.items(),
            key=lambda x: len(x[1]["leads"]),
            reverse=True,
        )
    )


def render_lead_card(lead):
    lead_id = lead.get("id", 0)
    score = _safe_int(lead.get("opportunity_score", 0))
    color = score_color(score)
    source = lead.get("source") or "unknown"
    sc = source_color(source)
    si = source_icon(source)
    name = lead.get("business_name", "Unknown")

    completeness = get_contact_completeness(lead)
    if isinstance(completeness, dict):
        pct = completeness.get("percentage", completeness.get("score", 0))
    else:
        pct = completeness
    pct = _safe_float(pct, 0.0)
    if pct > 100:
        pct = 100.0
    if pct < 0:
        pct = 0.0

    phone = lead.get("phone") or "Not available"
    email = lead.get("email") or "Not available"
    website = (lead.get("website") or "Not available")[:40]
    city = lead.get("city", "")
    country = lead.get("country", "")
    ind = lead.get("industry", "Unknown")

    st.markdown(
        dedent(f"""
<div style="background:linear-gradient(135deg,
rgba(17,24,39,0.95),rgba(24,33,52,0.95));
border:1px solid rgba(255,255,255,0.06);
border-left:4px solid {color};
border-radius:20px;padding:22px;
margin-bottom:16px;">
<div style="display:flex;
justify-content:space-between;
align-items:flex-start;margin-bottom:18px;">
<div>
<div style="color:white;font-size:18px;
font-weight:800;margin-bottom:8px;">{name}</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;">
<span style="background:{sc}22;
border:1px solid {sc}44;color:{sc};
padding:3px 10px;border-radius:999px;
font-size:11px;font-weight:700;">
{si} {source.replace("_"," ").title()}
</span>
<span style="background:rgba(255,255,255,0.05);
border:1px solid rgba(255,255,255,0.08);
color:#cbd5e1;padding:3px 10px;
border-radius:999px;font-size:11px;
font-weight:700;">{ind}</span>
</div>
</div>
<div style="text-align:right;">
<div style="color:{color};font-size:38px;
font-weight:900;line-height:1;">{score}</div>
<div style="color:#94a3b8;font-size:11px;
letter-spacing:1px;">SCORE</div>
</div>
</div>
<div style="display:grid;
grid-template-columns:1fr 1fr;
gap:12px;margin-bottom:16px;">
<div style="background:rgba(255,255,255,0.03);
border:1px solid rgba(255,255,255,0.05);
border-radius:14px;padding:12px;">
<div style="color:#94a3b8;font-size:10px;
font-weight:700;text-transform:uppercase;
margin-bottom:5px;">Phone</div>
<div style="color:white;font-size:13px;
font-weight:600;">{phone}</div>
</div>
<div style="background:rgba(255,255,255,0.03);
border:1px solid rgba(255,255,255,0.05);
border-radius:14px;padding:12px;">
<div style="color:#94a3b8;font-size:10px;
font-weight:700;text-transform:uppercase;
margin-bottom:5px;">Email</div>
<div style="color:white;font-size:13px;
font-weight:600;word-break:break-all;">
{email}
</div>
</div>
<div style="background:rgba(255,255,255,0.03);
border:1px solid rgba(255,255,255,0.05);
border-radius:14px;padding:12px;">
<div style="color:#94a3b8;font-size:10px;
font-weight:700;text-transform:uppercase;
margin-bottom:5px;">Website</div>
<div style="color:white;font-size:13px;
font-weight:600;word-break:break-all;">
{website}
</div>
</div>
<div style="background:rgba(255,255,255,0.03);
border:1px solid rgba(255,255,255,0.05);
border-radius:14px;padding:12px;">
<div style="color:#94a3b8;font-size:10px;
font-weight:700;text-transform:uppercase;
margin-bottom:5px;">Location</div>
<div style="color:white;font-size:13px;
font-weight:600;">{city} {country}</div>
</div>
</div>
<div>
<div style="display:flex;
justify-content:space-between;
margin-bottom:6px;">
<span style="color:#94a3b8;font-size:12px;
font-weight:600;">Contact Completeness</span>
<span style="color:white;font-size:12px;
font-weight:700;">{pct:.0f}%</span>
</div>
<div style="height:7px;background:#1e293b;
border-radius:999px;overflow:hidden;">
<div style="width:{pct}%;height:100%;
background:linear-gradient(90deg,
#5b8cff,#7c5cff);
border-radius:999px;"></div>
</div>
</div>
</div>
"""),
        unsafe_allow_html=True,
    )

    c1, c2, c3 = st.columns(3)

    with c1:
        if not lead.get("email"):
            if st.button(
                "📧 Find Email",
                key=safe_key(lead_id, "find_email"),
                use_container_width=True,
            ):
                with st.spinner("Searching..."):
                    found = find_email_multi_source(
                        business_name=name,
                        website=lead.get("website"),
                        location=lead.get("city", ""),
                    )
                    if found:
                        update_lead_email(lead_id, found)
                        st.success(f"Found: {found}")
                        st.rerun()
                    else:
                        st.warning("No email found.")

    with c2:
        if st.button(
            "🔄 Re-Enrich",
            key=safe_key(lead_id, "re_enrich"),
            use_container_width=True,
        ):
            with st.spinner("Re-enriching..."):
                enrich_lead(
                    lead,
                    find_email=True,
                    find_phone=True,
                )
                st.success("Lead re-enriched.")
                st.rerun()

    with c3:
        if st.button(
            "✅ Mark Called",
            key=safe_key(lead_id, "mark_called"),
            use_container_width=True,
        ):
            update_lead_status(lead_id, "called")
            st.success("Updated.")
            st.rerun()


def render_segment_row(
    seg_key: str,
    seg_data: dict,
    show_cards: bool,
    row_idx: int,
):
    """
    Render one segment as an expandable row.
    """
    industry = seg_data["industry"]
    city = seg_data["city"]
    leads = seg_data["leads"]

    total = len(leads)
    emails = sum(1 for l in leads if l.get("email"))
    phones = sum(1 for l in leads if l.get("phone"))
    hot = sum(1 for l in leads if (l.get("opportunity_score") or 0) >= 70)

    safe_seg = re.sub(r"[^a-zA-Z0-9]", "_", seg_key)[:30]

    label = (
        f"🗺️ {industry}"
        f"  |  📍 {city}"
        f"  |  👥 {total} leads"
        f"  |  📧 {emails} emails"
        f"  |  📞 {phones} phones"
        f"  |  🔥 {hot} hot"
    )

    with st.expander(label, expanded=False):
        seg_df = pd.DataFrame([
            {
                "Business": l.get("business_name"),
                "Phone":    l.get("phone"),
                "Email":    l.get("email"),
                "Website":  l.get("website"),
                "Score":    l.get("opportunity_score"),
                "Status":   l.get("contact_status"),
                "Source":   l.get("source"),
                "City":     l.get("city"),
                "Country":  l.get("country"),
                "Fit":      l.get("fit_score", 0),
                "Channel":  l.get("best_channel", ""),
            }
            for l in leads
        ])

        col_exp, col_btn = st.columns([3, 1])
        with col_btn:
            fname = f"{industry}_{city}.csv".replace(" ", "_").replace("/", "_")
            st.download_button(
                "📥 Export CSV",
                data=seg_df.to_csv(index=False),
                file_name=fname,
                mime="text/csv",
                key=f"exp_{safe_seg}_{row_idx}",
                use_container_width=True,
            )

        if show_cards:
            for lead in leads[:10]:
                try:
                    render_lead_card(lead)
                except Exception as e:
                    st.warning(f"Lead card error: {e}")
            if total > 10:
                st.info(
                    f"Showing first 10 of {total}. "
                    "Export CSV to see all."
                )
        else:
            try:
                st.dataframe(
                    seg_df,
                    use_container_width=True,
                    hide_index=True,
                    height=min(400, 40 + len(leads) * 35),
                )
            except Exception as e:
                st.warning(
                    "Table view could not render safely while data is updating. "
                    f"{e}"
                )


def render_segment_view(leads: list):
    """
    Main segment view — restored to match screenshot.
    """
    if not leads:
        st.warning("No leads match current filters.")
        return

    segments = build_segments(leads)
    seg_count = len(segments)
    total = len(leads)

    st.markdown(
        dedent(f"""
<div style="background:linear-gradient(135deg,
rgba(17,24,39,0.95),rgba(24,33,52,0.95));
border:1px solid rgba(255,255,255,0.07);
border-radius:14px;padding:16px 20px;
margin-bottom:12px;">
<span style="color:white;font-weight:800;
font-size:18px;">{seg_count}</span>
<span style="color:#64748b;font-size:14px;">
&nbsp;segments&nbsp;&nbsp;•&nbsp;&nbsp;</span>
<span style="color:white;font-weight:800;
font-size:18px;">{total}</span>
<span style="color:#64748b;font-size:14px;">
&nbsp;total leads</span>
</div>
"""),
        unsafe_allow_html=True,
    )

    scraping_active = _is_scraping_active()

    ctrl1, ctrl2, ctrl3 = st.columns([2, 1, 1])

    with ctrl1:
        if scraping_active:
            st.checkbox(
                "Show card view inside segments",
                value=True,
                disabled=True,
                key="seg_show_cards_locked",
            )
            st.caption("Card view is forced while scraping is active to avoid UI conflicts.")
            show_cards = True
        else:
            show_cards = st.checkbox(
                "Show card view inside segments",
                value=False,
                key="seg_show_cards",
            )

    all_df = pd.DataFrame([
        {
            "Business": l.get("business_name"),
            "Industry": l.get("industry"),
            "City":     l.get("city"),
            "Country":  l.get("country"),
            "Phone":    l.get("phone"),
            "Email":    l.get("email"),
            "Website":  l.get("website"),
            "Score":    l.get("opportunity_score"),
            "Fit":      l.get("fit_score", 0),
            "Channel":  l.get("best_channel", ""),
            "Status":   l.get("contact_status"),
            "Source":   l.get("source"),
        }
        for l in leads
    ])

    with ctrl2:
        st.download_button(
            "📥 Export All (CSV)",
            data=all_df.to_csv(index=False),
            file_name="all_leads.csv",
            mime="text/csv",
            key="export_all_seg",
            use_container_width=True,
        )

    with ctrl3:
        hot_df = all_df[all_df["Score"].fillna(0) >= 70]
        hot_count = len(hot_df)
        st.download_button(
            f"🔥 Export Hot ({hot_count})",
            data=hot_df.to_csv(index=False),
            file_name="hot_leads.csv",
            mime="text/csv",
            key="export_hot_seg",
            use_container_width=True,
        )

    st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)

    for row_idx, (seg_key, seg_data) in enumerate(segments.items()):
        render_segment_row(
            seg_key,
            seg_data,
            show_cards,
            row_idx,
        )


# ─────────────────────────────────────────────────────────
# TABLE VIEW — Native st.dataframe (no AgGrid/React error)
# ─────────────────────────────────────────────────────────

def render_table_view(leads):
    section_header(
        "CRM Table View",
        "Interactive lead management",
    )

    if not leads:
        st.warning("No leads match current filters.")
        return

    if _is_scraping_active():
        st.info(
            "Table view is paused while scraping is active to avoid UI conflicts. "
            "Please use Segment View or Cards during live scraping."
        )
        return

    rows = []
    for lead in leads:
        rows.append({
            "Business": lead.get("business_name"),
            "Industry": lead.get("industry"),
            "City":     lead.get("city"),
            "Country":  lead.get("country"),
            "Phone":    lead.get("phone"),
            "Email":    lead.get("email"),
            "Score":    lead.get("opportunity_score"),
            "Fit":      lead.get("fit_score", 0),
            "Channel":  lead.get("best_channel", ""),
            "Status":   lead.get("contact_status"),
            "Source":   lead.get("source"),
            "Enriched": lead.get("enrichment_status"),
        })

    df = pd.DataFrame(rows)

    try:
        st.dataframe(
            df,
            use_container_width=True,
            hide_index=True,
            height=500,
        )
    except Exception as e:
        st.warning(f"Table could not render safely: {e}")

    c1, c2 = st.columns(2)
    with c1:
        st.download_button(
            "📥 Export All (CSV)",
            data=df.to_csv(index=False),
            file_name="leads.csv",
            mime="text/csv",
            key="export_all_csv",
        )
    with c2:
        if "Score" in df.columns:
            hot_df = df[df["Score"].fillna(0) >= 70]
            if not hot_df.empty:
                st.download_button(
                    f"🔥 Export Hot ({len(hot_df)})",
                    data=hot_df.to_csv(index=False),
                    file_name="hot_leads.csv",
                    mime="text/csv",
                    key="export_hot_csv",
                )


# ─────────────────────────────────────────────────────────
# CARD VIEW (paginated)
# ─────────────────────────────────────────────────────────

def render_card_view(leads):
    section_header(
        "Lead Cards",
        "Premium CRM card experience",
    )

    if not leads:
        st.warning("No leads match current filters.")
        return

    per_page = 8
    total_pages = max(1, (len(leads) + per_page - 1) // per_page)

    page = st.number_input(
        "Page",
        min_value=1,
        max_value=total_pages,
        value=1,
        key="leads_card_page",
    )

    start = (page - 1) * per_page
    end = start + per_page

    st.markdown(
        dedent(f"""
<div style="margin-bottom:16px;
color:#94a3b8;font-size:13px;">
Showing
<b style="color:white;">{len(leads)}</b>
filtered leads — Page {page} of {total_pages}
</div>
"""),
        unsafe_allow_html=True,
    )

    for lead in leads[start:end]:
        try:
            render_lead_card(lead)
        except Exception as e:
            st.warning(f"Lead card failed to render: {e}")


# ─────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────

def render_leads_page():
    render_hero()

    try:
        all_leads = get_all_leads(limit=5000)
    except Exception as e:
        st.error(f"Unable to load leads: {e}")
        return

    if not all_leads:
        st.warning("No leads yet. Run a search first.")
        return

    render_kpis(all_leads)

    st.markdown("<div style='height:22px'></div>", unsafe_allow_html=True)

    filtered = render_filters(all_leads)

    st.markdown("<div style='height:20px'></div>", unsafe_allow_html=True)

    tabs = st.tabs([
        "📋 Lead Segments",
        "📊 CRM Table",
        "🃏 Lead Cards",
    ])

    with tabs[0]:
        render_segment_view(filtered)

    with tabs[1]:
        render_table_view(filtered)

    with tabs[2]:
        render_card_view(filtered)


def render():
    render_leads_page()
# engine/scraper.py
# FULL REPLACEMENT — Windows + Python 3.12 asyncio fix
# Uses nest_asyncio to patch event loop conflict with Streamlit
# v2 — Added DB deduplication check before scraping detail pages

import asyncio
import re
import sys
from urllib.parse import urljoin

# ══════════════════════════════════════════════════════════
# CRITICAL — Must patch BEFORE any asyncio.run() call
# Fixes NotImplementedError on Windows + Python 3.12
# ══════════════════════════════════════════════════════════
import nest_asyncio
nest_asyncio.apply()

# Windows-specific event loop policy
if sys.platform == "win32":
    asyncio.set_event_loop_policy(
        asyncio.WindowsSelectorEventLoopPolicy()
    )

from playwright.async_api import async_playwright
from bs4 import BeautifulSoup

from engine.anti_detection import (
    async_random_delay,
    random_viewport,
    get_random_user_agent,
    get_stealth_args,
    apply_stealth,
)
from config import HEADLESS_MODE, MAX_RESULTS

# ── DB connection for deduplication check ──
from database import get_connection

BASE_URL = "https://www.google.com"

# ══════════════════════════════════════════════════════════
# TIMEOUT CONSTANTS
# ══════════════════════════════════════════════════════════

PAGE_TIMEOUT     = 120000   # 120s — MTN 4G friendly
DETAIL_TIMEOUT   = 90000    # 90s for detail pages
SELECTOR_TIMEOUT = 15000    # 15s for selectors
MAX_RETRIES      = 2        # retry failed pages twice

# ══════════════════════════════════════════════════════════
# DEDUPLICATION — Check DB before scraping detail page
# ══════════════════════════════════════════════════════════

def is_already_in_db(business_name: str) -> bool:
    """
    Returns True if a business with this name
    already exists in the database.
    Prevents re-scraping leads we already have.
    """
    if not business_name or len(business_name.strip()) < 3:
        return False

    try:
        conn   = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT id FROM leads
            WHERE LOWER(TRIM(business_name))
            = LOWER(TRIM(?))
            LIMIT 1
            """,
            (business_name.strip(),),
        )
        result = cursor.fetchone()
        conn.close()
        return result is not None

    except Exception as e:
        print(f"   ⚠️ DB check error: {e}")
        return False  # If check fails, allow scraping


def get_existing_names_bulk(keyword: str, city: str) -> set:
    """
    Pre-loads all business names for this keyword+city
    into a set for fast in-memory lookup.
    Much faster than checking DB for every lead.
    """
    existing = set()
    try:
        conn   = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT LOWER(TRIM(business_name))
            FROM leads
            WHERE LOWER(industry) = LOWER(?)
            AND LOWER(city) = LOWER(?)
            """,
            (keyword.strip(), city.strip()),
        )
        rows = cursor.fetchall()
        conn.close()
        existing = {row[0] for row in rows}
        if existing:
            print(
                f"   📋 {len(existing)} existing leads "
                f"found for '{keyword}' in '{city}' "
                f"— will skip duplicates"
            )
    except Exception as e:
        print(f"   ⚠️ Bulk DB check error: {e}")

    return existing

# ══════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ══════════════════════════════════════════════════════════

def clean_business_name(name: str) -> str:
    if not name:
        return ""
    name = name.strip()
    name = re.sub(
        r"\s+-\s+Google Maps.*$", "", name,
        flags=re.IGNORECASE,
    )
    name = re.sub(
        r"\s+-\s+Google.*$", "", name,
        flags=re.IGNORECASE,
    )
    name = name.replace("Sponsored", "").strip()
    return name


def is_bad_business_name(name: str) -> bool:
    if not name:
        return True

    bad_exact = {
        "sponsored", "google maps", "google", "results",
        "loading", "directions", "reviews", "photos",
        "share", "map", "continue", "go back to web",
        "open in app", "this site can't be reached",
        "this site can t be reached",
        "before you continue to google",
        "before you continue", "page not found",
        "404", "error", "access denied", "just a moment",
        "please wait", "enable javascript",
        "you've been blocked", "attention required",
        "cloudflare", "captcha", "robot",
        "none", "null", "undefined", "n/a",
    }

    bad_phrases = [
        "before you continue", "this site can",
        "enable javascript", "just a moment",
        "access denied", "please wait",
        "not a robot", "verify you", "checking your",
        "sponsored", "privacy policy", "terms of service",
        "cookie", "404 not found", "page not found",
        "site can't be reached", "connection refused",
        "err_connection", "this page", "open the",
        "get the app", "google maps is better",
        "better on the app",
    ]

    normalized = name.strip().lower()

    if normalized in bad_exact:
        return True

    for phrase in bad_phrases:
        if phrase in normalized:
            return True

    if len(normalized) < 3:
        return True

    if normalized.startswith("http"):
        return True

    return False


def extract_phone_from_text(text: str) -> str:
    if not text:
        return ""

    patterns = [
        r"(\+44[\s\-]?\d{2,4}[\s\-]?\d{3,4}[\s\-]?\d{3,4})",
        r"(0[1-9]\d{1,4}[\s\-]?\d{3,4}[\s\-]?\d{3,4})",
        r"(\+234[\s\-]?\d{3}[\s\-]?\d{3}[\s\-]?\d{4})",
        r"(0[789][01]\d[\s\-]?\d{3}[\s\-]?\d{4})",
        r"(0\d{10})",
        r"(\+?[1-9]\d{1,3}[\s\-]?\(?\d{2,4}\)?[\s\-]?\d{3,4}[\s\-]?\d{3,4})",
        r"(\+?[\d\s\-\(\)]{10,18})",
    ]

    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            phone  = match.group(1).strip()
            digits = re.sub(r"\D", "", phone)
            if 9 <= len(digits) <= 15:
                return phone

    return ""


def normalize_phone_for_whatsapp(phone: str) -> str:
    if not phone:
        return ""
    digits = re.sub(r"\D", "", str(phone))
    if not digits:
        return ""
    if digits.startswith("0") and len(digits) == 11:
        return "234" + digits[1:]
    if digits.startswith("234") and len(digits) >= 12:
        return digits
    if 10 <= len(digits) <= 15:
        return digits
    return ""


def build_whatsapp_url(phone: str) -> str:
    normalized = normalize_phone_for_whatsapp(phone)
    if not normalized:
        return ""
    return f"https://wa.me/{normalized}"


# ══════════════════════════════════════════════════════════
# POPUP HANDLERS
# ══════════════════════════════════════════════════════════

async def handle_google_consent(page):
    try:
        current_url = (page.url or "").lower()
        if (
            "consent.google.com" not in current_url
            and "consent" not in current_url
        ):
            return

        print("🟡 Consent page detected...")

        for text in [
            "Accept all", "I agree", "Accept",
            "Reject all", "Reject", "Continue", "Agree",
        ]:
            try:
                btn = page.get_by_role("button", name=text)
                if await btn.count() > 0:
                    await btn.first.click(timeout=4000)
                    print(f"✅ Consent: {text}")
                    await async_random_delay(2, 4)
                    return
            except Exception:
                pass

        try:
            buttons = await page.query_selector_all("button")
            for btn in buttons:
                label = (
                    await btn.inner_text()
                ).strip().lower()
                if any(
                    k in label
                    for k in [
                        "accept", "agree",
                        "reject", "continue",
                    ]
                ):
                    await btn.click()
                    await async_random_delay(2, 4)
                    return
        except Exception:
            pass

    except Exception as e:
        print(f"⚠️ Consent error: {e}")


async def dismiss_google_maps_app_prompt(page):
    try:
        for text in [
            "Continue", "Go back to web", "Not now",
            "Use web version", "Open in browser", "Skip",
        ]:
            try:
                btn = page.get_by_role(
                    "button",
                    name=re.compile(text, re.I),
                )
                if await btn.count() > 0:
                    await btn.first.click(timeout=3000)
                    await async_random_delay(1, 2)
                    return
            except Exception:
                pass
    except Exception as e:
        print(f"⚠️ App prompt error: {e}")


async def handle_all_popups(page):
    await handle_google_consent(page)
    await dismiss_google_maps_app_prompt(page)


# ══════════════════════════════════════════════════════════
# SAFE NAVIGATION WITH RETRY
# ══════════════════════════════════════════════════════════

async def safe_goto(
    page, url: str, retries: int = MAX_RETRIES
) -> bool:
    for attempt in range(retries + 1):
        try:
            if attempt > 0:
                print(f"   🔄 Retry {attempt}/{retries}...")
                await async_random_delay(3, 6)

            await page.goto(
                url,
                wait_until="domcontentloaded",
                timeout=PAGE_TIMEOUT,
            )
            return True

        except Exception as e:
            error_msg = str(e).lower()

            if "timeout" in error_msg:
                print(
                    f"   ⏱️ Timeout attempt {attempt + 1} — "
                    f"{'retrying' if attempt < retries else 'giving up'}"
                )
                continue

            if any(
                x in error_msg
                for x in ["net::", "connection", "refused"]
            ):
                print(
                    f"   🔌 Connection error {attempt + 1} — "
                    f"{'retrying' if attempt < retries else 'giving up'}"
                )
                continue

            print(f"   ❌ Navigation error: {e}")
            return False

    return False


async def safe_goto_detail(
    page, url: str, retries: int = MAX_RETRIES
) -> bool:
    for attempt in range(retries + 1):
        try:
            if attempt > 0:
                print(
                    f"   🔄 Detail retry {attempt}/{retries}..."
                )
                await async_random_delay(2, 4)

            await page.goto(
                url,
                wait_until="domcontentloaded",
                timeout=DETAIL_TIMEOUT,
            )
            return True

        except Exception as e:
            error_msg = str(e).lower()
            if (
                "timeout" in error_msg
                or "net::" in error_msg
            ):
                print(
                    f"   ⏱️ Detail timeout attempt "
                    f"{attempt + 1}"
                )
                continue
            print(f"   ❌ Detail error: {e}")
            return False

    return False


# ══════════════════════════════════════════════════════════
# MAIN ASYNC SCRAPER
# ══════════════════════════════════════════════════════════

async def scrape_google_maps(
    keyword: str,
    location: str,
    max_results: int = MAX_RESULTS,
) -> list:
    """
    Scrape Google Maps listings.
    Stamps every lead with source, city, location, country.
    Skips businesses already in the database.
    """
    parts   = [p.strip() for p in location.split(",")]
    city    = parts[0] if parts else location
    country = parts[-1] if len(parts) > 1 else ""

    search_query = f"{keyword} {location}".strip()
    search_url   = (
        f"{BASE_URL}/maps/search/"
        f"{search_query.replace(' ', '+')}"
    )

    # ── Pre-load existing names for this keyword+city ──
    existing_names = get_existing_names_bulk(keyword, city)

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=HEADLESS_MODE,
            args=get_stealth_args(),
        )

        context = await browser.new_context(
            viewport={"width": 1440, "height": 900},
            user_agent=get_random_user_agent(),
            locale="en-GB",
            timezone_id="Europe/London",
            is_mobile=False,
            has_touch=False,
            device_scale_factor=1,
        )

        page  = await context.new_page()
        await apply_stealth(page)

        leads = []

        try:
            print(f"🔍 Google Maps: {search_url}")

            success = await safe_goto(page, search_url)

            if not success:
                print(
                    "❌ Failed to load Google Maps "
                    "after retries"
                )
                return []

            await async_random_delay(3, 6)
            await handle_all_popups(page)
            await async_random_delay(2, 4)

            raw_leads = await extract_all_listings(
                page,
                browser,
                max_results,
                existing_names,   # ← pass existing names
            )

            # Stamp location + source
            for lead in raw_leads:
                lead["source"]   = "google_maps"
                lead["industry"] = keyword
                if not lead.get("city"):
                    lead["city"] = city
                if not lead.get("location"):
                    lead["location"] = location
                if not lead.get("country"):
                    lead["country"] = country

            leads = raw_leads

        except Exception as e:
            print(f"❌ Scraping error: {e}")
            import traceback
            traceback.print_exc()

        finally:
            await browser.close()

    print(f"✅ Google Maps done: {len(leads)} leads")
    return leads


# ══════════════════════════════════════════════════════════
# LISTING COLLECTOR
# ══════════════════════════════════════════════════════════

async def extract_all_listings(
    page,
    browser,
    max_results: int,
    existing_names: set = None,   # ← pre-loaded DB names
) -> list:

    if existing_names is None:
        existing_names = set()

    all_leads  = []
    seen_names = set()
    urls       = []
    seen_urls  = set()

    await async_random_delay(2, 4)

    scroll_attempts     = 0
    max_scroll_attempts = 15

    while (
        len(urls) < max_results * 2
        and scroll_attempts < max_scroll_attempts
    ):
        try:
            for selector in [
                "a.hfpxzc",
                "a[href*='/maps/place/']",
            ]:
                locator = page.locator(selector)
                count   = await locator.count()

                for i in range(count):
                    try:
                        el   = locator.nth(i)
                        href = await el.get_attribute("href")
                        if not href:
                            continue
                        full_url = urljoin(BASE_URL, href)
                        if full_url not in seen_urls:
                            seen_urls.add(full_url)
                            urls.append(full_url)
                        if len(urls) >= max_results * 2:
                            break
                    except Exception:
                        continue

                if len(urls) >= max_results * 2:
                    break

            print(f"   📍 {len(urls)} URLs collected")

            try:
                await page.evaluate("""
                    const feed = document.querySelector(
                        'div[role="feed"]'
                    );
                    if (feed) feed.scrollTop += 1500;
                    else window.scrollBy(0, 1500);
                """)
            except Exception:
                pass

            await async_random_delay(2, 4)
            scroll_attempts += 1

        except Exception as e:
            print(f"   Scroll error: {e}")
            scroll_attempts += 1

    if not urls:
        print("⚠️ No URLs — HTML fallback")
        fallback = await extract_via_html(page)
        for lead in fallback:
            name = lead.get("business_name", "")
            if not name or is_bad_business_name(name):
                continue
            name_lower = name.strip().lower()
            # ── Skip if already in DB ──
            if name_lower in existing_names:
                print(f"   ⏭️ Already in DB: {name}")
                continue
            if name in seen_names:
                continue
            seen_names.add(name)
            lead["whatsapp_url"] = build_whatsapp_url(
                lead.get("phone", "")
            )
            all_leads.append(lead)
        return all_leads[:max_results]

    detail_page = await browser.new_page(
        viewport={"width": 1440, "height": 900},
        user_agent=get_random_user_agent(),
        locale="en-GB",
    )
    await apply_stealth(detail_page)

    try:
        for url in urls:
            if len(all_leads) >= max_results:
                break

            try:
                # ── FAST PRE-CHECK ──
                # Extract name from URL before loading page
                # Google Maps URLs contain the place name
                url_name = ""
                url_match = re.search(
                    r"/maps/place/([^/@]+)", url
                )
                if url_match:
                    url_name = url_match.group(1)
                    url_name = url_name.replace(
                        "+", " "
                    ).replace("%20", " ").strip()
                    url_name_lower = url_name.lower()

                    # Check against existing DB names
                    if url_name_lower in existing_names:
                        print(
                            f"   ⏭️ Skip (in DB): {url_name}"
                        )
                        continue

                    # Check against already seen this run
                    if url_name in seen_names:
                        print(
                            f"   ⏭️ Skip (seen): {url_name}"
                        )
                        continue

                # ── Load detail page ──
                lead = await extract_from_listing_url(
                    detail_page, url
                )

                if not lead:
                    continue

                name = clean_business_name(
                    lead.get("business_name", "")
                )

                if not name or is_bad_business_name(name):
                    print(f"   ⛔ Bad name: {name}")
                    continue

                name_lower = name.strip().lower()

                # ── Skip if already in DB ──
                if name_lower in existing_names:
                    print(f"   ⏭️ Already in DB: {name}")
                    continue

                # ── Skip if seen this run ──
                if name in seen_names:
                    continue

                lead["business_name"] = name
                lead["whatsapp_url"]  = build_whatsapp_url(
                    lead.get("phone", "")
                )
                lead["maps_url"] = url

                seen_names.add(name)

                # Add to existing set so later
                # URLs in same run don't re-check DB
                existing_names.add(name_lower)

                all_leads.append(lead)

                print(
                    f"   ✅ {lead['business_name']} | "
                    f"📞 {lead.get('phone','—')} | "
                    f"⭐ {lead.get('rating', 0)}"
                )

                await async_random_delay(2, 3)

            except Exception as e:
                print(f"   ⚠️ {e}")
                continue

    finally:
        await detail_page.close()

    return all_leads[:max_results]


# ══════════════════════════════════════════════════════════
# DETAIL PAGE EXTRACTOR
# ══════════════════════════════════════════════════════════

async def extract_from_listing_url(
    page, url: str
) -> dict:
    lead = {
        "business_name": "",
        "phone":         "",
        "website":       "",
        "address":       "",
        "rating":        0.0,
        "reviews":       0,
        "has_instagram": 0,
        "instagram_url": "",
        "whatsapp_url":  "",
        "maps_url":      url,
    }

    try:
        success = await safe_goto_detail(page, url)

        if not success:
            print(f"   ⏭️ Skipping — could not load page")
            return lead

        await async_random_delay(2, 4)
        await handle_all_popups(page)
        await async_random_delay(1, 2)

        try:
            await page.wait_for_selector(
                "h1", timeout=SELECTOR_TIMEOUT
            )
        except Exception:
            pass

        lead = await extract_detail_panel(page, lead)

    except Exception as e:
        print(f"   Listing error: {e}")

    return lead


async def extract_detail_panel(
    page, lead: dict
) -> dict:
    try:
        page_text = ""
        content   = ""

        try:
            page_text = await page.inner_text("body")
        except Exception:
            pass

        try:
            content = await page.content()
        except Exception:
            pass

        soup = (
            BeautifulSoup(content, "lxml")
            if content else None
        )

        error_signals = [
            "before you continue",
            "this site can't be reached",
            "enable javascript", "just a moment",
            "access denied", "captcha",
            "not a robot", "err_connection_refused",
            "err_name_not_resolved",
        ]

        page_text_lower = (
            page_text.lower() if page_text else ""
        )
        for signal in error_signals:
            if signal in page_text_lower[:500]:
                print(f"   ⛔ Error page: {signal}")
                return lead

        # ── Business Name ──
        try:
            name_el = await page.query_selector("h1")
            if name_el:
                name = (
                    await name_el.inner_text()
                ).strip()
                if name and not is_bad_business_name(name):
                    lead["business_name"] = (
                        clean_business_name(name)
                    )
        except Exception:
            pass

        if not lead.get("business_name") and page_text:
            first_line = next(
                (
                    line.strip()
                    for line in page_text.splitlines()
                    if line.strip()
                ),
                "",
            )
            if not is_bad_business_name(first_line):
                lead["business_name"] = (
                    clean_business_name(first_line)
                )

        # ── Rating ──
        try:
            rating_match = re.search(
                r"\b([1-5]\.[0-9])\b", page_text
            )
            if rating_match:
                lead["rating"] = float(
                    rating_match.group(1)
                )
        except Exception:
            pass

        # ── Reviews ──
        try:
            for pattern in [
                r"([\d,]+)\s+reviews?",
                r"\(([\d,]+)\)",
            ]:
                m = re.search(
                    pattern, page_text, re.IGNORECASE
                )
                if m:
                    lead["reviews"] = int(
                        m.group(1).replace(",", "")
                    )
                    break
        except Exception:
            pass

        # ── Phone ──
        try:
            tel_link = await page.query_selector(
                "a[href^='tel:']"
            )
            if tel_link:
                href = await tel_link.get_attribute(
                    "href"
                )
                if href:
                    lead["phone"] = href.replace(
                        "tel:", ""
                    ).strip()

            if not lead.get("phone"):
                for selector in [
                    "button[data-item-id*='phone']",
                    "a[data-item-id*='phone']",
                    "[aria-label*='phone' i]",
                    "[aria-label*='call' i]",
                ]:
                    el = await page.query_selector(
                        selector
                    )
                    if el:
                        txt = await el.inner_text()
                        if txt and txt.strip():
                            lead["phone"] = txt.strip()
                            break

            if not lead.get("phone"):
                lead["phone"] = extract_phone_from_text(
                    page_text
                )

        except Exception:
            pass

        # ── Website ──
        try:
            for selector in [
                "a[data-item-id='authority']",
                "a[aria-label*='Website' i]",
            ]:
                web_el = await page.query_selector(
                    selector
                )
                if web_el:
                    href = await web_el.get_attribute(
                        "href"
                    )
                    if (
                        href
                        and "google" not in href.lower()
                    ):
                        lead["website"] = href
                        break

            if not lead.get("website") and soup:
                for a in soup.find_all("a", href=True):
                    href = a.get("href", "")
                    if href and href.startswith("http"):
                        low = href.lower()
                        if (
                            "google" not in low
                            and "maps" not in low
                            and "tel:" not in low
                            and "javascript" not in low
                        ):
                            lead["website"] = href
                            break
        except Exception:
            pass

        # ── Address ──
        try:
            for selector in [
                "button[data-item-id='address']",
                "[aria-label*='address' i]",
                "button[data-tooltip='Copy address']",
            ]:
                addr_el = await page.query_selector(
                    selector
                )
                if addr_el:
                    addr_text = await addr_el.inner_text()
                    if addr_text and addr_text.strip():
                        lead["address"] = (
                            addr_text.strip()
                        )
                        break
        except Exception:
            pass

        # ── Instagram ──
        try:
            if (
                page_text
                and "instagram" in page_text.lower()
            ):
                insta_match = re.search(
                    r"instagram\.com/([a-zA-Z0-9_.]+)",
                    page_text,
                    re.IGNORECASE,
                )
                if insta_match:
                    handle = insta_match.group(1).strip()
                    lead["has_instagram"] = 1
                    lead["instagram_url"] = (
                        f"https://instagram.com/{handle}"
                    )
                else:
                    lead["has_instagram"] = 1
        except Exception:
            pass

        lead["whatsapp_url"] = build_whatsapp_url(
            lead.get("phone", "")
        )

    except Exception as e:
        print(f"   Detail panel error: {e}")

    return lead


# ══════════════════════════════════════════════════════════
# HTML FALLBACK
# ══════════════════════════════════════════════════════════

async def extract_via_html(page) -> list:
    leads = []
    try:
        content = await page.content()
        soup    = BeautifulSoup(content, "lxml")

        candidates = soup.find_all(
            "div",
            {"class": re.compile(
                r"fontHeadline|qBF1Pd|NrDZNb|Nv2PK"
            )},
        )

        for tag in candidates:
            text = tag.get_text(" ", strip=True)
            if text and len(text) > 2:
                name = clean_business_name(
                    text.split("•")[0].strip()
                )
                if not name or is_bad_business_name(name):
                    continue

                leads.append({
                    "business_name": name,
                    "phone":         "",
                    "website":       "",
                    "address":       "",
                    "rating":        0.0,
                    "reviews":       0,
                    "has_instagram": 0,
                    "instagram_url": "",
                    "whatsapp_url":  "",
                    "maps_url":      "",
                })
    except Exception as e:
        print(f"HTML fallback error: {e}")

    return leads


# ══════════════════════════════════════════════════════════
# SYNC WRAPPER — Called by job_manager
# nest_asyncio makes asyncio.run() safe inside Streamlit
# ══════════════════════════════════════════════════════════

def scrape_sync(
    keyword: str,
    location: str,
    max_results: int = MAX_RESULTS,
) -> list:
    """
    Synchronous wrapper.
    Uses ProactorEventLoop on Windows for Playwright
    subprocess support.
    """
    if sys.platform == "win32":
        loop = asyncio.ProactorEventLoop()
    else:
        loop = asyncio.new_event_loop()

    try:
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(
            scrape_google_maps(
                keyword, location, max_results
            )
        )
    finally:
        try:
            loop.close()
        except Exception:
            pass
from __future__ import annotations

import re
from typing import Any

# ─────────────────────────────────────────────────────────
# PHONE / COUNTRY MAPS
# ─────────────────────────────────────────────────────────

DIAL_CODE_TO_COUNTRY = {
    "234": "Nigeria",
    "233": "Ghana",
    "254": "Kenya",
    "27": "South Africa",
    "44": "United Kingdom",
    "353": "Ireland",
    "1": "United States",
    "91": "India",
    "880": "Bangladesh",
    "92": "Pakistan",
    "94": "Sri Lanka",
    "62": "Indonesia",
    "63": "Philippines",
    "60": "Malaysia",
    "65": "Singapore",
    "66": "Thailand",
    "84": "Vietnam",
    "971": "United Arab Emirates",
    "966": "Saudi Arabia",
    "20": "Egypt",
    "55": "Brazil",
    "52": "Mexico",
    "57": "Colombia",
    "54": "Argentina",
    "56": "Chile",
    "1": "Canada",
    "61": "Australia",
    "64": "New Zealand",
    "49": "Germany",
    "33": "France",
    "39": "Italy",
    "34": "Spain",
    "31": "Netherlands",
    "32": "Belgium",
    "41": "Switzerland",
    "43": "Austria",
    "46": "Sweden",
    "47": "Norway",
    "45": "Denmark",
    "358": "Finland",
    "48": "Poland",
}

NIGERIA_STYLE_COUNTRIES = {
    "nigeria", "ghana", "kenya", "south africa", "egypt",
    "india", "pakistan", "bangladesh", "sri lanka",
    "indonesia", "philippines", "malaysia", "singapore",
    "thailand", "vietnam", "uae", "united arab emirates",
    "saudi arabia", "brazil", "mexico", "colombia",
    "argentina", "chile",
}

UK_STYLE_COUNTRIES = {
    "united kingdom", "uk", "ireland", "germany", "france",
    "italy", "spain", "netherlands", "belgium", "switzerland",
    "austria", "sweden", "norway", "denmark", "finland", "poland",
}

MARKET_BUCKETS = {
    "nigeria": "nigeria",
    "ghana": "africa",
    "kenya": "africa",
    "south africa": "africa",
    "egypt": "africa",
    "united kingdom": "uk",
    "uk": "uk",
    "ireland": "uk",
    "united states": "north_america",
    "canada": "north_america",
    "australia": "oceania",
    "new zealand": "oceania",
    "india": "asia",
    "pakistan": "asia",
    "bangladesh": "asia",
    "sri lanka": "asia",
    "indonesia": "asia",
    "philippines": "asia",
    "malaysia": "asia",
    "singapore": "asia",
    "thailand": "asia",
    "vietnam": "asia",
    "uae": "middle_east",
    "united arab emirates": "middle_east",
    "saudi arabia": "middle_east",
    "brazil": "latam",
    "mexico": "latam",
    "colombia": "latam",
    "argentina": "latam",
    "chile": "latam",
    "germany": "europe",
    "france": "europe",
    "italy": "europe",
    "spain": "europe",
    "netherlands": "europe",
    "belgium": "europe",
    "switzerland": "europe",
    "austria": "europe",
    "sweden": "europe",
    "norway": "europe",
    "denmark": "europe",
    "finland": "europe",
    "poland": "europe",
}

TIMEZONE_BY_COUNTRY = {
    "nigeria": "Africa/Lagos",
    "ghana": "Africa/Accra",
    "kenya": "Africa/Nairobi",
    "south africa": "Africa/Johannesburg",
    "united kingdom": "Europe/London",
    "uk": "Europe/London",
    "ireland": "Europe/Dublin",
    "united states": "America/New_York",
    "canada": "America/Toronto",
    "india": "Asia/Kolkata",
    "uae": "Asia/Dubai",
    "united arab emirates": "Asia/Dubai",
    "saudi arabia": "Asia/Riyadh",
    "brazil": "America/Sao_Paulo",
    "mexico": "America/Mexico_City",
    "colombia": "America/Bogota",
    "argentina": "America/Argentina/Buenos_Aires",
    "chile": "America/Santiago",
    "australia": "Australia/Sydney",
    "new zealand": "Pacific/Auckland",
}

SOURCE_HINTS = {
    "companies house": "United Kingdom",
    "google maps uk": "United Kingdom",
    "uk": "United Kingdom",
    "nigeria": "Nigeria",
}


def _norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().casefold()


def _digits(value: Any) -> str:
    return re.sub(r"\D", "", str(value or ""))


def _phone_country_code(phone: str) -> tuple[str, str]:
    """
    Returns (dial_code, country) by longest-prefix match.
    """
    digits = _digits(phone)
    if not digits:
        return "", ""

    codes = sorted(DIAL_CODE_TO_COUNTRY.keys(), key=len, reverse=True)
    for code in codes:
        if digits.startswith(code):
            return code, DIAL_CODE_TO_COUNTRY[code]
    return "", ""


def _detect_country_from_text(*parts: Any) -> str:
    haystack = " | ".join(_norm(p) for p in parts if p)
    for hint, country in SOURCE_HINTS.items():
        if hint in haystack:
            return country

    for country in DIAL_CODE_TO_COUNTRY.values():
        if _norm(country) in haystack:
            return country

    return ""


def get_market_bucket(country: str) -> str:
    country_n = _norm(country)
    return MARKET_BUCKETS.get(country_n, "other")


def get_timezone(country: str) -> str:
    return TIMEZONE_BY_COUNTRY.get(_norm(country), "UTC")


def get_market_profile(country: str) -> dict:
    market = get_market_bucket(country)

    if market == "nigeria":
        return {
            "market": market,
            "preferred_channels": ["whatsapp", "call", "email"],
            "wa_primary": True,
            "tone": "friendly",
        }

    if market in {"africa", "latam", "asia", "middle_east"}:
        return {
            "market": market,
            "preferred_channels": ["whatsapp", "call", "email"],
            "wa_primary": True,
            "tone": "friendly",
        }

    if market == "uk" or market == "europe":
        return {
            "market": market,
            "preferred_channels": ["email", "call", "whatsapp_verified"],
            "wa_primary": False,
            "tone": "formal",
        }

    return {
        "market": market,
        "preferred_channels": ["call", "email", "whatsapp_verified"],
        "wa_primary": False,
        "tone": "direct",
    }


def enrich_lead_with_country(lead: dict) -> dict:
    """
    Populates country, market, timezone and phone_country_code.
    Safe to call repeatedly.
    """
    lead = dict(lead or {})

    phone = lead.get("phone") or lead.get("phone_number") or ""
    country = _norm(lead.get("country"))
    market = _norm(lead.get("market"))
    timezone = lead.get("timezone") or ""
    country_confidence = _norm(lead.get("country_confidence")) or "low"
    phone_country_code = _digits(lead.get("phone_country_code"))

    if phone:
        code, detected_country = _phone_country_code(phone)
        if code and not phone_country_code:
            phone_country_code = code
        if detected_country and not country:
            country = detected_country
            country_confidence = "high"

    if not country:
        detected = _detect_country_from_text(
            lead.get("location"),
            lead.get("city"),
            lead.get("source"),
            lead.get("address"),
            lead.get("website"),
        )
        if detected:
            country = detected
            country_confidence = "medium"

    if country and not market:
        market = get_market_bucket(country)

    if country and not timezone:
        timezone = get_timezone(country)

    lead["country"] = country.title() if country else ""
    lead["market"] = market
    lead["timezone"] = timezone
    lead["phone_country_code"] = phone_country_code
    lead["country_confidence"] = country_confidence

    return lead
# engine/scorer.py
# KNCS LeadGen Pro — v9.7 Premium
# AI scoring + website audit + website discovery + deep enrichment
# + search intent + country-aware routing
# Owner: Amechi — Offer: Professional Website Design ONLY

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sqlite3
import time
from datetime import datetime
from typing import Any
from urllib.parse import quote_plus, urlparse

import requests
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────
# DB PATH — read from env / config, never hardcoded
# ─────────────────────────────────────────────────────────
try:
    from config import DB_PATH
except Exception:
    DB_PATH = os.getenv("KNCS_DB_PATH", "data/leads.db")

# ─────────────────────────────────────────────────────────
# DB CONNECTION — use database.py helper (WAL + thread-safe)
# ─────────────────────────────────────────────────────────
try:
    from database import get_connection as _get_db_connection
    _DB_HELPER_AVAILABLE = True
except Exception:
    _DB_HELPER_AVAILABLE = False

    def _get_db_connection():
        conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn


# ─────────────────────────────────────────────────────────
# AI CLIENT
# ─────────────────────────────────────────────────────────
try:
    from engine.ai_client import call_ai, is_circuit_open
    _AI_CLIENT_AVAILABLE = True
except ImportError:
    _AI_CLIENT_AVAILABLE = False
    logger.warning("engine/ai_client.py not found — AI scoring disabled.")

    def call_ai(*args, **kwargs) -> str:
        return ""

    def is_circuit_open() -> bool:
        return False


# ─────────────────────────────────────────────────────────
# COUNTRY ROUTER
# ─────────────────────────────────────────────────────────
try:
    from engine.country_router import enrich_lead_with_country
    _COUNTRY_ROUTER_AVAILABLE = True
except Exception:
    _COUNTRY_ROUTER_AVAILABLE = False

    def enrich_lead_with_country(lead: dict) -> dict:
        return lead


# ─────────────────────────────────────────────────────────
# CHANNEL ROUTER
# ─────────────────────────────────────────────────────────
try:
    from engine.router import assign_channel
    _ROUTER_AVAILABLE = True
except Exception:
    _ROUTER_AVAILABLE = False

    def assign_channel(lead: dict) -> dict:
        return {}


# ─────────────────────────────────────────────────────────
# SEARCH INTENT
# ─────────────────────────────────────────────────────────
try:
    from engine.search_intent import get_search_phrase, get_search_intent_line
    _INTENT_AVAILABLE = True
except Exception:
    _INTENT_AVAILABLE = False

    def get_search_phrase(industry: str, city: str = "") -> str:
        return ""

    def get_search_intent_line(
        industry: str, city: str = "", tone: str = "friendly"
    ) -> str:
        return ""


# ─────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────

BANNED_PHRASES = [
    "strong online presence",
    "get more customers automatically",
    "businesses like yours",
    "digital marketing",
    "take your business to the next level",
    "in today's digital world",
    "online visibility",
    "brand awareness",
    "social media presence",
    "cutting-edge",
    "state-of-the-art",
]

_MIN_BATCH_DELAY   = 1.5
_SHORT_BATCH_DELAY = 1.5

# Domains excluded from website discovery results
EXCLUDED_DOMAINS = {
    "google.com", "google.com.ng", "facebook.com", "instagram.com",
    "twitter.com", "x.com", "youtube.com", "linkedin.com",
    "yelp.com", "tripadvisor.com", "yellowpages.com",
    "maps.google.com", "goo.gl", "foursquare.com",
    "wikipedia.org", "businesslist.com.ng", "vconnect.com",
    "whogohost.com", "nairaland.com", "jumia.com.ng",
    "jiji.ng", "olx.com.ng", "nigeria-property-centre.com",
    "privateproperty.com.ng", "propertypro.ng",
}

# Common words that should NOT count as a business name match in a domain
_GENERIC_WORDS = {
    "hotel", "school", "prime", "best", "top", "first", "global",
    "royal", "grand", "new", "city", "main", "central", "digital",
    "tech", "care", "home", "plus", "pro", "max", "star",
}

NIGERIA_TLDS = [
    ".com.ng", ".ng", ".edu.ng", ".sch.ng",
    ".org.ng", ".gov.ng", ".net.ng",
    ".com", ".org", ".net", ".co",
]

# Max slug length for domain guessing — real domains are rarely > 20 chars
_MAX_SLUG_LEN = 20

_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

# Fields that should not be overwritten with empty string on re-score
_NO_OVERWRITE_WITH_EMPTY = {
    "phone", "email", "website",
    "decision_maker_name", "decision_maker_title",
}

# WA status values that are actual WA states (not generic verification)
_VALID_WA_STATUSES = {
    "verified", "estimated", "opted_in",
    "business_confirmed", "unknown",
}


# ══════════════════════════════════════════════
# SAFETY HELPERS
# ══════════════════════════════════════════════

def _safe_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _safe_int(value: Any) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def _contains_banned(text: str) -> bool:
    low = text.lower()
    return any(phrase in low for phrase in BANNED_PHRASES)


def _sanitise_opener(opener: str, lead: dict) -> str:
    if not opener or _contains_banned(opener):
        return _build_specific_opener(lead)
    return opener.strip()


def _prompt_hash(prompt: str) -> str:
    return hashlib.sha256(
        str(prompt or "").encode("utf-8", errors="ignore")
    ).hexdigest()


def _clean_url(url: str) -> str:
    url = url.strip().rstrip("/")
    if not url.startswith("http"):
        url = "https://" + url
    return url


def _domain_from_url(url: str) -> str:
    try:
        return urlparse(url).netloc.lower().replace("www.", "")
    except Exception:
        return ""


def _no_website(value: str) -> bool:
    """Return True if the value represents an absent/unknown website."""
    return (
        not value
        or value.lower() in {"", "none", "n/a", "not found", "no website", "no website found"}
        or len(value) <= 4
    )


def _get_wa_status(lead: dict) -> str:
    """
    FIX: Extract canonical WA status without contaminating with
    'unverified' from verification_status field.
    """
    wa = str(lead.get("wa_status") or "").strip().lower()
    if wa in _VALID_WA_STATUSES:
        return wa
    return "unknown"


# ══════════════════════════════════════════════
# WEBSITE DISCOVERY ENGINE
# ══════════════════════════════════════════════

def _is_business_domain(url: str, business_name: str) -> bool:
    """
    Returns True if a URL looks like it belongs to the business.
    FIX: Generic words (hotel, school, prime etc.) are excluded
    from matching to reduce false positives.
    """
    try:
        domain = _domain_from_url(url)
        if not domain:
            return False

        for excluded in EXCLUDED_DOMAINS:
            if excluded in domain:
                return False

        # Only match on non-generic words longer than 3 chars
        name_words = [
            w.lower()
            for w in re.split(r"[\s\-_&']+", business_name)
            if len(w) > 3 and w.lower() not in _GENERIC_WORDS
        ]
        if any(word in domain for word in name_words):
            return True

        if any(
            tld in domain
            for tld in {".edu.ng", ".sch.ng", ".org.ng", ".gov.ng"}
        ):
            return True

        return False
    except Exception:
        return False


def _check_url_resolves(url: str, timeout: int = 6) -> bool:
    """
    Returns True if the URL resolves with a non-error HTTP status.
    Uses HEAD first (faster), falls back to GET.
    """
    try:
        url = _clean_url(url)
        resp = requests.head(
            url,
            timeout=timeout,
            allow_redirects=True,
            headers=_HEADERS,
        )
        if resp.status_code < 400:
            return True
        # HEAD sometimes returns 405 — try GET
        resp = requests.get(
            url,
            timeout=timeout,
            allow_redirects=True,
            headers=_HEADERS,
        )
        return resp.status_code < 400
    except Exception:
        return False


def _extract_urls_from_html(html: str) -> list:
    """
    FIX: Tighter regex — requires quotes around href value
    to avoid capturing trailing quote characters.
    """
    return re.findall(r'href=["\']((https?://)[^"\'>\s]+)["\']', html)


def _search_duckduckgo(query: str, timeout: int = 10) -> list:
    try:
        url = f"https://html.duckduckgo.com/html/?q={quote_plus(query)}"
        resp = requests.get(url, timeout=timeout, headers=_HEADERS)
        if resp.status_code == 200:
            # _extract_urls_from_html now returns tuples (full_url, scheme)
            pairs = _extract_urls_from_html(resp.text)
            return [p[0] for p in pairs]
    except Exception as exc:
        logger.debug("[website_finder] DuckDuckGo search failed: %s", exc)
    return []


def _search_bing(query: str, timeout: int = 10) -> list:
    try:
        url = f"https://www.bing.com/search?q={quote_plus(query)}"
        resp = requests.get(url, timeout=timeout, headers=_HEADERS)
        if resp.status_code == 200:
            pairs = _extract_urls_from_html(resp.text)
            return [p[0] for p in pairs]
    except Exception as exc:
        logger.debug("[website_finder] Bing search failed: %s", exc)
    return []


def discover_business_website(
    business_name: str,
    city: str = "",
    country: str = "",
    industry: str = "",
    timeout: int = 6,
) -> dict:
    """
    Searches the web for the real website of a business.

    Strategy:
      1. DuckDuckGo search
      2. Bing fallback
      3. Direct domain guessing (slug ≤ 20 chars)

    Returns:
        {
            "found": bool,
            "url": str,
            "confidence": "high" | "medium" | "low" | "none",
            "source": "search" | "domain_guess" | "none",
            "checked": bool,
        }
    """
    if not business_name:
        return {
            "found": False, "url": "", "confidence": "none",
            "source": "none", "checked": False,
        }

    _empty = {
        "found": False, "url": "", "confidence": "none",
        "source": "none", "checked": True,
    }

    for query_suffix in ["official website", "school website", ""]:
        parts = [business_name]
        if city:
            parts.append(city)
        if query_suffix:
            parts.append(query_suffix)

        urls = _search_duckduckgo(" ".join(parts), timeout=timeout)
        for url in urls[:15]:
            if _is_business_domain(url, business_name):
                if _check_url_resolves(url, timeout=timeout):
                    logger.info(
                        "[website_finder] Found via DuckDuckGo: %s → %s",
                        business_name, url,
                    )
                    return {
                        "found": True, "url": url,
                        "confidence": "high", "source": "search",
                        "checked": True,
                    }

    bing_urls = _search_bing(
        f"{business_name} {city} website".strip(), timeout=timeout
    )
    for url in bing_urls[:15]:
        if _is_business_domain(url, business_name):
            if _check_url_resolves(url, timeout=timeout):
                logger.info(
                    "[website_finder] Found via Bing: %s → %s",
                    business_name, url,
                )
                return {
                    "found": True, "url": url,
                    "confidence": "high", "source": "search",
                    "checked": True,
                }

    # Domain guessing — FIX: enforce max slug length
    slug = re.sub(r"[^a-z0-9]", "", business_name.lower())[:_MAX_SLUG_LEN]
    words = re.split(r"\s+", business_name.lower())
    abbrev = "".join(w[0] for w in words if w)[:_MAX_SLUG_LEN]

    tlds = (
        NIGERIA_TLDS
        if str(country or "").lower() in {"nigeria", "ng", ""}
        else [".com", ".org", ".net", ".co"]
    )

    for name_variant in [slug, abbrev]:
        if len(name_variant) < 3:
            continue
        for tld in tlds:
            guess_url = f"https://{name_variant}{tld}"
            if _check_url_resolves(guess_url, timeout=timeout):
                logger.info(
                    "[website_finder] Found via domain guess: %s → %s",
                    business_name, guess_url,
                )
                return {
                    "found": True, "url": guess_url,
                    "confidence": "medium", "source": "domain_guess",
                    "checked": True,
                }

    logger.info("[website_finder] No website found for: %s", business_name)
    return _empty


def enrich_website(lead: dict) -> dict:
    """
    If the lead has no website, searches the web for one.
    FIX: Does NOT overwrite website_discovered=True with False
    if website already exists.
    """
    existing = str(lead.get("website") or "").strip().lower()

    if not _no_website(existing):
        # Already has a website — preserve existing discovery flags
        if "website_discovered" not in lead:
            lead["website_discovered"] = False
        if "website_discovery_confidence" not in lead:
            lead["website_discovery_confidence"] = "existing"
        if "website_discovery_source" not in lead:
            lead["website_discovery_source"] = "original"
        return lead

    result = discover_business_website(
        business_name=lead.get("business_name", ""),
        city=lead.get("city", ""),
        country=lead.get("country", ""),
        industry=lead.get("industry", ""),
    )

    if result["found"]:
        lead["website"] = result["url"]
        lead["website_discovered"] = True
        lead["website_discovery_confidence"] = result["confidence"]
        lead["website_discovery_source"] = result["source"]
        logger.info(
            "[enrich_website] Discovered website for %s: %s",
            lead.get("business_name", "unknown"), result["url"],
        )
    else:
        lead["website_discovered"] = False
        lead["website_discovery_confidence"] = "none"
        lead["website_discovery_source"] = "none"

    return lead


# ══════════════════════════════════════════════
# DEEP ENRICHMENT — Decision Maker + Phone
# ══════════════════════════════════════════════

def _extract_phones_from_text(text: str) -> list:
    patterns = [
        r"\+234[\s\-]?\d{3}[\s\-]?\d{3}[\s\-]?\d{4}",
        r"0[789]\d{9}",
        r"\+44[\s\-]?\d{3,4}[\s\-]?\d{6,7}",
        r"\+1[\s\-]?\(?\d{3}\)?[\s\-]?\d{3}[\s\-]?\d{4}",
        r"\+\d{1,3}[\s\-]?\d{6,14}",
    ]
    found = []
    for pattern in patterns:
        found.extend(re.findall(pattern, text))

    cleaned = []
    seen: set = set()
    for phone in found:
        clean = re.sub(r"[\s\-\(\)]", "", phone)
        if clean not in seen and len(clean) >= 10:
            seen.add(clean)
            cleaned.append(clean)
    return cleaned


def _extract_emails_from_text(text: str) -> list:
    pattern = r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
    found = re.findall(pattern, text)
    excluded = {"example.com", "email.com", "domain.com", "yourmail.com"}
    return [
        e.lower() for e in found
        if not any(ex in e.lower() for ex in excluded)
    ]


def _extract_names_from_text(text: str) -> list:
    triggers = [
        r"(?:principal|director|proprietor|proprietress|ceo|md|"
        r"managing director|owner|head teacher|headmaster|headmistress|"
        r"founded by|established by|contact|manager)\s*[:\-]?\s*"
        r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})",
    ]
    found = []
    for pattern in triggers:
        found.extend(re.findall(pattern, text, re.IGNORECASE))
    return list(dict.fromkeys(found))


def _scrape_website_for_contacts(url: str, timeout: int = 8) -> dict:
    """
    FIX: timeout reduced to 8s per page. Checks home + /contact only
    (removed /about to reduce per-lead time from ~30s to ~16s max).
    """
    result: dict = {
        "phones": [],
        "emails": [],
        "names": [],
        "about_text": "",
    }

    # FIX: 2 pages only (not 3) to limit batch time
    pages_to_check = [url, url.rstrip("/") + "/contact"]

    all_text = ""
    for page_url in pages_to_check:
        try:
            resp = requests.get(
                _clean_url(page_url),
                timeout=timeout,
                headers=_HEADERS,
                allow_redirects=True,
            )
            if resp.status_code < 400:
                raw = re.sub(r"<[^>]+>", " ", resp.text)
                raw = re.sub(r"\s+", " ", raw).strip()
                all_text += " " + raw[:6000]
        except Exception as exc:
            logger.debug("[deep_enrich] Page fetch failed %s: %s", page_url, exc)

    if all_text:
        result["phones"]     = _extract_phones_from_text(all_text)
        result["emails"]     = _extract_emails_from_text(all_text)
        result["names"]      = _extract_names_from_text(all_text)
        result["about_text"] = all_text[:800]

    return result


def _search_decision_maker_web(
    business_name: str,
    city: str = "",
    timeout: int = 8,
) -> dict:
    """
    FIX: Replaces _search_linkedin_public.
    DDG does not support site: operators in HTML endpoint.
    Uses plain keyword search instead, extracting names from snippets.
    """
    result = {
        "decision_maker_name": "",
        "decision_maker_title": "",
        "source": "web_search",
        "confidence": "low",
    }

    query = (
        f'"{business_name}" {city} '
        f"director OR principal OR owner OR CEO OR proprietor"
    )

    try:
        resp = requests.get(
            f"https://html.duckduckgo.com/html/?q={quote_plus(query)}",
            timeout=timeout,
            headers=_HEADERS,
        )
        if resp.status_code != 200:
            return result

        snippet_text = re.sub(r"<[^>]+>", " ", resp.text)
        snippet_text = re.sub(r"\s+", " ", snippet_text)[:6000]

        names = _extract_names_from_text(snippet_text)
        if not names:
            return result

        result["decision_maker_name"] = names[0]
        result["confidence"] = "medium"

        name_escaped = re.escape(names[0])
        title_match = re.search(
            rf"{name_escaped}\s*[,\-–]?\s*"
            r"(Director|Principal|Owner|CEO|MD|Proprietor|"
            r"Head Teacher|Manager|Founder)[^\n]*",
            snippet_text,
            re.IGNORECASE,
        )
        if title_match:
            result["decision_maker_title"] = title_match.group(1).strip()
            result["confidence"] = "high"

    except Exception as exc:
        logger.debug("[dm_search] Web search failed: %s", exc)

    return result


def deep_enrich_lead(lead: dict) -> dict:
    """
    Full enrichment pipeline:
      1. Website discovery
      2. Website contact scraping (phone, email, DM names)
      3. Web search for decision maker

    FIX: Never overwrites existing phone/email with empty string.
    """
    lead = dict(lead)
    lead = enrich_website(lead)

    website = str(lead.get("website") or "").strip()
    has_website = not _no_website(website)
    website_contacts: dict = {}

    if has_website:
        try:
            website_contacts = _scrape_website_for_contacts(website)
        except Exception as exc:
            logger.debug("[deep_enrich] Website scrape failed: %s", exc)

        existing_phone = str(lead.get("phone") or "").strip()
        if not existing_phone and website_contacts.get("phones"):
            lead["phone"] = website_contacts["phones"][0]
            lead["phone_source"] = "website_scraped"

        existing_email = str(lead.get("email") or "").strip()
        if not existing_email and website_contacts.get("emails"):
            lead["email"] = website_contacts["emails"][0]
            lead["email_source"] = "website_scraped"

    existing_dm = str(
        lead.get("decision_maker_name") or
        lead.get("decision_maker_first") or ""
    ).strip()

    if not existing_dm:
        if website_contacts.get("names"):
            lead["decision_maker_name"] = website_contacts["names"][0]
            lead["decision_maker_source"] = "website_scraped"
        else:
            try:
                dm_result = _search_decision_maker_web(
                    business_name=lead.get("business_name", ""),
                    city=lead.get("city", ""),
                )
                if dm_result.get("decision_maker_name"):
                    lead["decision_maker_name"]  = dm_result["decision_maker_name"]
                    lead["decision_maker_title"] = dm_result.get("decision_maker_title", "")
                    lead["decision_maker_source"] = dm_result.get("source", "web_search")
            except Exception as exc:
                logger.debug("[deep_enrich] DM web search failed: %s", exc)

    lead["deep_enriched"]    = True
    lead["deep_enriched_at"] = datetime.utcnow().isoformat()
    return lead


# ══════════════════════════════════════════════
# WEBSITE AUDIT SCORE
# ══════════════════════════════════════════════

def compute_website_audit_score(lead: dict) -> int:
    website = str(lead.get("website") or "").strip().lower()
    rating  = _safe_float(lead.get("rating"))
    reviews = _safe_int(lead.get("reviews"))
    phone   = str(lead.get("phone") or "").strip()
    website_discovered   = bool(lead.get("website_discovered", False))
    discovery_confidence = str(
        lead.get("website_discovery_confidence") or ""
    ).lower()

    has_website = not _no_website(website)

    if not has_website:
        score = 0
        if reviews and reviews > 10:
            score = 1
        if rating and rating >= 4.0 and reviews and reviews > 20:
            score = 2
        # FIX: clamp even in early return
        return max(0, min(10, score))

    if website_discovered:
        score = 3 if discovery_confidence == "high" else 2
    else:
        score = 4

    if reviews:
        if reviews >= 50:
            score += 2
        elif reviews >= 20:
            score += 1
        elif reviews < 5:
            score -= 1

    if rating:
        if rating >= 4.5:
            score += 2
        elif rating >= 4.0:
            score += 1
        elif rating < 3.5:
            score -= 1

    if phone and len(phone) >= 7:
        score += 1

    return max(0, min(10, score))


def _audit_explanation(score: int, lead: dict | None = None) -> str:
    ld = lead or {}
    website_discovered = bool(ld.get("website_discovered", False))
    website_url        = str(ld.get("website") or "").strip()
    discovery_source   = str(ld.get("website_discovery_source") or "").lower()

    if score == 0:
        return (
            f"Website Audit Score: {score}/10 — No website found after "
            "web search. This business is completely invisible online."
        )
    if score <= 2:
        if website_discovered:
            return (
                f"Website Audit Score: {score}/10 — Website found at "
                f"{website_url} (discovered via {discovery_source}) but "
                "not promoted; very weak online signals."
            )
        return (
            f"Website Audit Score: {score}/10 — No website found. "
            "Completely invisible to online searchers."
        )
    if score <= 4:
        if website_discovered:
            return (
                f"Website Audit Score: {score}/10 — Website exists at "
                f"{website_url} (found via web search, not listed in GMB). "
                "Basic site, not optimised, low trust signals."
            )
        return (
            f"Website Audit Score: {score}/10 — Website exists but "
            "weak. Very few reviews and low trust signals."
        )
    if score <= 6:
        return (
            f"Website Audit Score: {score}/10 — Website exists but "
            "lacks optimisation. Low reviews or missing contact features."
        )
    if score <= 8:
        return (
            f"Website Audit Score: {score}/10 — Decent website with "
            "reasonable reviews. Could be stronger with better local SEO "
            "and WhatsApp integration."
        )
    return (
        f"Website Audit Score: {score}/10 — Relatively strong web "
        "presence. Focus pitch on modernisation and conversion."
    )


# ══════════════════════════════════════════════
# OPENER / PROMPT HELPERS
# ══════════════════════════════════════════════

def _build_specific_opener(lead: dict) -> str:
    name     = lead.get("business_name") or "there"
    industry = lead.get("industry") or "your industry"
    city     = lead.get("city") or "your area"
    website  = str(lead.get("website") or "").strip().lower()
    rating   = _safe_float(lead.get("rating"))
    reviews  = _safe_int(lead.get("reviews"))
    audit    = _safe_int(lead.get("website_audit_score"))
    website_discovered = bool(lead.get("website_discovered", False))
    decision_maker = str(
        lead.get("decision_maker_name") or
        lead.get("decision_maker_first") or ""
    ).strip()

    has_website   = not _no_website(website)
    audit_note    = f"(website audit: {audit}/10)"
    intent_phrase = get_search_phrase(industry, city) if _INTENT_AVAILABLE else ""
    intent_line   = (
        f'Most customers search "{intent_phrase}" on Google — '
        f"right now they may not find you easily. "
        if intent_phrase else ""
    )
    greeting = f"Hi {decision_maker}" if decision_maker else f"Hi {name}"

    if not has_website:
        return (
            f"{greeting}, I noticed {name} doesn't appear to have a "
            f"website yet {audit_note}. {intent_line}"
            f"I build websites specifically for local {industry} "
            f"businesses in {city}. Worth a quick chat?"
        )
    if website_discovered:
        return (
            f"{greeting}, I found {name}'s website at {website} — "
            f"but it doesn't appear to be bringing in enquiries "
            f"{audit_note}. {intent_line}"
            f"I help {industry} businesses in {city} turn their "
            f"website into a proper lead generator. "
            f"Worth a 10-minute call?"
        )
    if rating >= 4.0 and reviews >= 20:
        return (
            f"{greeting}, your {rating}★ rating with {reviews} reviews "
            f"is impressive {audit_note} — but your website isn't "
            f"matching that reputation. {intent_line}"
            f"I design sites for {industry} businesses in {city} "
            f"that convert visitors into paying customers."
        )
    if reviews < 10:
        return (
            f"{greeting}, I ran a quick audit on {name}'s website "
            f"{audit_note}. {intent_line}"
            f"The site is live but trust signals are low — "
            f"I build professional websites for {industry} businesses. "
            f"Would you like to see what's possible?"
        )
    return (
        f"{greeting}, I checked {name}'s website {audit_note}. "
        f"{intent_line}"
        f"There's room to improve how it converts visitors. "
        f"I design sites for {industry} businesses in {city}. "
        f"Worth a quick 10-min call?"
    )


def _build_prompt(lead: dict, audit_score: int) -> str:
    """
    FIX: wa_status resolved cleanly (no 'unverified' contamination).
    FIX: intent block only included when intent is available and non-empty.
    """
    audit_note = _audit_explanation(audit_score, lead)
    industry   = lead.get("industry") or "Unknown"
    city       = lead.get("city") or "Unknown"
    country    = lead.get("country") or "Unknown"
    market     = lead.get("market") or "Unknown"

    # FIX: use clean WA status helper
    wa_status  = _get_wa_status(lead)

    website_discovered = bool(lead.get("website_discovered", False))
    decision_maker     = str(
        lead.get("decision_maker_name") or
        lead.get("decision_maker_first") or ""
    ).strip()
    decision_maker_title = str(lead.get("decision_maker_title") or "").strip()

    # Intent block — only include if module available and phrase non-empty
    intent_block = ""
    if _INTENT_AVAILABLE:
        search_phrase = get_search_phrase(industry, city)
        if search_phrase:
            intent_block = (
                f"\nSEARCH INTENT SIGNAL\n"
                f'Customers in {city} search "{search_phrase}" on Google '
                f"before choosing this type of business.\n"
                f"Reference this in the opener to show you understand "
                f"how their customers find them.\n"
            )
    else:
        search_phrase = ""

    # Website context block
    if website_discovered:
        website_context = (
            f"\nWEBSITE DISCOVERY NOTE\n"
            f"The website was NOT listed on Google My Business.\n"
            f"It was found via web search at: {lead.get('website', '')}\n"
            f"This means the business has a site but does not actively "
            f"promote it. Do NOT say 'you have no website'.\n"
            f"Instead focus on: the site is not generating enquiries, "
            f"not optimised, not visible in local search.\n"
        )
    else:
        website_val = str(lead.get("website") or "").strip()
        if _no_website(website_val):
            website_context = (
                f"\nWEBSITE NOTE\n"
                f"Web search confirmed: NO website found for this business.\n"
                f"It is safe to say they have no website.\n"
            )
        else:
            website_context = (
                f"\nWEBSITE NOTE\n"
                f"Website is listed and known: {website_val}\n"
                f"Focus on improvement, not absence.\n"
            )

    decision_maker_block = ""
    if decision_maker:
        decision_maker_block = (
            f"\nDECISION MAKER\n"
            f"Name: {decision_maker}\n"
            f"Title: {decision_maker_title or 'Unknown'}\n"
            f"Address the opener to this person by name.\n"
        )

    return f"""
You are a sales intelligence assistant for KNCS, a professional website
design agency run by Amechi. KNCS sells ONE service only:
professional website design for local service businesses.

Do NOT suggest:
- AI tools, CRM tools, social media management
- Generic "digital marketing"
- Any banned phrase: "strong online presence",
  "get more customers automatically", "businesses like yours",
  "digital marketing", "take your business to the next level"

────────────────────────────────────────
LEAD DETAILS
────────────────────────────────────────
Business Name : {lead.get("business_name", "Unknown")}
Industry      : {industry}
City          : {city}
Country       : {country}
Market        : {market}
Website       : {lead.get("website", "None")}
Rating        : {lead.get("rating", "N/A")}
Reviews       : {lead.get("reviews", "N/A")}
Phone         : {lead.get("phone", "N/A")}
WA Status     : {wa_status}

AUDIT SIGNAL
{audit_note}
{website_context}
{intent_block}
{decision_maker_block}
────────────────────────────────────────
SCORING INSTRUCTIONS
────────────────────────────────────────
Score this lead 1–10 for how urgently they need a NEW or IMPROVED website.

10 = No website at all + active business + reachable
 8 = Has website but weak, low reviews, no WhatsApp integration
 6 = Decent website but could be improved
 4 = Reasonable web presence
 1 = Already strong modern website (low priority)

IMPORTANT:
- If website was DISCOVERED (not in GMB), score 6-8 range.
  They have a site but it is not working hard enough.
- If NO website confirmed, score 8-10.
- If website is listed and strong, score 3-5.

Identify the 2–3 most specific pain points related to their
WEBSITE specifically (not general marketing).

Write ONE recommended_opener — a short first message (2–3 sentences max).

Rules for opener:
- If a decision maker name is provided, address them by name
- Must mention the business name
- Must mention the specific website problem (reference audit score)
- If search phrase provided, include it naturally
- Must mention city or industry
- NEVER say "you have no website" if website_discovered is true
- NEVER use banned phrases listed above
- Must sound human, not robotic
- Maximum 3 sentences

────────────────────────────────────────
RESPOND IN THIS EXACT JSON FORMAT — NO OTHER TEXT:
────────────────────────────────────────
{{
  "fit_score": <integer 1-10>,
  "fit_reason": "<one sentence explaining the score>",
  "pain_points": ["<pain 1>", "<pain 2>", "<pain 3>"],
  "recommended_opener": "<your opener here>"
}}
""".strip()


def _parse_ai_response(text: str) -> dict:
    """
    FIX: Use non-greedy match to avoid capturing multiple JSON objects.
    """
    if not text:
        return {}
    try:
        text = re.sub(r"```(?:json)?", "", text).strip().strip("`").strip()
        # FIX: non-greedy match for innermost/first complete JSON object
        match = re.search(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)?\}", text, re.DOTALL)
        if not match:
            # Fallback: try to parse the whole text
            return json.loads(text)
        return json.loads(match.group())
    except Exception as exc:
        logger.warning("JSON parse failed: %s | text: %s", exc, text[:200])
        return {}


def _default_pain_points(lead: dict, audit_score: int) -> list:
    points = []
    website = str(lead.get("website") or "").strip().lower()
    no_web  = _no_website(website)
    website_discovered = bool(lead.get("website_discovered", False))
    reviews = _safe_int(lead.get("reviews"))
    rating  = _safe_float(lead.get("rating"))

    if no_web:
        points.append("No website — completely invisible to online searchers")
    elif website_discovered:
        points.append("Website not promoted — not appearing in local Google searches")
    if reviews < 10:
        points.append("Very few reviews — low social proof for new customers")
    if 0 < rating < 4.0:
        points.append(f"Low rating ({rating}★) — damaging first impressions")
    if audit_score <= 4:
        points.append("Website does not meet basic professional standards")
    if not points:
        points.append("Website could be significantly improved for conversions")

    return points[:3]


def _priority_label(score: int) -> str:
    """
    FIX: Returns labels matching database.py and dashboard.py expectations.
    was: "hot"/"warm"/"cold"/"unqualified"
    now: "high"/"medium"/"low"/"unscored"
    """
    if score >= 8:
        return "high"
    if score >= 6:
        return "medium"
    if score >= 4:
        return "low"
    return "unscored"


# ══════════════════════════════════════════════
# MAIN SCORING FUNCTION
# ══════════════════════════════════════════════

def score_lead(lead: dict) -> dict:
    """
    Full scoring pipeline:
      1. Country enrichment
      2. Deep enrichment (website + DM discovery)
      3. Audit score
      4. Search intent
      5. Build prompt
      6. AI call (cache + circuit breaker)
      7. Parse + validate
      8. Priority label
      9. Channel routing

    FIX: routing updates only applied for routing-specific fields,
    not geography (to prevent router overwriting country_router data).
    FIX: never overwrites existing phone/email/website with empty.
    """
    lead = dict(lead or {})

    # Step 1 — Country enrichment (safe)
    try:
        lead = enrich_lead_with_country(lead)
    except Exception as exc:
        logger.warning("[scorer] Country enrichment failed: %s", exc)

    # Step 2 — Deep enrichment
    try:
        lead = deep_enrich_lead(lead)
    except Exception as exc:
        logger.warning("[scorer] Deep enrichment failed: %s", exc)

    # Step 3 — Audit score
    audit_score = compute_website_audit_score(lead)
    lead["website_audit_score"] = audit_score

    # Step 4 — Build prompt
    prompt      = _build_prompt(lead, audit_score)
    prompt_hash = _prompt_hash(prompt)

    # Step 5 — Check cache / circuit breaker
    result: dict    = {}
    ai_text: str    = ""
    scoring_status  = "fallback"
    last_ai_error   = ""

    cached_hash   = str(lead.get("ai_prompt_hash") or "").strip()
    cached_output = str(lead.get("ai_output_cached") or "").strip()

    if cached_hash == prompt_hash and cached_output:
        ai_text = cached_output
        result  = _parse_ai_response(ai_text)
        scoring_status = "cached"
    elif is_circuit_open():
        logger.warning(
            "[scorer] Circuit breaker open — skipping AI for %s",
            lead.get("business_name", "unknown"),
        )
        last_ai_error  = "circuit_open"
        scoring_status = "circuit_open"
    else:
        try:
            ai_text = call_ai(
                prompt=prompt,
                max_tokens=600,
                use_cache=True,
                fallback="",
            )
            result         = _parse_ai_response(ai_text)
            scoring_status = "ai" if result else "fallback"
        except Exception as exc:
            logger.warning("[scorer] AI call raised exception: %s", exc)
            last_ai_error  = str(exc)
            scoring_status = "fallback"

    # Step 6 — Extract + validate
    fit_score = _safe_int(result.get("fit_score", 0))
    if not 1 <= fit_score <= 10:
        fit_score = max(1, min(10, audit_score + 1))

    fit_reason = str(result.get("fit_reason") or "").strip()
    if not fit_reason:
        fit_reason = _audit_explanation(audit_score, lead)

    pain_points = result.get("pain_points", [])
    if not isinstance(pain_points, list):
        pain_points = []
    pain_points = [str(p).strip() for p in pain_points if str(p).strip()]
    if not pain_points:
        pain_points = _default_pain_points(lead, audit_score)

    opener = str(result.get("recommended_opener") or "").strip()
    opener = _sanitise_opener(opener, lead)

    # Step 7 — Priority label (FIX: "high"/"medium"/"low"/"unscored")
    priority = _priority_label(fit_score)

    # Step 8 — Channel routing
    # FIX: Only apply routing-channel-specific fields from routing result.
    # Never let router overwrite country/market/timezone from country_router.
    _routing_only_fields = {
        "best_channel", "channel_label", "routing_channel", "routing_reason",
        "call_ready", "email_ready", "whatsapp_ready", "ai_call_ready",
        "manual_review", "wa_eligible", "wa_status",
        "whatsapp_check_attempted", "whatsapp_check_at",
        "verification_status", "phone_verified",
    }
    routing_updates: dict = {}
    if _ROUTER_AVAILABLE:
        try:
            routing_input = dict(lead)
            routing_input.update({
                "fit_score": fit_score,
                "lead_priority": priority,
                "website_audit_score": audit_score,
                "recommended_opener": opener,
                "fit_reason": fit_reason,
                "pain_points": pain_points,
            })
            raw_routing = assign_channel(routing_input) or {}
            # Only keep routing-specific fields
            routing_updates = {
                k: v for k, v in raw_routing.items()
                if k in _routing_only_fields
            }
        except Exception as exc:
            logger.warning("[scorer] Routing failed: %s", exc)

    # Step 9 — Fail counter
    ai_fail_count = _safe_int(lead.get("ai_fail_count", 0))
    if scoring_status in {"fallback", "circuit_open"}:
        ai_fail_count += 1
    else:
        ai_fail_count = 0

    ai_output_cached = ai_text or json.dumps(result or {}, ensure_ascii=False)

    # ── Helper: preserve existing value if new one is empty ──
    def _keep(key: str, new_val, lead_val) -> Any:
        if key in _NO_OVERWRITE_WITH_EMPTY:
            if not new_val and lead_val:
                return lead_val
        return new_val if new_val is not None else lead_val

    search_phrase = (
        get_search_phrase(lead.get("industry", ""), lead.get("city", ""))
        if _INTENT_AVAILABLE else ""
    )

    return {
        # Core scoring
        "fit_score":           fit_score,
        "fit_reason":          fit_reason,
        "pain_points":         pain_points,
        "recommended_opener":  opener,
        "website_audit_score": audit_score,
        "lead_priority":       priority,
        "search_phrase":       search_phrase,

        # Website discovery
        "website":                      _keep("website", lead.get("website", ""), lead.get("website", "")),
        "website_discovered":           lead.get("website_discovered", False),
        "website_discovery_confidence": lead.get("website_discovery_confidence", "none"),
        "website_discovery_source":     lead.get("website_discovery_source", "none"),

        # Deep enrichment — FIX: preserve existing phone/email
        "decision_maker_name":   lead.get("decision_maker_name", ""),
        "decision_maker_title":  lead.get("decision_maker_title", ""),
        "decision_maker_source": lead.get("decision_maker_source", ""),
        "phone":                 _keep("phone", lead.get("phone", ""), lead.get("phone", "")),
        "phone_source":          lead.get("phone_source", ""),
        "email":                 _keep("email", lead.get("email", ""), lead.get("email", "")),
        "email_source":          lead.get("email_source", ""),
        "deep_enriched":         lead.get("deep_enriched", False),
        "deep_enriched_at":      lead.get("deep_enriched_at", ""),

        # Geography — from country_router, not from routing
        "country":           lead.get("country", ""),
        "market":            lead.get("market", ""),
        "timezone":          lead.get("timezone", ""),
        "phone_country_code": lead.get("phone_country_code", ""),
        "country_confidence": lead.get("country_confidence", "low"),

        # WA / routing — from routing_updates, fallback to lead
        "wa_status":              routing_updates.get("wa_status", lead.get("wa_status", "unknown")),
        "wa_eligible":            routing_updates.get("wa_eligible", lead.get("wa_eligible", 0)),
        "wa_verified":            lead.get("wa_verified", 0),
        "wa_opt_in":              lead.get("wa_opt_in", 0),
        "verification_status":    routing_updates.get("verification_status", lead.get("verification_status", "unverified")),
        "phone_verified":         routing_updates.get("phone_verified", lead.get("phone_verified", 0)),
        "routing_channel":        routing_updates.get("routing_channel", lead.get("routing_channel", "")),
        "best_channel":           routing_updates.get("best_channel", lead.get("best_channel", "unknown")),
        "channel_label":          routing_updates.get("channel_label", lead.get("channel_label", "unrouted")),
        "routing_reason":         routing_updates.get("routing_reason", lead.get("routing_reason", "")),
        "call_ready":             routing_updates.get("call_ready", lead.get("call_ready", 0)),
        "email_ready":            routing_updates.get("email_ready", lead.get("email_ready", 0)),
        "whatsapp_ready":         routing_updates.get("whatsapp_ready", lead.get("whatsapp_ready", 0)),
        "ai_call_ready":          routing_updates.get("ai_call_ready", lead.get("ai_call_ready", 0)),
        "manual_review":          routing_updates.get("manual_review", lead.get("manual_review", 0)),
        "whatsapp_check_attempted": routing_updates.get("whatsapp_check_attempted", lead.get("whatsapp_check_attempted", 0)),
        "whatsapp_check_at":      routing_updates.get("whatsapp_check_at", lead.get("whatsapp_check_at", "")),

        # AI metadata
        "ai_scored_at":        datetime.utcnow().isoformat(),
        "ai_prompt_hash":      prompt_hash,
        "ai_output_cached":    ai_output_cached,
        "ai_fail_count":       ai_fail_count,
        "last_ai_error":       last_ai_error,
        "scoring_status":      scoring_status,
        "scored_at":           datetime.utcnow().isoformat(),
        "fit_scored_at":       datetime.utcnow().isoformat(),
        "last_contact_channel": lead.get("last_contact_channel", ""),
    }


# ══════════════════════════════════════════════
# DATABASE SAVE
# ══════════════════════════════════════════════

def score_and_save_lead(lead_id: int) -> dict | None:
    """
    FIX: Uses get_connection() from database.py (WAL + thread-safe).
    FIX: Never overwrites existing phone/email with empty string.
    FIX: Runs _ensure_columns once per connection.
    """
    conn = _get_db_connection()
    cur  = conn.cursor()

    try:
        _ensure_columns(cur, conn)
    except Exception as exc:
        logger.warning("[scorer] _ensure_columns failed: %s", exc)

    try:
        cur.execute("SELECT * FROM leads WHERE id = ?", (lead_id,))
        row = cur.fetchone()
        if not row:
            logger.warning("Lead %s not found in DB", lead_id)
            return None

        lead = dict(row)
    except Exception as exc:
        logger.error("Lead fetch failed for id %s: %s", lead_id, exc)
        conn.close()
        return None

    try:
        result = score_lead(lead)
    except Exception as exc:
        logger.error("Scoring failed for lead %s: %s", lead_id, exc)
        conn.close()
        return None

    # FIX: preserve existing phone/email if scoring returned empty
    def _safe_write(key: str) -> str:
        new_val  = str(result.get(key) or "").strip()
        old_val  = str(lead.get(key) or "").strip()
        if key in _NO_OVERWRITE_WITH_EMPTY and not new_val and old_val:
            return old_val
        return new_val

    now_iso = datetime.utcnow().isoformat()

    try:
        cur.execute(
            """
            UPDATE leads SET
                fit_score                    = ?,
                fit_reason                   = ?,
                pain_points                  = ?,
                recommended_opener           = ?,
                website_audit_score          = ?,
                lead_priority                = ?,
                search_phrase                = ?,
                fit_scored_at                = ?,
                scored_at                    = ?,

                website                      = ?,
                website_discovered           = ?,
                website_discovery_confidence = ?,
                website_discovery_source     = ?,

                decision_maker_name          = ?,
                decision_maker_title         = ?,
                decision_maker_source        = ?,
                phone                        = ?,
                phone_source                 = ?,
                email                        = ?,
                email_source                 = ?,
                deep_enriched                = ?,
                deep_enriched_at             = ?,

                ai_scored_at                 = ?,
                ai_prompt_hash               = ?,
                ai_output_cached             = ?,
                ai_fail_count                = ?,
                last_ai_error                = ?,
                scoring_status               = ?,

                country                      = ?,
                market                       = ?,
                timezone                     = ?,
                phone_country_code           = ?,
                country_confidence           = ?,

                wa_status                    = ?,
                wa_eligible                  = ?,
                wa_verified                  = ?,
                wa_opt_in                    = ?,
                verification_status          = ?,
                phone_verified               = ?,

                routing_channel              = ?,
                best_channel                 = ?,
                channel_label                = ?,
                routing_reason               = ?,

                call_ready                   = ?,
                email_ready                  = ?,
                whatsapp_ready               = ?,
                ai_call_ready                = ?,
                manual_review                = ?,

                whatsapp_check_attempted     = ?,
                whatsapp_check_at            = ?,
                last_contact_channel         = ?,
                updated_at                   = ?
            WHERE id = ?
            """,
            (
                result["fit_score"],
                result["fit_reason"],
                json.dumps(result["pain_points"]),
                result["recommended_opener"],
                result["website_audit_score"],
                result["lead_priority"],
                result.get("search_phrase", ""),
                result.get("fit_scored_at", now_iso),
                result.get("scored_at", now_iso),

                _safe_write("website"),
                int(bool(result.get("website_discovered", False))),
                result.get("website_discovery_confidence", "none"),
                result.get("website_discovery_source", "none"),

                result.get("decision_maker_name", ""),
                result.get("decision_maker_title", ""),
                result.get("decision_maker_source", ""),
                _safe_write("phone"),
                result.get("phone_source", ""),
                _safe_write("email"),
                result.get("email_source", ""),
                int(bool(result.get("deep_enriched", False))),
                result.get("deep_enriched_at", ""),

                result.get("ai_scored_at", now_iso),
                result.get("ai_prompt_hash", ""),
                result.get("ai_output_cached", ""),
                result.get("ai_fail_count", 0),
                result.get("last_ai_error", ""),
                result.get("scoring_status", "fallback"),

                result.get("country", ""),
                result.get("market", ""),
                result.get("timezone", ""),
                result.get("phone_country_code", ""),
                result.get("country_confidence", "low"),

                result.get("wa_status", "unknown"),
                result.get("wa_eligible", 0),
                result.get("wa_verified", 0),
                result.get("wa_opt_in", 0),
                result.get("verification_status", "unverified"),
                result.get("phone_verified", 0),

                result.get("routing_channel", ""),
                result.get("best_channel", ""),
                result.get("channel_label", ""),
                result.get("routing_reason", ""),

                result.get("call_ready", 0),
                result.get("email_ready", 0),
                result.get("whatsapp_ready", 0),
                result.get("ai_call_ready", 0),
                result.get("manual_review", 0),

                result.get("whatsapp_check_attempted", 0),
                result.get("whatsapp_check_at", ""),
                result.get("last_contact_channel", ""),
                now_iso,

                lead_id,
            ),
        )
        conn.commit()

    except Exception as exc:
        logger.error("DB save failed for lead %s: %s", lead_id, exc)
    finally:
        conn.close()

    logger.info(
        "Lead %s scored — fit=%s audit=%s/10 priority=%s "
        "website_discovered=%s dm=%s channel=%s",
        lead_id,
        result["fit_score"],
        result["website_audit_score"],
        result["lead_priority"],
        result.get("website_discovered", False),
        result.get("decision_maker_name") or "—",
        result.get("best_channel") or "—",
    )
    return result


def _ensure_columns(cur: sqlite3.Cursor, con: sqlite3.Connection) -> None:
    """
    FIX: Single commit at end, not per column.
    FIX: Only catches OperationalError (column exists) — other errors propagate.
    """
    new_columns = [
        ("website_audit_score",          "INTEGER DEFAULT 0"),
        ("search_phrase",                "TEXT DEFAULT ''"),
        ("country",                      "TEXT DEFAULT ''"),
        ("market",                       "TEXT DEFAULT ''"),
        ("timezone",                     "TEXT DEFAULT ''"),
        ("phone_country_code",           "TEXT DEFAULT ''"),
        ("country_confidence",           "TEXT DEFAULT 'low'"),
        ("wa_status",                    "TEXT DEFAULT 'unknown'"),
        ("wa_eligible",                  "INTEGER DEFAULT 0"),
        ("wa_verified",                  "INTEGER DEFAULT 0"),
        ("wa_opt_in",                    "INTEGER DEFAULT 0"),
        ("verification_status",          "TEXT DEFAULT 'unverified'"),
        ("phone_verified",               "INTEGER DEFAULT 0"),
        ("routing_channel",              "TEXT DEFAULT ''"),
        ("scoring_status",               "TEXT DEFAULT 'pending'"),
        ("ai_scored_at",                 "TEXT"),
        ("ai_prompt_hash",               "TEXT"),
        ("ai_output_cached",             "TEXT"),
        ("ai_fail_count",                "INTEGER DEFAULT 0"),
        ("last_ai_error",                "TEXT"),
        ("last_contact_channel",         "TEXT"),
        ("scored_at",                    "TEXT"),
        ("fit_scored_at",                "TEXT"),
        ("website_discovered",           "INTEGER DEFAULT 0"),
        ("website_discovery_confidence", "TEXT DEFAULT 'none'"),
        ("website_discovery_source",     "TEXT DEFAULT 'none'"),
        ("decision_maker_name",          "TEXT DEFAULT ''"),
        ("decision_maker_title",         "TEXT DEFAULT ''"),
        ("decision_maker_source",        "TEXT DEFAULT ''"),
        ("phone_source",                 "TEXT DEFAULT ''"),
        ("email_source",                 "TEXT DEFAULT ''"),
        ("deep_enriched",                "INTEGER DEFAULT 0"),
        ("deep_enriched_at",             "TEXT DEFAULT ''"),
    ]

    for col_name, col_def in new_columns:
        try:
            cur.execute(
                f"ALTER TABLE leads ADD COLUMN {col_name} {col_def}"
            )
        except sqlite3.OperationalError:
            pass  # Column already exists — expected

    try:
        con.commit()
    except Exception as exc:
        logger.warning("[scorer] _ensure_columns commit failed: %s", exc)


# ══════════════════════════════════════════════
# BATCH SCORING
# ══════════════════════════════════════════════

def _get_unscored_ids(limit: int | None = None) -> list:
    """
    FIX: Uses IS NULL on fit_score, not = 0.
    Uses get_connection() from database.py.
    """
    conn = _get_db_connection()
    try:
        cur = conn.cursor()
        query = """
            SELECT id FROM leads
            WHERE fit_score IS NULL
               OR lead_priority IS NULL
               OR lead_priority IN ('', 'unscored')
            ORDER BY id ASC
        """
        if limit:
            cur.execute(query + " LIMIT ?", (limit,))
        else:
            cur.execute(query)
        return [row["id"] for row in cur.fetchall()]
    finally:
        conn.close()


def score_all_unscored(delay: float = _MIN_BATCH_DELAY) -> int:
    ids = _get_unscored_ids()
    logger.info("[scorer] Batch scoring %s leads", len(ids))
    scored = 0

    for lead_id in ids:
        if is_circuit_open():
            logger.warning(
                "[scorer] Circuit open — stopping batch at %d/%d", scored, len(ids)
            )
            break
        result = score_and_save_lead(lead_id)
        if result:
            scored += 1
        time.sleep(delay)

    logger.info("[scorer] Batch complete — %s/%s scored", scored, len(ids))
    return scored


def score_unscored_leads_batch(limit: int = 50, use_ai: bool = True) -> dict:
    """
    FIX: medium bucket now correctly counts 5 ≤ fit < 8 (not fit >= 5).
    """
    ids = _get_unscored_ids(limit=limit)
    total  = len(ids)
    scored = high = medium = low = 0
    circuit_stopped = False

    for lead_id in ids:
        if is_circuit_open():
            logger.warning(
                "[scorer] Circuit open — stopping early. %d of %d scored.",
                scored, total,
            )
            circuit_stopped = True
            break

        result = score_and_save_lead(lead_id)
        if result:
            scored += 1
            fit = _safe_int(result.get("fit_score", 0))
            if fit >= 8:
                high += 1
            elif 5 <= fit < 8:   # FIX: was just >= 5, now exclusive of 8
                medium += 1
            else:
                low += 1
        time.sleep(_SHORT_BATCH_DELAY)

    return {
        "total":           total,
        "scored":          scored,
        "high":            high,
        "medium":          medium,
        "low":             low,
        "circuit_stopped": circuit_stopped,
        "used_ai":         bool(use_ai),
    }


# ══════════════════════════════════════════════
# LEGACY HELPERS
# ══════════════════════════════════════════════

def get_fit_label(fit_score: int) -> dict:
    if fit_score >= 8:
        return {"label": "⭐ HIGH FIT", "color": "#2ed573", "bg": "#eafff1"}
    if fit_score >= 5:
        return {"label": "✅ MEDIUM FIT", "color": "#FFA502", "bg": "#FFF3E0"}
    if fit_score >= 1:
        return {"label": "⚪ LOW FIT", "color": "#747D8C", "bg": "#F1F2F6"}
    return {"label": "❓ UNSCORED", "color": "#a4b0be", "bg": "#f1f2f6"}


def get_channel_label(channel: str) -> dict:
    return {
        "whatsapp": {"label": "💬 WhatsApp", "color": "#25D366", "bg": "#e8fff2"},
        "ai_call":  {"label": "🤖 AI Call",  "color": "#5352ED", "bg": "#eeeeff"},
        "email":    {"label": "📧 Email",     "color": "#1E90FF", "bg": "#e8f4ff"},
        "manual":   {"label": "👤 Manual",    "color": "#747D8C", "bg": "#F1F2F6"},
        "unknown":  {"label": "❓ Unknown",   "color": "#a4b0be", "bg": "#f1f2f6"},
    }.get(channel or "unknown", {"label": "❓ Unknown", "color": "#a4b0be", "bg": "#f1f2f6"})


def get_contact_completeness(lead: dict) -> dict:
    fields = {
        "Phone":   bool(lead.get("phone")),
        "Email":   bool(lead.get("email")),
        "Website": bool(lead.get("website")),
        "Address": bool(lead.get("address")),
    }
    filled = sum(1 for v in fields.values() if v)
    return {
        "percentage": (filled / len(fields) * 100),
        "fields":     fields,
        "filled":     filled,
        "total":      len(fields),
    }
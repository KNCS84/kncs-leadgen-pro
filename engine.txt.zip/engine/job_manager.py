# engine/job_manager.py
# v8.1 — Updated with full lead intelligence scoring
# Adds fit scoring, channel recommendation, lead priority
# after each lead is saved. Safe fallback if scorer fails.

"""
Background job manager for KNCS LeadGen Pro.

Runs scraping jobs in background threads.
Jobs survive page navigation in Streamlit.
Progress tracked in database.
Leads saved as they are found.
"""

import threading
import traceback
import asyncio
from datetime import datetime
from typing import Optional

import nest_asyncio
nest_asyncio.apply()

# ─────────────────────────────────────────────────────────
# In-memory job registry
# ─────────────────────────────────────────────────────────

_active_jobs = {}
_jobs_lock = threading.Lock()

# ─────────────────────────────────────────────────────────
# Job status constants
# ─────────────────────────────────────────────────────────

STATUS_PENDING  = "pending"
STATUS_RUNNING  = "running"
STATUS_DONE     = "done"
STATUS_FAILED   = "failed"
STATUS_STOPPED  = "stopped"

# ─────────────────────────────────────────────────────────
# Safe async runner
# ─────────────────────────────────────────────────────────

def run_async(coro):
    """
    Safely run an async coroutine from a background thread.

    Uses ProactorEventLoop on Windows because Playwright
    launches Chromium as a subprocess and SelectorEventLoop
    cannot handle subprocesses on Windows.

    This is the root cause fix for NotImplementedError.
    """
    import sys

    if sys.platform == "win32":
        loop = asyncio.ProactorEventLoop()
    else:
        loop = asyncio.new_event_loop()

    try:
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(coro)
    except Exception as e:
        print(f"❌ run_async error: {e}")
        traceback.print_exc()
        return []
    finally:
        try:
            loop.close()
        except Exception:
            pass

# ─────────────────────────────────────────────────────────
# Database helpers
# ─────────────────────────────────────────────────────────

def _ensure_jobs_table(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scrape_jobs (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            keyword         TEXT,
            location        TEXT,
            source          TEXT,
            status          TEXT DEFAULT 'pending',
            progress        INTEGER DEFAULT 0,
            leads_found     INTEGER DEFAULT 0,
            total_target    INTEGER DEFAULT 0,
            current_lead    TEXT DEFAULT '',
            started_at      TEXT,
            completed_at    TEXT,
            error_message   TEXT,
            created_at      TEXT DEFAULT (datetime('now'))
        )
    """)
    conn.commit()


def create_job(
    keyword: str,
    location: str,
    source: str,
    total_target: int,
) -> int:
    """
    Create a new scrape job record in DB.
    Returns the job ID.
    """
    from database import get_connection

    conn = get_connection()

    try:
        _ensure_jobs_table(conn)

        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO scrape_jobs
            (
                keyword,
                location,
                source,
                status,
                progress,
                leads_found,
                total_target,
                started_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                keyword,
                location,
                source,
                STATUS_PENDING,
                0,
                0,
                total_target,
                datetime.utcnow().isoformat(),
            ),
        )

        conn.commit()
        job_id = cursor.lastrowid

        print(f"✅ Job created: ID={job_id}")
        return job_id

    finally:
        conn.close()


def update_job_progress(
    job_id: int,
    progress: int,
    leads_found: int,
    current_lead: str = "",
    status: str = STATUS_RUNNING,
):
    """
    Update job progress in DB.
    """
    from database import get_connection

    conn = get_connection()

    try:
        _ensure_jobs_table(conn)

        conn.execute(
            """
            UPDATE scrape_jobs
            SET
                status       = ?,
                progress     = ?,
                leads_found  = ?,
                current_lead = ?
            WHERE id = ?
            """,
            (
                status,
                min(progress, 100),
                leads_found,
                current_lead[:100] if current_lead else "",
                job_id,
            ),
        )

        conn.commit()

    except Exception as e:
        print(f"⚠️ Job progress update error: {e}")

    finally:
        conn.close()


def complete_job(
    job_id: int,
    leads_found: int,
    error: str = None,
    status: str = None,
):
    """
    Mark job as done / failed / stopped.
    """
    from database import get_connection

    conn = get_connection()

    try:
        _ensure_jobs_table(conn)

        if status:
            final_status = status
        else:
            final_status = STATUS_FAILED if error else STATUS_DONE

        conn.execute(
            """
            UPDATE scrape_jobs
            SET
                status        = ?,
                progress      = 100,
                leads_found   = ?,
                completed_at  = ?,
                error_message = ?
            WHERE id = ?
            """,
            (
                final_status,
                leads_found,
                datetime.utcnow().isoformat(),
                error,
                job_id,
            ),
        )

        conn.commit()

        print(
            f"✅ Job {job_id} complete: "
            f"{leads_found} leads | status={final_status}"
        )

    except Exception as e:
        print(f"⚠️ Job complete update error: {e}")

    finally:
        conn.close()

        with _jobs_lock:
            _active_jobs.pop(job_id, None)


def get_job(job_id: int) -> dict:
    """
    Get job record from DB.
    """
    from database import get_connection

    conn = get_connection()

    try:
        _ensure_jobs_table(conn)

        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM scrape_jobs WHERE id = ?",
            (job_id,),
        )

        row = cursor.fetchone()
        return dict(row) if row else {}

    finally:
        conn.close()


def get_recent_jobs(limit: int = 10) -> list:
    """
    Get most recent scrape jobs.
    """
    from database import get_connection

    conn = get_connection()

    try:
        _ensure_jobs_table(conn)

        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT *
            FROM scrape_jobs
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (limit,),
        )

        return [dict(r) for r in cursor.fetchall()]

    finally:
        conn.close()


def get_running_job() -> dict:
    """
    Get currently running job if any.
    """
    from database import get_connection

    conn = get_connection()

    try:
        _ensure_jobs_table(conn)

        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT *
            FROM scrape_jobs
            WHERE status = 'running'
            ORDER BY created_at DESC
            LIMIT 1
            """
        )

        row = cursor.fetchone()
        return dict(row) if row else {}

    finally:
        conn.close()


def stop_job(job_id: int):
    """
    Signal a job to stop.
    """
    from database import get_connection

    conn = get_connection()

    try:
        conn.execute(
            """
            UPDATE scrape_jobs
            SET status = ?
            WHERE id = ?
            """,
            (STATUS_STOPPED, job_id),
        )
        conn.commit()

        print(f"🛑 Job {job_id} stop requested")

    finally:
        conn.close()


def is_job_stopped(job_id: int) -> bool:
    """
    Check if job has been requested to stop.
    """
    job = get_job(job_id)
    return job.get("status") in [STATUS_STOPPED, STATUS_FAILED]


# ─────────────────────────────────────────────────────────
# Lead intelligence scorer (v8.1)
# Runs AFTER a lead is saved to DB.
# Safe — never breaks the job if it fails.
# ─────────────────────────────────────────────────────────

def _run_full_scoring(lead: dict, lead_id: int) -> None:
    """
    Run the full lead intelligence scoring pipeline on a
    saved lead and write results back to the database.

    Calls score_lead_full() from engine/scorer.py which
    produces:
        - fit_score
        - fit_reason
        - pain_points
        - recommended_opener
        - best_channel
        - lead_priority
        - urgency_score
        - reachability_score
        - whatsapp_ready
        - ai_call_ready
        - email_ready

    Wrapped in try/except — if scorer.py does not have
    score_lead_full yet, this is a silent no-op.
    """
    try:
        from engine.scorer import score_lead_full
    except ImportError:
        # scorer.py does not have score_lead_full yet — safe skip
        return

    try:
        result = score_lead_full(lead)

        if not result or not isinstance(result, dict):
            return

        from database import update_lead_fit_score

        update_lead_fit_score(
            lead_id=lead_id,
            fit_score=result.get("fit_score", 0),
            fit_reason=result.get("fit_reason", ""),
            pain_points=result.get("pain_points", []),
            recommended_opener=result.get("recommended_opener", ""),
            best_channel=result.get("best_channel", "manual"),
            lead_priority=result.get("lead_priority", "unscored"),
            urgency_score=result.get("urgency_score", 0),
            reachability_score=result.get("reachability_score", 0),
            whatsapp_ready=int(result.get("whatsapp_ready", False)),
            ai_call_ready=int(result.get("ai_call_ready", False)),
            email_ready=int(result.get("email_ready", False)),
        )

        print(
            f"  🧠 Scored lead {lead_id}: "
            f"fit={result.get('fit_score', 0)} "
            f"priority={result.get('lead_priority', '?')} "
            f"channel={result.get('best_channel', '?')}"
        )

    except Exception as e:
        # Never let scoring crash the job
        print(f"  ⚠️ Full scoring skipped for lead {lead_id}: {e}")


# ─────────────────────────────────────────────────────────
# Background thread runner
# ─────────────────────────────────────────────────────────

def _run_scrape_job(
    job_id: int,
    keyword: str,
    location: str,
    source: str,
    max_results: int,
    max_pages: int,
    do_enrich: bool,
    do_email: bool,
    do_scripts: bool,
    force_restart: bool,
    city: str,
    country: str,
):
    """
    Actual scraping function that runs in a background thread.

    Pipeline per lead (v8.1):
        1. Scrape
        2. Deduplicate
        3. Enrich
        4. Basic score  (score_lead — unchanged)
        5. Save to DB
        6. Full intelligence score (score_lead_full — new)
        7. Write intelligence fields back to DB
    """

    from database import insert_lead, log_search
    from engine.enricher import enrich_lead
    from engine.scorer import score_lead
    from engine.deduplicator import deduplicate_batch

    try:
        from engine.script_generator import generate_script
        has_scripts = True
    except Exception:
        has_scripts = False

    leads_found = 0
    all_leads   = []

    try:
        update_job_progress(
            job_id,
            0,
            0,
            "Starting...",
            STATUS_RUNNING,
        )

        # ─────────────────────────────────────────────
        # GOOGLE MAPS
        # ─────────────────────────────────────────────
        if source == "google_maps":
            update_job_progress(
                job_id, 5, leads_found, "Starting Google Maps...",
            )

            if is_job_stopped(job_id):
                complete_job(job_id, leads_found, status=STATUS_STOPPED)
                return

            try:
                from engine.scraper import scrape_google_maps

                print("🔍 Launching Google Maps scraper...")

                gm_leads = run_async(
                    scrape_google_maps(
                        keyword=keyword,
                        location=location,
                        max_results=max_results,
                    )
                )

                gm_leads = gm_leads or []
                all_leads.extend(gm_leads)

                log_search(keyword, location, "google_maps", len(gm_leads))

                update_job_progress(
                    job_id, 20, leads_found,
                    f"Google Maps: {len(gm_leads)} found",
                )

                print(f"✅ Google Maps: {len(gm_leads)} leads")

            except Exception as e:
                print(f"⚠️ Google Maps error: {e}")
                traceback.print_exc()

        # ─────────────────────────────────────────────
        # B2BHINT
        # ─────────────────────────────────────────────
        elif source == "b2bhint":
            update_job_progress(
                job_id, 25, leads_found, "Starting B2BHint...",
            )

            if is_job_stopped(job_id):
                complete_job(job_id, leads_found, status=STATUS_STOPPED)
                return

            try:
                from engine.b2bhint_scraper import scrape_b2bhint

                b2b_leads = scrape_b2bhint(
                    keyword=keyword,
                    location=location,
                    max_results=max_results,
                    max_pages=max_pages,
                    force_restart=force_restart,
                )

                b2b_leads = b2b_leads or []
                all_leads.extend(b2b_leads)

                log_search(keyword, location, "b2bhint", len(b2b_leads))

                update_job_progress(
                    job_id, 40, leads_found,
                    f"B2BHint: {len(b2b_leads)} found",
                )

                print(f"✅ B2BHint complete: {len(b2b_leads)} leads")

            except Exception as e:
                print(f"⚠️ B2BHint error: {e}")
                traceback.print_exc()

        # ─────────────────────────────────────────────
        # YELP
        # ─────────────────────────────────────────────
        elif source == "yelp":
            update_job_progress(
                job_id, 30, leads_found, "Starting Yelp...",
            )

            if is_job_stopped(job_id):
                complete_job(job_id, leads_found, status=STATUS_STOPPED)
                return

            try:
                from engine.yelp_scraper import scrape_yelp

                yelp_leads = scrape_yelp(
                    keyword=keyword,
                    location=location,
                    max_results=max_results,
                )

                yelp_leads = yelp_leads or []
                all_leads.extend(yelp_leads)

                log_search(keyword, location, "yelp", len(yelp_leads))

                update_job_progress(
                    job_id, 50, leads_found,
                    f"Yelp: {len(yelp_leads)} found",
                )

                print(f"✅ Yelp complete: {len(yelp_leads)} leads")

            except Exception as e:
                print(f"⚠️ Yelp error: {e}")
                traceback.print_exc()

        # ─────────────────────────────────────────────
        # COMPANIES HOUSE UK
        # ─────────────────────────────────────────────
        elif source == "companies_house":
            update_job_progress(
                job_id, 20, leads_found,
                "Connecting to Companies House UK...",
            )

            if is_job_stopped(job_id):
                complete_job(job_id, leads_found, status=STATUS_STOPPED)
                return

            try:
                from engine.companies_house_scraper import scrape_companies_house

                print("🇬🇧 Launching Companies House scraper...")

                ch_leads = scrape_companies_house(
                    keyword=keyword,
                    location=location,
                    max_results=max_results,
                    get_details=True,
                    get_officers=True,
                    active_only=True,
                )

                ch_leads = ch_leads or []
                all_leads.extend(ch_leads)

                log_search(
                    keyword, location, "companies_house", len(ch_leads),
                )

                update_job_progress(
                    job_id, 60, leads_found,
                    f"Companies House: {len(ch_leads)} companies found",
                )

                print(f"✅ Companies House: {len(ch_leads)} leads")

            except Exception as e:
                print(f"⚠️ Companies House error: {e}")
                traceback.print_exc()

        # ─────────────────────────────────────────────
        # YELLOWPAGES
        # ─────────────────────────────────────────────
        elif source == "yellowpages":
            update_job_progress(
                job_id, 35, leads_found, "Starting YellowPages...",
            )

            if is_job_stopped(job_id):
                complete_job(job_id, leads_found, status=STATUS_STOPPED)
                return

            try:
                from engine.yellowpages_scraper import scrape_yellowpages

                yp_leads = scrape_yellowpages(
                    keyword=keyword,
                    location=location,
                    max_results=max_results,
                )

                yp_leads = yp_leads or []
                all_leads.extend(yp_leads)

                log_search(keyword, location, "yellowpages", len(yp_leads))

                update_job_progress(
                    job_id, 55, leads_found,
                    f"YellowPages: {len(yp_leads)} found",
                )

                print(f"✅ YellowPages complete: {len(yp_leads)} leads")

            except Exception as e:
                print(f"⚠️ YellowPages error: {e}")
                traceback.print_exc()

        # ─────────────────────────────────────────────
        # BOTH — Google Maps + B2BHint
        # ─────────────────────────────────────────────
        elif source == "both":

            # Google Maps half
            try:
                from engine.scraper import scrape_google_maps

                update_job_progress(
                    job_id, 10, leads_found,
                    "Google Maps (both mode)...",
                )

                gm_leads = run_async(
                    scrape_google_maps(
                        keyword=keyword,
                        location=location,
                        max_results=max(1, max_results // 2),
                    )
                )

                gm_leads = gm_leads or []
                all_leads.extend(gm_leads)

                log_search(keyword, location, "google_maps", len(gm_leads))

                print(f"✅ BOTH/Google Maps: {len(gm_leads)} leads")

            except Exception as e:
                print(f"⚠️ BOTH/Google Maps error: {e}")
                traceback.print_exc()

            # B2BHint half
            try:
                from engine.b2bhint_scraper import scrape_b2bhint

                update_job_progress(
                    job_id, 40, leads_found,
                    "B2BHint (both mode)...",
                )

                b2b_leads = scrape_b2bhint(
                    keyword=keyword,
                    location=location,
                    max_results=max(1, max_results // 2),
                    max_pages=max_pages,
                )

                b2b_leads = b2b_leads or []
                all_leads.extend(b2b_leads)

                log_search(keyword, location, "b2bhint", len(b2b_leads))

                print(f"✅ BOTH/B2BHint: {len(b2b_leads)} leads")

            except Exception as e:
                print(f"⚠️ BOTH/B2BHint error: {e}")
                traceback.print_exc()

        # ─────────────────────────────────────────────
        # ALL — All sources
        # ─────────────────────────────────────────────
        elif source == "all":
            per_source = max(1, max_results // 4)

            sources_config = [
                ("google_maps",  10),
                ("b2bhint",      30),
                ("yelp",         50),
                ("yellowpages",  70),
            ]

            for src, prog_start in sources_config:
                if is_job_stopped(job_id):
                    complete_job(job_id, leads_found, status=STATUS_STOPPED)
                    return

                update_job_progress(
                    job_id, prog_start, leads_found, f"Running {src}...",
                )

                try:
                    if src == "google_maps":
                        from engine.scraper import scrape_google_maps
                        leads = run_async(
                            scrape_google_maps(
                                keyword=keyword,
                                location=location,
                                max_results=per_source,
                            )
                        )

                    elif src == "b2bhint":
                        from engine.b2bhint_scraper import scrape_b2bhint
                        leads = scrape_b2bhint(
                            keyword=keyword,
                            location=location,
                            max_results=per_source,
                        )

                    elif src == "yelp":
                        from engine.yelp_scraper import scrape_yelp
                        leads = scrape_yelp(
                            keyword=keyword,
                            location=location,
                            max_results=per_source,
                        )

                    elif src == "yellowpages":
                        from engine.yellowpages_scraper import scrape_yellowpages
                        leads = scrape_yellowpages(
                            keyword=keyword,
                            location=location,
                            max_results=per_source,
                        )
                    else:
                        leads = []

                    leads = leads or []
                    all_leads.extend(leads)

                    log_search(keyword, location, src, len(leads))

                    print(f"✅ {src}: {len(leads)} leads")

                except Exception as e:
                    print(f"⚠️ {src} error: {e}")
                    traceback.print_exc()

        # ─────────────────────────────────────────────
        # No leads found — exit cleanly
        # ─────────────────────────────────────────────
        if not all_leads:
            print(f"⚠️ No leads collected for job {job_id}")
            complete_job(job_id, 0)
            return

        # ─────────────────────────────────────────────
        # Deduplicate
        # ─────────────────────────────────────────────
        try:
            unique, _ = deduplicate_batch(all_leads)
        except Exception:
            unique = all_leads

        total = len(unique)

        update_job_progress(
            job_id, 45, leads_found,
            f"Processing {total} leads...",
        )

        print(f"📋 Processing {total} unique leads...")

        # ─────────────────────────────────────────────
        # Process each lead
        # Pipeline:
        #   enrich → basic score → save → full score
        # ─────────────────────────────────────────────
        for i, lead in enumerate(unique):

            if is_job_stopped(job_id):
                complete_job(job_id, leads_found, status=STATUS_STOPPED)
                return

            name     = lead.get("business_name", "...")
            progress = 45 + int((i / max(total, 1)) * 50)

            update_job_progress(
                job_id, progress, leads_found, f"Saving: {name}",
            )

            # ── Stamp location fields ──────────────────
            if not lead.get("city"):
                lead["city"] = city
            if not lead.get("country"):
                lead["country"] = country
            if not lead.get("location"):
                lead["location"] = location
            if not lead.get("industry") or lead.get("industry") in ("", "unknown"):
                lead["industry"] = keyword

            # ── Step 1: Enrich ─────────────────────────
            if do_enrich:
                try:
                    lead = enrich_lead(
                        lead,
                        find_email=do_email,
                        find_phone=True,
                    )
                except Exception as e:
                    print(f"⚠️ Enrich error: {e}")

            # ── Step 2: Basic score (unchanged) ────────
            try:
                scores = score_lead(lead)
                if isinstance(scores, dict):
                    lead["opportunity_score"] = scores.get(
                        "opportunity_score", 0
                    )
                    lead["contact_score"] = scores.get("contact_score", 0)
                else:
                    lead["opportunity_score"] = scores
            except Exception:
                lead["opportunity_score"] = 0

            # ── Step 3: Script ─────────────────────────
            if do_scripts and has_scripts:
                try:
                    lead["call_script"] = generate_script(lead)
                except Exception:
                    pass

            # ── Step 4: Save to DB ─────────────────────
            saved_id = None
            try:
                ok, msg = insert_lead(lead)
                if ok:
                    leads_found += 1
                    print(f"  💾 [{leads_found}/{total}] Saved: {name}")

                    # msg may carry the new lead_id if database.py
                    # returns it — handle both formats safely
                    if isinstance(msg, int):
                        saved_id = msg
                    elif isinstance(msg, str) and msg.isdigit():
                        saved_id = int(msg)

            except Exception as e:
                print(f"⚠️ Insert error: {e}")

            # ── Step 5: Full intelligence score ────────
            # Runs after save so we have a real lead_id.
            # If insert_lead does not return the id we
            # fall back to a DB lookup by business_name.
            if leads_found > 0:
                if saved_id is None:
                    saved_id = _get_lead_id_by_name(
                        lead.get("business_name", "")
                    )

                if saved_id:
                    _run_full_scoring(lead, saved_id)

        # ── Complete job ───────────────────────────────
        complete_job(job_id, leads_found)

    except Exception as e:
        error_msg = str(e)
        print(f"❌ Job {job_id} failed: {error_msg}")
        traceback.print_exc()
        complete_job(job_id, leads_found, error=error_msg)


# ─────────────────────────────────────────────────────────
# Helper: look up lead_id after insert
# Used when insert_lead does not return the row id.
# ─────────────────────────────────────────────────────────

def _get_lead_id_by_name(business_name: str) -> Optional[int]:
    """
    Fetch the most recently inserted lead_id for a given
    business name. Used as a fallback when insert_lead
    does not return the row id directly.
    """
    if not business_name:
        return None

    try:
        from database import get_connection

        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT id FROM leads
                WHERE business_name = ?
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (business_name,),
            )
            row = cursor.fetchone()
            return row["id"] if row else None
        finally:
            conn.close()

    except Exception as e:
        print(f"⚠️ _get_lead_id_by_name error: {e}")
        return None


# ─────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────

def start_scrape_job(
    keyword: str,
    location: str,
    source: str,
    max_results: int = 20,
    max_pages: int = 5,
    do_enrich: bool = True,
    do_email: bool = True,
    do_scripts: bool = True,
    force_restart: bool = False,
) -> int:
    """
    Start a background scraping job.
    Returns job_id immediately.
    Scraping runs in a background thread.
    """
    parts   = [p.strip() for p in location.split(",")]
    city    = parts[0] if parts else location
    country = parts[-1].strip() if len(parts) > 1 else ""

    job_id = create_job(
        keyword=keyword,
        location=location,
        source=source,
        total_target=max_results,
    )

    thread = threading.Thread(
        target=_run_scrape_job,
        kwargs=dict(
            job_id=job_id,
            keyword=keyword,
            location=location,
            source=source,
            max_results=max_results,
            max_pages=max_pages,
            do_enrich=do_enrich,
            do_email=do_email,
            do_scripts=do_scripts,
            force_restart=force_restart,
            city=city,
            country=country,
        ),
        daemon=True,
        name=f"scrape_job_{job_id}",
    )

    with _jobs_lock:
        _active_jobs[job_id] = thread

    thread.start()

    print(
        f"🚀 Job {job_id} started in background "
        f"thread: {thread.name}"
    )

    return job_id


def get_job_status_summary(job_id: int) -> dict:
    """
    Get a clean status summary for UI display.
    """
    job = get_job(job_id)

    if not job:
        return {
            "found":      False,
            "status":     "unknown",
            "progress":   0,
            "leads":      0,
            "message":    "Job not found",
            "is_done":    False,
            "is_running": False,
        }

    status  = job.get("status", "unknown")
    progress = job.get("progress", 0)
    leads   = job.get("leads_found", 0)
    current = job.get("current_lead", "")
    error   = job.get("error_message", "")

    messages = {
        STATUS_PENDING: "Waiting to start...",
        STATUS_RUNNING: current or "Running...",
        STATUS_DONE:    f"Complete — {leads} leads saved",
        STATUS_FAILED:  f"Failed: {error}",
        STATUS_STOPPED: "Stopped by user",
    }

    return {
        "found":      True,
        "status":     status,
        "progress":   progress,
        "leads":      leads,
        "message":    messages.get(status, status),
        "is_done":    status in [STATUS_DONE, STATUS_FAILED, STATUS_STOPPED],
        "is_running": status == STATUS_RUNNING,
    }


def any_job_running() -> bool:
    """
    Check if any scraping job is currently active.
    """
    return bool(get_running_job())


def get_active_job_id() -> Optional[int]:
    """
    Get the ID of the currently running job.
    Returns None if no job is running.
    """
    job = get_running_job()
    return job.get("id") if job else None
# engine/yellowpages_scraper.py
# v4 — Fixed Google warmup timeout + graceful fallback

import re
import sys
import asyncio
import json
from pathlib import Path
from bs4 import BeautifulSoup

from engine.anti_detection import (
    async_random_delay,
    apply_stealth,
    get_stealth_args,
    build_yp_context,
    human_mouse_move,
    human_scroll,
)


def get_yp_url(
    keyword:  str,
    location: str,
    country:  str,
    page:     int = 1,
) -> str:
    country_lower = country.lower() if country else ""
    keyword_enc   = keyword.strip().replace(" ", "+")
    location_enc  = location.strip().replace(" ", "+")

    if "united kingdom" in country_lower:
        base = (
            f"https://www.yell.com/ucs/UcsSearchAction.do"
            f"?keywords={keyword_enc}"
            f"&location={location_enc}"
        )
        if page > 1:
            base += f"&pageNum={page}"
        return base
    else:
        kw_slug  = (
            keyword.strip().lower().replace(" ", "-")
        )
        loc_slug = (
            location.strip().split(",")[0]
            .lower().replace(" ", "-")
        )
        if page == 1:
            return (
                f"https://www.yellowpages.com"
                f"/{loc_slug}/{kw_slug}"
            )
        return (
            f"https://www.yellowpages.com"
            f"/{loc_slug}/{kw_slug}?page={page}"
        )


def extract_yp_leads(
    html:     str,
    keyword:  str,
    location: str,
    country:  str,
) -> list:
    leads = []
    soup  = BeautifulSoup(html, "lxml")
    parts = [p.strip() for p in location.split(",")]
    city  = parts[0] if parts else location
    country_lower = country.lower() if country else ""
    seen  = set()

    # ── Strategy 1: JSON-LD ──────────────────────────────
    for script in soup.find_all(
        "script", type="application/ld+json"
    ):
        try:
            data  = json.loads(script.string or "")
            items = (
                data if isinstance(data, list) else [data]
            )
            for item in items:
                if not isinstance(item, dict):
                    continue
                name = item.get("name", "").strip()
                if not name or len(name) < 3:
                    continue
                if name in seen:
                    continue
                itype = item.get("@type", "")
                if not any(
                    t in itype for t in [
                        "LocalBusiness", "Organization",
                        "Store", "Restaurant", "Service",
                    ]
                ):
                    continue
                seen.add(name)

                phone   = item.get("telephone", "")
                address = ""
                addr    = item.get("address", {})
                if isinstance(addr, dict):
                    address = ", ".join(filter(None, [
                        addr.get("streetAddress", ""),
                        addr.get("addressLocality", ""),
                        addr.get("postalCode", ""),
                    ]))

                website = item.get("url", "")
                if any(
                    x in website.lower()
                    for x in ["yellowpages", "yell.com"]
                ):
                    website = ""

                rating, reviews = 0.0, 0
                agg = item.get("aggregateRating", {})
                if isinstance(agg, dict):
                    try:
                        rating  = float(
                            agg.get("ratingValue", 0)
                        )
                        reviews = int(
                            agg.get("reviewCount", 0)
                        )
                    except Exception:
                        pass

                leads.append({
                    "business_name": name,
                    "phone":         phone,
                    "email":         "",
                    "website":       website,
                    "address":       address,
                    "rating":        rating,
                    "reviews":       reviews,
                    "source":        "yellowpages",
                    "source_url":    "",
                    "industry":      keyword,
                    "city":          city,
                    "location":      location,
                    "country":       country,
                    "has_website":   1 if website else 0,
                    "has_instagram": 0,
                    "has_facebook":  0,
                })
        except Exception:
            continue

    if leads:
        return leads

    if "united kingdom" in country_lower:
        # ── Yell.com HTML ─────────────────────────────────
        containers = soup.find_all(
            ["article", "li", "div"],
            {"class": re.compile(
                r"businessCapsule|listing|result",
                re.I,
            )},
        )
        for container in containers:
            try:
                name_el = container.find(
                    ["h2", "h3", "a"]
                )
                if not name_el:
                    continue
                name = re.sub(
                    r"^\d+\.\s*",
                    "",
                    name_el.get_text(strip=True),
                ).strip()
                if not name or len(name) < 3:
                    continue
                if name in seen:
                    continue
                seen.add(name)

                phone  = ""
                tel_el = container.find(
                    "a", href=re.compile(r"tel:")
                )
                if tel_el:
                    phone = tel_el["href"].replace(
                        "tel:", ""
                    ).strip()

                website = ""
                web_el  = container.find(
                    "a",
                    {"class": re.compile(
                        r"website|web|url", re.I
                    )},
                )
                if web_el:
                    href = web_el.get("href", "")
                    if "yell.com" not in href.lower():
                        website = href

                address = ""
                addr_el = container.find(
                    ["address", "span", "div"],
                    {"class": re.compile(
                        r"address|location|street",
                        re.I,
                    )},
                )
                if addr_el:
                    address = addr_el.get_text(
                        " ", strip=True
                    )

                leads.append({
                    "business_name": name,
                    "phone":         phone,
                    "email":         "",
                    "website":       website,
                    "address":       address,
                    "rating":        0.0,
                    "reviews":       0,
                    "source":        "yellowpages",
                    "source_url":    "",
                    "industry":      keyword,
                    "city":          city,
                    "location":      location,
                    "country":       country,
                    "has_website":   1 if website else 0,
                    "has_instagram": 0,
                    "has_facebook":  0,
                })
            except Exception:
                continue
    else:
        # ── YellowPages.com US HTML ───────────────────────
        cards = soup.find_all(
            "div",
            {"class": re.compile(
                r"\bresult\b|\bv-card\b|srp-listing",
                re.I,
            )},
        )
        for card in cards:
            try:
                name_el = card.find(
                    "a",
                    {"class": re.compile(
                        r"business-name", re.I
                    )},
                )
                if not name_el:
                    name_el = card.find(["h2", "h3"])
                if not name_el:
                    continue

                name = re.sub(
                    r"^\d+\.\s*",
                    "",
                    name_el.get_text(strip=True),
                ).strip()
                if not name or len(name) < 3:
                    continue
                if name in seen:
                    continue
                seen.add(name)

                phone    = ""
                phone_el = card.find(
                    ["div", "span"],
                    {"class": re.compile(
                        r"\bphones?\b", re.I
                    )},
                )
                if phone_el:
                    phone = phone_el.get_text(strip=True)
                if not phone:
                    tel_el = card.find(
                        "a", href=re.compile(r"tel:")
                    )
                    if tel_el:
                        phone = tel_el["href"].replace(
                            "tel:", ""
                        ).strip()

                address  = ""
                addr_el  = card.find(
                    ["div", "span"],
                    {"class": re.compile(
                        r"\badr\b|street|locality",
                        re.I,
                    )},
                )
                if addr_el:
                    address = addr_el.get_text(
                        " ", strip=True
                    )

                website = ""
                web_el  = card.find(
                    "a",
                    {"class": re.compile(
                        r"track-visit-website|website",
                        re.I,
                    )},
                )
                if web_el:
                    website = web_el.get("href", "")

                rating   = 0.0
                rate_el  = card.find(
                    ["div", "span"],
                    {"class": re.compile(
                        r"rating", re.I
                    )},
                )
                if rate_el:
                    m = re.search(
                        r"(\d+\.?\d*)",
                        rate_el.get("aria-label", "")
                        or rate_el.get_text(),
                    )
                    if m:
                        rating = float(m.group(1))

                leads.append({
                    "business_name": name,
                    "phone":         phone,
                    "email":         "",
                    "website":       website,
                    "address":       address,
                    "rating":        rating,
                    "reviews":       0,
                    "source":        "yellowpages",
                    "source_url":    "",
                    "industry":      keyword,
                    "city":          city,
                    "location":      location,
                    "country":       country,
                    "has_website":   1 if website else 0,
                    "has_instagram": 0,
                    "has_facebook":  0,
                })
            except Exception:
                continue

    return leads


async def _warmup_browser(pg) -> bool:
    """
    Visit a neutral site first to warm up browser.
    Returns True if successful, False if failed.
    Failure is non-fatal — scraping continues anyway.
    """
    warmup_sites = [
        "https://www.bing.com",
        "https://www.wikipedia.org",
        "https://www.bbc.com",
    ]

    for site in warmup_sites:
        try:
            print(f"   🌐 Warmup: visiting {site}...")
            await pg.goto(
                site,
                wait_until="domcontentloaded",
                timeout=20000,  # 20 seconds per site
            )
            await async_random_delay(1, 2)
            print(f"   ✅ Warmup successful")
            return True
        except Exception as e:
            print(f"   ⚠️ Warmup {site} failed: {e}")
            continue

    # All warmup sites failed — continue anyway
    print("   ⚠️ All warmup sites failed — skipping warmup")
    return False


async def scrape_yellowpages_async(
    keyword:     str,
    location:    str,
    max_results: int = 20,
) -> list:
    from playwright.async_api import async_playwright
    from config import HEADLESS_MODE

    parts   = [p.strip() for p in location.split(",")]
    country = parts[-1] if len(parts) > 1 else ""
    is_uk   = "united kingdom" in country.lower()

    all_leads  = []
    seen_names = set()
    page_num   = 1
    max_pages  = max(1, (max_results + 9) // 10)

    source_name = "Yell.com" if is_uk else "YellowPages.com"
    print(f"\n🔍 {source_name}: {keyword} in {location}")

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=HEADLESS_MODE,
            args=get_stealth_args(),
        )

        context = await build_yp_context(
            browser, is_uk=is_uk
        )
        pg = await context.new_page()
        await apply_stealth(pg)

        try:
            # ── Warmup: visit neutral site first ──────────
            # Non-fatal — if warmup fails, we still scrape
            await _warmup_browser(pg)

            # ── Main scraping loop ─────────────────────────
            while (
                len(all_leads) < max_results
                and page_num <= max_pages
            ):
                url = get_yp_url(
                    keyword, location, country, page_num
                )
                print(f"   📄 Page {page_num}: {url}")

                try:
                    await pg.goto(
                        url,
                        wait_until="domcontentloaded",
                        timeout=120000,  # 2 minutes
                        referer=(
                            "https://www.bing.com/"
                        ),
                    )

                    # Human behaviour simulation
                    await async_random_delay(3, 5)
                    await human_mouse_move(pg)
                    await async_random_delay(1, 2)

                    # Wait for listings to appear
                    try:
                        await pg.wait_for_selector(
                            ".result, .v-card, "
                            ".srp-listing, "
                            ".businessCapsule, "
                            "article, h2",
                            timeout=20000,
                        )
                    except Exception:
                        print(
                            f"   ⚠️ Selector timeout "
                            f"page {page_num} — trying anyway"
                        )

                    # Accept cookie banners
                    for btn_text in [
                        "Accept All", "Accept",
                        "I Agree", "OK",
                        "Accept Cookies",
                    ]:
                        try:
                            btn = pg.get_by_role(
                                "button", name=btn_text
                            )
                            if await btn.count() > 0:
                                await btn.first.click(
                                    timeout=3000
                                )
                                await async_random_delay(1, 2)
                                break
                        except Exception:
                            pass

                    # Natural scroll
                    await human_scroll(pg, scroll_times=3)
                    await async_random_delay(1, 2)

                    # Extract leads
                    html  = await pg.content()
                    leads = extract_yp_leads(
                        html, keyword, location, country
                    )

                    if not leads:
                        # Save debug screenshot
                        debug_dir = Path("data/debug")
                        debug_dir.mkdir(
                            parents=True, exist_ok=True
                        )
                        shot_path = (
                            debug_dir
                            / f"yp_page{page_num}.png"
                        )
                        try:
                            await pg.screenshot(
                                path=str(shot_path),
                                full_page=True,
                            )
                            print(
                                f"   📸 Debug screenshot: "
                                f"{shot_path}"
                            )
                        except Exception:
                            pass

                        print(
                            f"   ⚠️ No leads on "
                            f"page {page_num} — stopping"
                        )
                        break

                    # Add new leads
                    new_count = 0
                    for lead in leads:
                        name = lead.get(
                            "business_name", ""
                        )
                        if (
                            name
                            and name not in seen_names
                        ):
                            seen_names.add(name)
                            all_leads.append(lead)
                            new_count += 1
                            print(
                                f"   ✅ {name} | "
                                f"📞 {lead.get('phone','—')}"
                            )
                        if len(all_leads) >= max_results:
                            break

                    print(
                        f"   📊 Page {page_num}: "
                        f"{new_count} new | "
                        f"Total: {len(all_leads)}"
                    )

                    if len(all_leads) >= max_results:
                        break

                    page_num += 1
                    await async_random_delay(4, 7)

                except Exception as e:
                    error_msg = str(e)
                    print(f"   ❌ Page error: {error_msg}")

                    # Save debug screenshot on error
                    try:
                        debug_dir = Path("data/debug")
                        debug_dir.mkdir(
                            parents=True, exist_ok=True
                        )
                        shot_path = (
                            debug_dir
                            / f"yp_error_p{page_num}.png"
                        )
                        await pg.screenshot(
                            path=str(shot_path),
                            full_page=True,
                        )
                        print(
                            f"   📸 Error screenshot: "
                            f"{shot_path}"
                        )
                    except Exception:
                        pass

                    break

        finally:
            try:
                await browser.close()
            except Exception:
                pass

    print(
        f"✅ {source_name} done: {len(all_leads)} leads"
    )
    return all_leads[:max_results]


def scrape_yellowpages(
    keyword:     str,
    location:    str,
    max_results: int = 20,
) -> list:
    """
    Synchronous entry point for YellowPages scraper.
    Called from job_manager.py background thread.
    """
    if sys.platform == "win32":
        loop = asyncio.ProactorEventLoop()
    else:
        loop = asyncio.new_event_loop()

    try:
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(
            scrape_yellowpages_async(
                keyword, location, max_results
            )
        )
    finally:
        try:
            loop.close()
        except Exception:
            pass
# engine/yelp_scraper.py
# v3 — Uses build_yelp_context() with Client Hints
# Saves debug screenshot if 0 leads found

import re
import sys
import asyncio
import json
from pathlib import Path
from bs4 import BeautifulSoup

from engine.anti_detection import (
    async_random_delay,
    apply_stealth,
    get_stealth_args,
    build_yelp_context,
    human_mouse_move,
    human_scroll,
)


def get_yelp_base(country: str) -> str:
    if country and "united kingdom" in country.lower():
        return "https://www.yelp.co.uk"
    return "https://www.yelp.com"


def build_yelp_url(
    keyword: str,
    location: str,
    country: str,
    page: int = 0,
) -> str:
    base          = get_yelp_base(country)
    keyword_slug  = keyword.strip().replace(" ", "+")
    location_slug = location.strip().replace(" ", "+")
    offset        = page * 10

    if offset == 0:
        return (
            f"{base}/search"
            f"?find_desc={keyword_slug}"
            f"&find_loc={location_slug}"
        )
    return (
        f"{base}/search"
        f"?find_desc={keyword_slug}"
        f"&find_loc={location_slug}"
        f"&start={offset}"
    )


def extract_leads_from_yelp_html(
    html: str,
    keyword: str,
    location: str,
) -> list:
    leads = []
    soup  = BeautifulSoup(html, "lxml")

    parts   = [p.strip() for p in location.split(",")]
    city    = parts[0] if parts else location
    country = parts[-1] if len(parts) > 1 else ""
    seen    = set()

    # ── Strategy 1: JSON-LD ──────────────────────────────
    for script in soup.find_all(
        "script", type="application/ld+json"
    ):
        try:
            data  = json.loads(script.string or "")
            items = (
                data if isinstance(data, list) else [data]
            )
            for item in items:
                if not isinstance(item, dict):
                    continue
                name = item.get("name", "").strip()
                if not name or name in seen:
                    continue
                itype = item.get("@type", "")
                if not any(
                    t in itype for t in [
                        "LocalBusiness", "Restaurant",
                        "HealthAndBeautyBusiness",
                        "Store", "Organization",
                        "FoodEstablishment",
                    ]
                ):
                    continue

                seen.add(name)
                phone   = item.get("telephone", "")
                address = ""
                addr    = item.get("address", {})
                if isinstance(addr, dict):
                    address = ", ".join(filter(None, [
                        addr.get("streetAddress", ""),
                        addr.get("addressLocality", ""),
                        addr.get("postalCode", ""),
                    ]))

                rating, reviews = 0.0, 0
                agg = item.get("aggregateRating", {})
                if isinstance(agg, dict):
                    try:
                        rating  = float(agg.get("ratingValue", 0))
                        reviews = int(agg.get("reviewCount", 0))
                    except Exception:
                        pass

                website = item.get("url", "")
                if "yelp" in website.lower():
                    website = ""

                leads.append({
                    "business_name": name,
                    "phone":         phone,
                    "email":         "",
                    "website":       website,
                    "address":       address,
                    "rating":        rating,
                    "reviews":       reviews,
                    "source":        "yelp",
                    "source_url":    item.get("url", ""),
                    "industry":      keyword,
                    "city":          city,
                    "location":      location,
                    "country":       country,
                    "has_website":   1 if website else 0,
                    "has_instagram": 0,
                    "has_facebook":  0,
                })
        except Exception:
            continue

    if leads:
        return leads

    # ── Strategy 2: React window data ───────────────────
    for script in soup.find_all("script"):
        txt = script.string or ""
        if "bizName" in txt or '"name"' in txt:
            try:
                matches = re.findall(
                    r'"(?:bizName|businessName|name)"'
                    r'\s*:\s*"([^"]{3,80})"',
                    txt,
                )
                for name in matches:
                    if name and name not in seen:
                        seen.add(name)
                        leads.append({
                            "business_name": name,
                            "phone":         "",
                            "email":         "",
                            "website":       "",
                            "address":       "",
                            "rating":        0.0,
                            "reviews":       0,
                            "source":        "yelp",
                            "source_url":    "",
                            "industry":      keyword,
                            "city":          city,
                            "location":      location,
                            "country":       country,
                            "has_website":   0,
                            "has_instagram": 0,
                            "has_facebook":  0,
                        })
            except Exception:
                continue

    if leads:
        return leads

    # ── Strategy 3: /biz/ link fallback ─────────────────
    skip_words = [
        "write a review", "see all", "more info",
        "get directions", "claim", "sponsored",
        "next", "previous", "photos", "reviews",
        "menu", "order", "reserve", "website",
    ]
    for link in soup.find_all(
        "a", href=re.compile(r"/biz/")
    ):
        try:
            name = re.sub(
                r"^\d+\.\s*",
                "",
                link.get_text(strip=True),
            ).strip()
            if (
                not name
                or len(name) < 3
                or name.isdigit()
                or name in seen
                or any(s in name.lower() for s in skip_words)
            ):
                continue
            seen.add(name)
            href     = link.get("href", "")
            full_url = (
                href if href.startswith("http")
                else get_yelp_base(country) + href
            )
            leads.append({
                "business_name": name,
                "phone":         "",
                "email":         "",
                "website":       "",
                "address":       "",
                "rating":        0.0,
                "reviews":       0,
                "source":        "yelp",
                "source_url":    full_url,
                "industry":      keyword,
                "city":          city,
                "location":      location,
                "country":       country,
                "has_website":   0,
                "has_instagram": 0,
                "has_facebook":  0,
            })
        except Exception:
            continue

    return leads


async def scrape_yelp_async(
    keyword: str,
    location: str,
    max_results: int = 20,
) -> list:
    from playwright.async_api import async_playwright
    from config import HEADLESS_MODE

    parts   = [p.strip() for p in location.split(",")]
    country = parts[-1] if len(parts) > 1 else ""

    all_leads  = []
    seen_names = set()
    page_num   = 0
    max_pages  = max(1, (max_results + 9) // 10)

    print(f"🔍 Yelp: {keyword} in {location}")

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=HEADLESS_MODE,
            args=get_stealth_args(),
        )

        # ── Use Yelp-specific context with Client Hints ──
        context = await build_yelp_context(browser)
        page    = await context.new_page()
        await apply_stealth(page)

        try:
            while (
                len(all_leads) < max_results
                and page_num < max_pages
            ):
                url = build_yelp_url(
                    keyword, location, country, page_num
                )
                print(f"   📄 Page {page_num + 1}: {url}")

                try:
                    # ── First visit google then navigate ──
                    # Looks like organic traffic to Yelp
                    if page_num == 0:
                        await page.goto(
                            "https://www.google.com",
                            wait_until="domcontentloaded",
                            timeout=30000,
                        )
                        await async_random_delay(2, 3)

                    await page.goto(
                        url,
                        wait_until="domcontentloaded",
                        timeout=90000,
                        referer="https://www.google.com/",
                    )

                    # ── Human simulation ──
                    await async_random_delay(3, 5)
                    await human_mouse_move(page)
                    await async_random_delay(1, 2)

                    # ── Wait for content ──
                    try:
                        await page.wait_for_selector(
                            'h3, [class*="businessName"],'
                            'a[href*="/biz/"],'
                            'script[type="application/ld+json"]',
                            timeout=15000,
                        )
                    except Exception:
                        pass

                    # ── Scroll naturally ──
                    await human_scroll(page, scroll_times=3)
                    await async_random_delay(2, 3)

                    # ── Handle popups ──
                    for btn_text in [
                        "Accept All", "Accept",
                        "I Agree", "OK", "Got it",
                        "Close", "No Thanks",
                    ]:
                        try:
                            btn = page.get_by_role(
                                "button", name=btn_text
                            )
                            if await btn.count() > 0:
                                await btn.first.click(
                                    timeout=2000
                                )
                                await async_random_delay(1, 2)
                                break
                        except Exception:
                            pass

                    html = await page.content()

                    # ── Debug: save screenshot if no leads ──
                    leads = extract_leads_from_yelp_html(
                        html, keyword, location
                    )

                    if not leads:
                        # Save screenshot for debugging
                        debug_dir = Path("data/debug")
                        debug_dir.mkdir(
                            parents=True, exist_ok=True
                        )
                        shot_path = (
                            debug_dir
                            / f"yelp_page{page_num + 1}.png"
                        )
                        await page.screenshot(
                            path=str(shot_path),
                            full_page=True,
                        )
                        print(
                            f"   📸 Screenshot saved: "
                            f"{shot_path}"
                        )
                        print(
                            f"   ⚠️ No leads on page "
                            f"{page_num + 1}"
                        )

                        # One more scroll + retry
                        await page.evaluate(
                            "window.scrollTo("
                            "0, document.body.scrollHeight)"
                        )
                        await async_random_delay(3, 4)
                        html  = await page.content()
                        leads = extract_leads_from_yelp_html(
                            html, keyword, location
                        )

                    if not leads:
                        print("   ⛔ Stopping — no data")
                        break

                    new_count = 0
                    for lead in leads:
                        name = lead.get("business_name", "")
                        if name and name not in seen_names:
                            seen_names.add(name)
                            all_leads.append(lead)
                            new_count += 1
                            print(
                                f"   ✅ {name} | "
                                f"📞 {lead.get('phone','—')}"
                            )
                        if len(all_leads) >= max_results:
                            break

                    print(
                        f"   📊 Page {page_num + 1}: "
                        f"{new_count} new | "
                        f"Total: {len(all_leads)}"
                    )

                    if len(all_leads) >= max_results:
                        break

                    page_num += 1
                    await async_random_delay(5, 8)

                except Exception as e:
                    print(f"   ❌ Page error: {e}")
                    break

        finally:
            await browser.close()

    print(f"✅ Yelp done: {len(all_leads)} leads")
    return all_leads[:max_results]


def scrape_yelp(
    keyword: str,
    location: str,
    max_results: int = 20,
) -> list:
    if sys.platform == "win32":
        loop = asyncio.ProactorEventLoop()
    else:
        loop = asyncio.new_event_loop()

    try:
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(
            scrape_yelp_async(keyword, location, max_results)
        )
    finally:
        try:
            loop.close()
        except Exception:
            pass
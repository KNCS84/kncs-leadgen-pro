# engine/deduplicator.py
"""
Deduplication engine.

Two-level check:
1. Within the current batch (same scrape session)
2. Against the database (existing saved leads)

For B2BHint re-scrapes of the same keyword:
- Leads already in DB are NOT blocked — they pass through
  so the upsert logic in database.py can update missing
  phone/email/score fields.
- Only true batch duplicates (same name scraped twice
  in one session) are dropped here.
"""

from database import get_connection


def is_exact_duplicate(business_name: str, phone: str) -> bool:
    """
    Returns True ONLY if this exact name+phone combo exists
    AND both phone fields are non-empty.
    If phone is empty on either side, match by name only
    but return False so the upsert can update the record.
    """
    if not business_name:
        return False

    conn   = get_connection()
    cursor = conn.cursor()

    try:
        if phone and phone.strip():
            # Both name and phone present — check exact match
            cursor.execute("""
                SELECT id, email, phone, city FROM leads
                WHERE business_name = ?
                AND phone = ?
                AND phone != ''
                LIMIT 1
            """, (business_name.strip(), phone.strip()))
        else:
            # No phone — check name only
            cursor.execute("""
                SELECT id, email, phone, city FROM leads
                WHERE business_name = ?
                LIMIT 1
            """, (business_name.strip(),))

        row = cursor.fetchone()

        if not row:
            return False  # Not in DB at all — it's new

        existing = dict(row)

        # It exists — but check if it's missing useful data
        # If it is, return False so upsert can fill it in
        missing_email   = not existing.get("email")
        missing_phone   = not existing.get("phone")
        missing_city    = not existing.get("city")

        if missing_email or missing_phone or missing_city:
            # Let it through — upsert will add the missing data
            return False

        # All fields present — true duplicate, block it
        return True

    finally:
        conn.close()


def leads_already_in_db(business_names: list) -> set:
    """
    Return set of business names that already exist in DB.
    Used for page-skip logic in the scraper.
    """
    if not business_names:
        return set()

    conn   = get_connection()
    cursor = conn.cursor()

    try:
        placeholders = ",".join(["?" for _ in business_names])
        cursor.execute(
            f"SELECT business_name FROM leads "
            f"WHERE business_name IN ({placeholders})",
            business_names
        )
        return {row[0] for row in cursor.fetchall()}
    finally:
        conn.close()


def deduplicate_batch(leads: list) -> tuple:
    """
    Remove within-batch duplicates only.
    Does NOT block leads already in DB — those go through
    the smart upsert which fills in missing fields.

    Returns: (unique_leads, duplicate_count)
    """
    new_leads       = []
    duplicate_count = 0
    seen_in_batch   = set()

    for lead in leads:
        name  = (lead.get("business_name") or "").strip()
        phone = (lead.get("phone") or "").strip()

        if not name:
            duplicate_count += 1
            continue

        # Key: name + phone if available, else just name
        if phone:
            batch_key = f"{name.lower()}|{phone}"
        else:
            batch_key = name.lower()

        if batch_key in seen_in_batch:
            duplicate_count += 1
            continue

        seen_in_batch.add(batch_key)
        new_leads.append(lead)

    return new_leads, duplicate_count
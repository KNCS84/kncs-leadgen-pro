# engine/router.py — v9.6
# Country-aware channel routing + WhatsApp estimated vs verified

from __future__ import annotations

import re
from datetime import datetime, timezone

try:
    from engine.country_router import enrich_lead_with_country, get_market_profile
except Exception:  # pragma: no cover
    def enrich_lead_with_country(lead: dict) -> dict:
        return lead

    def get_market_profile(country: str) -> dict:
        return {
            "market": "other",
            "preferred_channels": ["call", "email", "whatsapp_verified"],
            "wa_primary": False,
            "tone": "direct",
        }


# ─────────────────────────────────────────
# Phone validation
# ─────────────────────────────────────────

def is_valid_phone(phone: str) -> bool:
    if not phone:
        return False
    phone = str(phone).strip()
    cleaned = re.sub(r"[\s\-\(\)\.]", "", phone)
    digit_count = sum(c.isdigit() for c in cleaned)
    if digit_count < 7 or digit_count > 15:
        return False
    placeholders = {"0000000", "1111111", "1234567", "9999999"}
    if any(p in cleaned for p in placeholders):
        return False
    return True


def is_valid_email(email: str) -> bool:
    if not email:
        return False
    email = str(email).strip().lower()
    pattern = r"^[a-zA-Z0-9_.+\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-.]+$"
    if not re.match(pattern, email):
        return False
    fake_domains = {
        "example.com", "test.com", "placeholder.com",
        "noreply.com", "no-reply.com"
    }
    domain = email.split("@")[-1]
    if domain in fake_domains:
        return False
    return True


# ─────────────────────────────────────────
# WhatsApp readiness logic
# ─────────────────────────────────────────

WHATSAPP_FRIENDLY_INDUSTRIES = {
    "restaurant", "hotel", "salon", "beauty", "spa", "clinic",
    "pharmacy", "logistics", "transport", "travel", "events",
    "catering", "cleaning", "plumbing", "electrical", "retail",
    "fashion", "real estate", "property", "agency", "freelance",
    "consulting", "photography", "fitness", "gym", "laundry",
    "dentist", "mechanic", "garage", "builder", "construction",
}

WHATSAPP_PRIMARY_COUNTRIES = {
    "nigeria", "ghana", "kenya", "south africa",
    "india", "pakistan", "bangladesh", "indonesia",
    "philippines", "malaysia", "singapore", "uae",
    "united arab emirates", "saudi arabia", "egypt",
    "brazil", "mexico", "colombia", "argentina", "chile",
}

WHATSAPP_MEDIUM_COUNTRIES = {
    "united kingdom", "uk", "ireland", "germany", "france",
    "italy", "spain", "netherlands", "belgium", "switzerland",
    "austria", "sweden", "norway", "denmark", "finland", "poland",
}

CALL_HEAVY_INDUSTRIES = {
    "hotel", "restaurant", "clinic", "pharmacy", "plumbing",
    "electrical", "transport", "logistics", "cleaning",
    "construction", "security", "insurance", "estate agent",
    "solicitor", "accountant", "dentist", "mechanic", "garage",
    "lawyer", "doctor", "doctor's office",
}


def estimate_whatsapp_readiness(lead: dict) -> dict:
    lead = enrich_lead_with_country(dict(lead or {}))

    phone = lead.get("phone", "") or ""
    if not is_valid_phone(phone):
        return {
            "whatsapp_ready": 0,
            "confidence": "high",
            "wa_status": "unknown",
            "wa_verified": 0,
            "wa_opt_in": 0,
            "wa_eligible": 0,
            "reason": "No valid phone number present",
        }

    # Explicit verification always wins
    wa_verified_flag = int(lead.get("wa_verified", 0) or lead.get("whatsapp_verified", 0) or 0)
    wa_opt_in_flag = int(lead.get("wa_opt_in", 0) or 0)
    explicit_status = str(lead.get("wa_status") or lead.get("verification_status") or "").strip().lower()

    if explicit_status in {"verified", "opted_in"} or wa_verified_flag:
        return {
            "whatsapp_ready": 1,
            "confidence": "high",
            "wa_status": "verified" if wa_verified_flag else explicit_status or "verified",
            "wa_verified": 1,
            "wa_opt_in": 1 if explicit_status == "opted_in" or wa_opt_in_flag else 0,
            "wa_eligible": 1,
            "reason": "Manually verified as WhatsApp active",
        }

    country = str(lead.get("country") or "").lower().strip()
    industry = str(lead.get("industry") or "").lower().strip()
    market = str(lead.get("market") or "").lower().strip()
    source = str(lead.get("source") or "").lower().strip()

    if "companies house" in source or "uk" in source:
        country = country or "united kingdom"

    industry_match = any(ind in industry for ind in WHATSAPP_FRIENDLY_INDUSTRIES)
    phone_verified = int(lead.get("phone_verified", 0) or 0)

    # Primary markets: WhatsApp is usually a good fit, but still only "estimated" unless verified
    if country in WHATSAPP_PRIMARY_COUNTRIES or market in {"nigeria", "africa", "latam", "asia", "middle_east"}:
        if phone_verified and industry_match:
            return {
                "whatsapp_ready": 1,
                "confidence": "high",
                "wa_status": "business_confirmed",
                "wa_verified": 0,
                "wa_opt_in": 0,
                "wa_eligible": 1,
                "reason": f"Primary WhatsApp market + WhatsApp-friendly industry ({industry})",
            }
        return {
            "whatsapp_ready": 1,
            "confidence": "high" if industry_match else "medium",
            "wa_status": "estimated",
            "wa_verified": 0,
            "wa_opt_in": 0,
            "wa_eligible": 1,
            "reason": (
                f"Primary WhatsApp market ({country or market})"
                + (f" + WhatsApp-friendly industry ({industry})" if industry_match else "")
            ),
        }

    # Medium markets: don't over-claim WhatsApp
    if country in WHATSAPP_MEDIUM_COUNTRIES or market in {"uk", "europe", "north_america"}:
        return {
            "whatsapp_ready": 0,
            "confidence": "medium" if industry_match else "low",
            "wa_status": "unknown",
            "wa_verified": 0,
            "wa_opt_in": 0,
            "wa_eligible": 0,
            "reason": "UK/EU/NA market — use email/call first unless WhatsApp is confirmed",
        }

    return {
        "whatsapp_ready": 0,
        "confidence": "low",
        "wa_status": "unknown",
        "wa_verified": 0,
        "wa_opt_in": 0,
        "wa_eligible": 0,
        "reason": "Country unknown — cannot confirm WhatsApp readiness",
    }


# ─────────────────────────────────────────
# Full channel routing
# ─────────────────────────────────────────

def assign_channel(lead: dict) -> dict:
    lead = enrich_lead_with_country(dict(lead or {}))

    phone = lead.get("phone", "") or ""
    email = lead.get("email", "") or ""
    industry = str(lead.get("industry", "") or "").lower()
    fit_score = int(lead.get("fit_score", 0) or 0)

    has_phone = is_valid_phone(phone)
    has_email = is_valid_email(email)

    wa_result = estimate_whatsapp_readiness(lead)
    whatsapp_ready = int(wa_result["whatsapp_ready"])
    wa_status = wa_result["wa_status"]

    wa_verified = 1 if wa_status in {"verified", "opted_in"} else 0
    wa_opt_in = 1 if wa_status == "opted_in" else 0
    wa_eligible = int(wa_result.get("wa_eligible", whatsapp_ready))

    call_ready = 1 if has_phone else 0
    email_ready = 1 if has_email else 0

    ai_call_ready = 1 if has_phone and any(ind in industry for ind in CALL_HEAVY_INDUSTRIES) and fit_score >= 6 else 0
    manual_review = 1 if not has_phone and not has_email else 0

    market_profile = get_market_profile(lead.get("country", ""))
    preferred_channels = market_profile.get("preferred_channels", [])
    market = market_profile.get("market", "other")

    # Best channel selection
    if whatsapp_ready and wa_status in {"verified", "opted_in"}:
        best_channel = "whatsapp"
        channel_label = "WhatsApp ✓"
        routing_reason = wa_result["reason"]

    elif whatsapp_ready:
        best_channel = "whatsapp"
        channel_label = "WhatsApp Estimated"
        routing_reason = wa_result["reason"]

    elif ai_call_ready and fit_score >= 6:
        best_channel = "ai_call"
        channel_label = "AI Call"
        routing_reason = f"Call-heavy industry ({industry}) with strong fit score ({fit_score})"

    elif email_ready and preferred_channels and preferred_channels[0] == "email":
        best_channel = "email"
        channel_label = "Email First"
        routing_reason = "Market prefers email before call/WhatsApp"

    elif email_ready and has_phone:
        best_channel = "email"
        channel_label = "Email + Call"
        routing_reason = "Both email and phone present. Lead with email first."

    elif call_ready:
        best_channel = "manual"
        channel_label = "Call Only"
        routing_reason = "Phone present — use manual call."

    elif manual_review:
        best_channel = "manual"
        channel_label = "Manual Research"
        routing_reason = "No reliable contact method. Needs research."

    else:
        best_channel = "manual"
        channel_label = "Unrouted"
        routing_reason = "Insufficient data to route automatically."

    routing_channel = best_channel

    return {
        "country": lead.get("country", ""),
        "market": market,
        "timezone": lead.get("timezone", ""),
        "phone_country_code": lead.get("phone_country_code", ""),
        "country_confidence": lead.get("country_confidence", "low"),

        "call_ready": call_ready,
        "email_ready": email_ready,
        "whatsapp_ready": whatsapp_ready,
        "whatsapp_verified": wa_verified,
        "wa_verified": wa_verified,
        "wa_opt_in": wa_opt_in,
        "wa_eligible": wa_eligible,
        "wa_status": wa_status,

        "ai_call_ready": ai_call_ready,
        "manual_review": manual_review,
        "best_channel": best_channel,
        "routing_channel": routing_channel,
        "channel_label": channel_label,
        "routing_reason": routing_reason,

        "verification_status": wa_status if wa_status in {"verified", "opted_in"} else "unverified",
        "phone_verified": 1 if has_phone else 0,

        "whatsapp_check_attempted": 1,
        "whatsapp_check_at": datetime.now(timezone.utc).isoformat(),
    }


# ─────────────────────────────────────────
# Batch routing
# ─────────────────────────────────────────

def batch_route_leads(leads: list[dict]) -> list[dict]:
    results = []
    for lead in leads:
        try:
            updates = assign_channel(lead)
            results.append({"id": lead.get("id"), "updates": updates})
        except Exception as e:
            results.append({
                "id": lead.get("id"),
                "updates": {
                    "channel_label": "Error",
                    "routing_reason": f"Routing failed: {str(e)}",
                    "manual_review": 1,
                },
            })
    return results


def apply_routing_updates(conn, routing_results: list[dict]):
    cursor = conn.cursor()
    for result in routing_results:
        lead_id = result["id"]
        updates = result["updates"]
        if not lead_id or not updates:
            continue
        set_clause = ", ".join(f"{col} = ?" for col in updates.keys())
        values = list(updates.values()) + [lead_id]
        cursor.execute(f"UPDATE leads SET {set_clause}, updated_at = datetime('now') WHERE id = ?", values)
    conn.commit()
    cursor.close()
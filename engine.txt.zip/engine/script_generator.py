# engine/script_generator.py
"""
Script generator for sales call scripts.

Provides:
- generate_script()          ← main function
- generate_script_with_ai()  ← Cloudflare AI
- get_script_template()      ← template fallback
- generate_call_script()     ← compatibility alias

Falls back to templates automatically
if Cloudflare AI is not configured.
"""

import requests

# ─────────────────────────────────────────────────────────
# Config import
# ─────────────────────────────────────────────────────────

try:
    from config import (
        CLOUDFLARE_ACCOUNT_ID,
        CLOUDFLARE_API_TOKEN,
        CF_AI_URL,
        CF_MODEL,
        CF_AI_ENABLED,
    )

    AI_ACCOUNT_ID = CLOUDFLARE_ACCOUNT_ID
    AI_API_TOKEN  = CLOUDFLARE_API_TOKEN
    AI_MODEL      = CF_MODEL
    AI_ENABLED    = CF_AI_ENABLED

except Exception:

    AI_ACCOUNT_ID = ""
    AI_API_TOKEN  = ""
    AI_MODEL      = "@cf/meta/llama-3-8b-instruct"
    AI_ENABLED    = False


# ─────────────────────────────────────────────────────────
# Script templates
# ─────────────────────────────────────────────────────────

SCRIPT_TEMPLATES = {

    "no_website": """
📞 COLD CALL SCRIPT — NO WEBSITE

OPENING:
"Hello, may I speak with the owner or manager please?"

HOOK:
"My name is [Your Name]. I was looking at {business_name}
and noticed it does not appear to have a website yet."

PROBLEM:
"Right now, most customers search online before calling
or visiting a business. Without a website, many of those
customers may go to competitors instead."

SOLUTION:
"I help local businesses like yours get a simple,
professional website that attracts more customers —
often within days, not months."

OBJECTION HANDLING:
- "We're too busy" → "That's exactly why I handle everything for you."
- "Too expensive" → "We have starter packages under ₦100K."
- "We get referrals" → "Imagine doubling that with online visibility."

CLOSE:
"Would you be open to a short conversation this week
so I can show you what that could look like for {business_name}?"
""",

    "dead_website": """
📞 COLD CALL SCRIPT — BROKEN WEBSITE

OPENING:
"Hello, is this the owner or manager of {business_name}?"

HOOK:
"I tried to visit your website and it does not seem
to be loading correctly right now."

PROBLEM:
"When a website is broken or slow, potential customers
often assume the business is closed or unreliable.
You could be losing leads right now without knowing."

SOLUTION:
"I specialize in fixing and upgrading local business
websites quickly. I can have yours back up and looking
professional within days."

CLOSE:
"Can I show you what we can fix and improve this week?"
""",

    "low_reviews": """
📞 COLD CALL SCRIPT — LOW REVIEWS

OPENING:
"Hello, may I speak with the business owner?"

HOOK:
"I noticed {business_name} has a solid rating of {rating}
but only {reviews} reviews so far."

PROBLEM:
"Most customers only trust businesses with many
visible reviews. More reviews means more trust,
which means more customers choosing you."

SOLUTION:
"I help local businesses build their online reputation
and get found more easily on Google."

CLOSE:
"Would you like me to walk you through how this works?
It usually takes less than 10 minutes to explain."
""",

    "has_social": """
📞 COLD CALL SCRIPT — HAS SOCIAL MEDIA

OPENING:
"Hello, may I speak with the owner or manager?"

HOOK:
"I can see {business_name} is active on social media —
that is great. But I noticed your overall digital
presence could be significantly stronger."

PROBLEM:
"Social media alone is not enough. Customers who
find you on Google are much more likely to buy
than casual social media followers."

SOLUTION:
"I help businesses like yours turn their social
presence into a full digital strategy that generates
consistent leads."

CLOSE:
"Could we talk for 10 minutes this week about
what that could look like for {business_name}?"
""",

    "default": """
📞 COLD CALL SCRIPT

OPENING:
"Hello, may I speak with the owner or manager please?"

HOOK:
"My name is [Your Name] and I help local businesses
improve their online presence and attract more customers."

PROBLEM:
"Many businesses in your area are losing potential
customers because their digital presence is weak
or incomplete."

SOLUTION:
"I can help {business_name} get more visibility online,
build trust with customers, and generate more enquiries."

OBJECTION HANDLING:
- "Not interested" → "I understand. Can I send you some info just in case?"
- "Call back later" → "Of course. What time works best?"
- "We do it ourselves" → "I can show you how to make it even more effective."

CLOSE:
"Would you be open to a quick 10-minute call this week?"
""",
}


# ─────────────────────────────────────────────────────────
# Template selector
# ─────────────────────────────────────────────────────────

def get_script_template(lead: dict) -> str:
    """
    Return the best script template based on lead data.

    Selection logic:
    1. Dead website → dead_website template
    2. No website   → no_website template
    3. Low reviews  → low_reviews template
    4. Has social   → has_social template
    5. Default      → default template
    """

    if not lead:
        return SCRIPT_TEMPLATES["default"]

    business_name  = lead.get("business_name", "your business")
    rating         = float(lead.get("rating", 0) or 0)
    reviews        = int(lead.get("reviews", 0) or 0)
    website        = lead.get("website") or ""
    website_active = bool(lead.get("website_active"))
    has_instagram  = bool(lead.get("has_instagram"))
    has_facebook   = bool(lead.get("has_facebook"))

    # Select template
    if website and not website_active:
        key = "dead_website"

    elif not website:
        key = "no_website"

    elif reviews < 20:
        key = "low_reviews"

    elif has_instagram or has_facebook:
        key = "has_social"

    else:
        key = "default"

    template = SCRIPT_TEMPLATES[key]

    # Safe format — only replace known placeholders
    try:
        return template.format(
            business_name=business_name,
            rating=rating,
            reviews=reviews,
            website=website,
        )
    except Exception:
        return template


# ─────────────────────────────────────────────────────────
# AI generation
# ─────────────────────────────────────────────────────────

def generate_script_with_ai(lead: dict) -> str:
    """
    Generate personalized script using Cloudflare Workers AI.
    Falls back to template if:
    - AI not configured
    - API call fails
    - Response is empty
    """

    if not AI_ENABLED or not AI_ACCOUNT_ID or not AI_API_TOKEN:
        return get_script_template(lead)

    business_name  = lead.get("business_name", "Unknown")
    rating         = lead.get("rating", 0) or 0
    reviews        = lead.get("reviews", 0) or 0
    website        = lead.get("website") or "None"
    website_active = "Yes" if lead.get("website_active") else "No"
    industry       = lead.get("industry", "Local business")
    city           = lead.get("city", "the area")
    country        = lead.get("country", "")
    has_email      = "Yes" if lead.get("email") else "No"
    score          = lead.get("opportunity_score", 0)

    prompt = f"""
Write a short, persuasive cold call script for
selling digital marketing services to a local business.

Business Details:
- Name: {business_name}
- Industry: {industry}
- Location: {city}{', ' + country if country else ''}
- Rating: {rating} stars
- Reviews: {reviews}
- Website: {website}
- Website Active: {website_active}
- Has Email: {has_email}
- Opportunity Score: {score}/100

Requirements:
- Greeting and introduction
- Hook based on their weakness
- Clear problem statement
- Simple solution offer
- Handle 2 common objections
- Strong close
- Under 300 words
- Conversational and natural tone
- Suitable for phone call
"""

    try:
        url = (
            f"https://api.cloudflare.com/client/v4/"
            f"accounts/{AI_ACCOUNT_ID}/ai/run/{AI_MODEL}"
        )

        headers = {
            "Authorization": f"Bearer {AI_API_TOKEN}",
            "Content-Type":  "application/json",
        }

        payload = {
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are an expert sales coach. "
                        "Write short, effective cold call "
                        "scripts for digital marketing sales."
                    ),
                },
                {
                    "role":    "user",
                    "content": prompt,
                },
            ],
            "max_tokens": 600,
        }

        resp = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=30,
        )

        if resp.status_code == 200:
            data = resp.json()

            if data.get("success"):
                result   = data.get("result", {})
                response = result.get("response", "")

                if response and len(response) > 50:
                    return response

    except Exception as e:
        print(f"⚠️ AI script error: {e}")

    return get_script_template(lead)


# ─────────────────────────────────────────────────────────
# Main function
# ─────────────────────────────────────────────────────────

def generate_script(lead: dict) -> str:
    """
    Main script generation entry point.

    Tries AI first if configured.
    Always falls back to templates.
    Never raises an exception.
    """

    try:
        return generate_script_with_ai(lead)
    except Exception:
        pass

    try:
        return get_script_template(lead)
    except Exception:
        pass

    return SCRIPT_TEMPLATES["default"]


# ─────────────────────────────────────────────────────────
# Compatibility aliases
# ─────────────────────────────────────────────────────────

def generate_call_script(lead: dict) -> str:
    """
    Backward-compatible alias.
    Used by call_center.py and older code.
    """
    return generate_script(lead)
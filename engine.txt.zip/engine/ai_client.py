from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import sqlite3
import threading
import time
from datetime import datetime
from typing import Any

import requests
from dotenv import load_dotenv

try:
    from database import get_connection
except Exception:  # pragma: no cover
    get_connection = None

load_dotenv()
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────

CLOUDFLARE_ACCOUNT_ID = os.getenv("CLOUDFLARE_ACCOUNT_ID", "").strip()
CLOUDFLARE_API_TOKEN = (
    os.getenv("CLOUDFLARE_API_TOKEN")
    or os.getenv("CF_API_TOKEN")
    or os.getenv("CLOUDFLARE_TOKEN")
    or ""
).strip()
CLOUDFLARE_AI_MODEL = (
    os.getenv("CLOUDFLARE_AI_MODEL")
    or "@cf/meta/llama-3.1-8b-instruct"
).strip()

REQUEST_TIMEOUT = float(os.getenv("AI_REQUEST_TIMEOUT", "45"))
MIN_CALL_DELAY = float(os.getenv("AI_MIN_CALL_DELAY", "1.5"))
CACHE_TTL_SECONDS = int(os.getenv("AI_CACHE_TTL_SECONDS", "86400"))
FAILURE_THRESHOLD = int(os.getenv("AI_FAILURE_THRESHOLD", "3"))
CIRCUIT_OPEN_SECONDS = int(os.getenv("AI_CIRCUIT_OPEN_SECONDS", "120"))
BASE_BACKOFF_SECONDS = float(os.getenv("AI_BACKOFF_SECONDS", "2.0"))
MAX_ATTEMPTS = int(os.getenv("AI_MAX_ATTEMPTS", "3"))
JITTER_SECONDS = float(os.getenv("AI_JITTER_SECONDS", "0.35"))

_lock = threading.Lock()
_last_call_at = 0.0
_consecutive_failures = 0
_circuit_open_until = 0.0


# ─────────────────────────────────────────────────────────
# CACHE TABLE
# ─────────────────────────────────────────────────────────

def _ensure_cache_schema() -> None:
    if get_connection is None:
        return

    conn = None
    try:
        conn = get_connection()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ai_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                prompt_hash TEXT UNIQUE,
                model TEXT,
                response_text TEXT,
                response_json TEXT,
                hit_count INTEGER DEFAULT 0,
                fail_count INTEGER DEFAULT 0,
                cached_at TEXT DEFAULT (datetime('now')),
                last_used_at TEXT,
                last_status TEXT DEFAULT 'ok'
            )
        """)
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_ai_cache_hash ON ai_cache(prompt_hash)"
        )
        conn.commit()
    finally:
        if conn:
            conn.close()


# ─────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────

def _hash_prompt(prompt: str, model: str, max_tokens: int, temperature: float) -> str:
    """
    Cache key includes temperature because the same prompt can legitimately
    produce different outputs at different temperatures.
    """
    temp_key = f"{float(temperature):.3f}"
    raw = f"{model}|{max_tokens}|{temp_key}|{prompt}".encode("utf-8", errors="ignore")
    return hashlib.sha256(raw).hexdigest()


def _row_value(row: Any, key: str, index: int, default: Any = "") -> Any:
    try:
        return row[key]
    except Exception:
        try:
            return row[index]
        except Exception:
            return default


def _throttle() -> None:
    """
    Enforce minimum spacing between calls.
    Uses a lock to keep timing sane across concurrent Streamlit reruns.
    """
    global _last_call_at

    with _lock:
        now = time.time()
        elapsed = now - _last_call_at
        wait_for = max(0.0, MIN_CALL_DELAY - elapsed)
        _last_call_at = now + wait_for

    if wait_for > 0:
        time.sleep(wait_for)


def _open_circuit(seconds: float) -> None:
    global _circuit_open_until
    with _lock:
        _circuit_open_until = max(_circuit_open_until, time.time() + float(seconds))


def is_circuit_open() -> bool:
    with _lock:
        return time.time() < _circuit_open_until


def _reset_failure_state() -> None:
    global _consecutive_failures, _circuit_open_until
    with _lock:
        _consecutive_failures = 0
        _circuit_open_until = 0.0


def _record_failure(status_code: int | None = None, retry_after: float = 0.0) -> float:
    """
    Track failures and return a backoff delay for retry loops.

    Circuit breaker behavior:
    - 429 opens the circuit immediately.
    - repeated failures open the circuit after threshold is hit.
    """
    global _consecutive_failures

    with _lock:
        _consecutive_failures += 1
        failure_num = _consecutive_failures

    backoff = BASE_BACKOFF_SECONDS * (2 ** max(0, failure_num - 1))
    backoff = min(backoff, 60.0)
    backoff += random.uniform(0.0, JITTER_SECONDS)

    if retry_after and retry_after > 0:
        backoff = max(backoff, retry_after)

    if status_code == 429:
        _open_circuit(max(CIRCUIT_OPEN_SECONDS, backoff))
    elif failure_num >= FAILURE_THRESHOLD:
        _open_circuit(max(CIRCUIT_OPEN_SECONDS, backoff))

    return backoff


def _record_success() -> None:
    _reset_failure_state()


def _parse_retry_after(header_value: str | None) -> float:
    if not header_value:
        return 0.0
    try:
        return max(0.0, float(header_value))
    except (TypeError, ValueError):
        return 0.0


def _cache_get(prompt_hash: str) -> str:
    if get_connection is None:
        return ""

    _ensure_cache_schema()
    conn = None
    try:
        conn = get_connection()
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            """
            SELECT response_text, cached_at
            FROM ai_cache
            WHERE prompt_hash = ?
            LIMIT 1
            """,
            (prompt_hash,),
        ).fetchone()

        if not row:
            return ""

        cached_at = _row_value(row, "cached_at", 1, "")
        response_text = _row_value(row, "response_text", 0, "")

        if cached_at:
            try:
                cached_dt = datetime.fromisoformat(str(cached_at))
                age = (datetime.utcnow() - cached_dt).total_seconds()
                if age > CACHE_TTL_SECONDS:
                    return ""
            except Exception:
                # If date parsing fails, still allow cache hit rather than fail closed.
                pass

        conn.execute(
            """
            UPDATE ai_cache
            SET hit_count = hit_count + 1,
                last_used_at = datetime('now'),
                last_status = 'cache_hit'
            WHERE prompt_hash = ?
            """,
            (prompt_hash,),
        )
        conn.commit()
        return str(response_text or "")
    except Exception:
        return ""
    finally:
        if conn:
            conn.close()


def _cache_set(prompt_hash: str, response_text: str, response_json: str = "") -> None:
    if get_connection is None:
        return

    _ensure_cache_schema()
    conn = None
    try:
        conn = get_connection()
        conn.execute(
            """
            INSERT INTO ai_cache (
                prompt_hash, model, response_text, response_json,
                hit_count, fail_count, cached_at, last_used_at, last_status
            )
            VALUES (?, ?, ?, ?, 0, 0, datetime('now'), datetime('now'), 'ok')
            ON CONFLICT(prompt_hash) DO UPDATE SET
                model=excluded.model,
                response_text=excluded.response_text,
                response_json=excluded.response_json,
                cached_at=datetime('now'),
                last_used_at=datetime('now'),
                last_status='ok'
            """,
            (prompt_hash, CLOUDFLARE_AI_MODEL, response_text, response_json),
        )
        conn.commit()
    finally:
        if conn:
            conn.close()


def _extract_text(payload: Any) -> str:
    if payload is None:
        return ""

    if isinstance(payload, str):
        return payload.strip()

    if isinstance(payload, (int, float, bool)):
        return str(payload).strip()

    if isinstance(payload, list):
        for item in payload:
            text = _extract_text(item)
            if text:
                return text
        try:
            return json.dumps(payload, ensure_ascii=False)
        except Exception:
            return ""

    if isinstance(payload, dict):
        # Cloudflare AI often returns {"result": ...}
        if "result" in payload:
            result = payload.get("result")
            text = _extract_text(result)
            if text:
                return text

        for key in ("response", "text", "output", "content", "message"):
            value = payload.get(key)
            text = _extract_text(value)
            if text:
                return text

        try:
            return json.dumps(payload, ensure_ascii=False)
        except Exception:
            return ""

    return ""


def _extract_error_message(payload: Any) -> str:
    if isinstance(payload, dict):
        errors = payload.get("errors")
        if isinstance(errors, list):
            parts = []
            for item in errors:
                if isinstance(item, dict):
                    for key in ("message", "detail", "error"):
                        val = item.get(key)
                        if val:
                            parts.append(str(val))
                            break
                elif item:
                    parts.append(str(item))
            if parts:
                return " | ".join(parts)

        for key in ("message", "error", "detail"):
            val = payload.get(key)
            if val:
                return str(val)

    return ""


def _is_retryable_status(status_code: int) -> bool:
    return status_code in {408, 425, 500, 502, 503, 504}


# ─────────────────────────────────────────────────────────
# MAIN CALL
# ─────────────────────────────────────────────────────────

def call_ai(
    prompt: str,
    max_tokens: int = 600,
    use_cache: bool = True,
    fallback: str = "",
    temperature: float = 0.2,
    model: str | None = None,
) -> str:
    """
    Throttled Cloudflare AI call with:
    - cache
    - retry/backoff
    - circuit breaker
    - safe fallback

    Returns raw text from the AI model or fallback on failure.
    """
    prompt = str(prompt or "").strip()
    if not prompt:
        return fallback

    chosen_model = (model or CLOUDFLARE_AI_MODEL).strip()
    prompt_hash = _hash_prompt(prompt, chosen_model, max_tokens, temperature)

    if use_cache:
        cached = _cache_get(prompt_hash)
        if cached:
            return cached

    if is_circuit_open():
        logger.warning("[ai_client] Circuit open — returning fallback")
        return fallback

    # Missing credentials is a config problem, not an AI outage.
    if not CLOUDFLARE_ACCOUNT_ID or not CLOUDFLARE_API_TOKEN:
        logger.warning("[ai_client] Missing Cloudflare credentials")
        return fallback

    url = (
        f"https://api.cloudflare.com/client/v4/accounts/"
        f"{CLOUDFLARE_ACCOUNT_ID}/ai/run/{chosen_model}"
    )
    headers = {
        "Authorization": f"Bearer {CLOUDFLARE_API_TOKEN}",
        "Content-Type": "application/json",
    }
    payload = {
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }

    last_error = ""

    for attempt in range(MAX_ATTEMPTS):
        if is_circuit_open():
            logger.warning("[ai_client] Circuit opened during retries — returning fallback")
            return fallback

        _throttle()

        try:
            response = requests.post(
                url,
                headers=headers,
                json=payload,
                timeout=REQUEST_TIMEOUT,
            )
        except requests.RequestException as exc:
            last_error = str(exc)
            logger.warning("[ai_client] Request failed (attempt %s/%s): %s", attempt + 1, MAX_ATTEMPTS, exc)
            backoff = _record_failure()
            if attempt < MAX_ATTEMPTS - 1:
                time.sleep(backoff)
                continue
            return fallback

        if response.status_code == 429:
            retry_after = _parse_retry_after(response.headers.get("Retry-After"))
            try:
                data = response.json()
                last_error = _extract_error_message(data) or response.text
            except Exception:
                last_error = response.text

            _record_failure(status_code=429, retry_after=retry_after)

            logger.warning(
                "[ai_client] 429 Too Many Requests (retry_after=%s): %s",
                retry_after,
                last_error[:300],
            )

            # Do not hammer on 429s. Return fallback and let the circuit breaker protect us.
            return fallback

        if not response.ok:
            try:
                data = response.json()
                last_error = _extract_error_message(data) or response.text
            except Exception:
                data = response.text
                last_error = str(data)

            logger.warning(
                "[ai_client] HTTP %s (attempt %s/%s): %s",
                response.status_code,
                attempt + 1,
                MAX_ATTEMPTS,
                last_error[:300],
            )

            if _is_retryable_status(response.status_code) and attempt < MAX_ATTEMPTS - 1:
                backoff = _record_failure(status_code=response.status_code)
                time.sleep(backoff)
                continue

            _record_failure(status_code=response.status_code)
            return fallback

        try:
            data = response.json()
        except Exception:
            data = response.text

        text = _extract_text(data)
        if not text:
            last_error = "Empty AI response"
            logger.warning("[ai_client] Empty AI response (attempt %s/%s)", attempt + 1, MAX_ATTEMPTS)

            backoff = _record_failure()
            if attempt < MAX_ATTEMPTS - 1:
                time.sleep(backoff)
                continue
            return fallback

        # Cache and success path
        raw_json = ""
        if not isinstance(data, str):
            try:
                raw_json = json.dumps(data, ensure_ascii=False)
            except Exception:
                raw_json = ""

        _cache_set(prompt_hash, text, raw_json)
        _record_success()
        return text

    logger.warning("[ai_client] AI call failed: %s", last_error[:300])
    return fallback
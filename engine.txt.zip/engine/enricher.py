# engine/enricher.py
"""
Lead enrichment engine.

Contact discovery priority:
1. Website discovery (if no website on lead)
2. Business website crawl (deep paths)
3. JSON-LD / schema.org structured data
4. Google search
5. Bing search
6. DuckDuckGo search

Email validation:
- Must plausibly match business name OR website domain
- Rejects generic/placeholder/junk emails
- Rejects emails from unrelated domains

New in this version:
- Website discovery engine
- Domain relevance scoring
- Deep crawl paths
- Enrichment status tracking
- Confidence scoring for email + phone
"""

import re
import time
import random
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin
from typing import Optional

# ─────────────────────────────────────────────────────────
# Headers pool
# ─────────────────────────────────────────────────────────

HEADERS_POOL = [
    {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": (
            "text/html,application/xhtml+xml,"
            "application/xml;q=0.9,*/*;q=0.8"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Cache-Control": "max-age=0",
    },
    {
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/605.1.15 (KHTML, like Gecko) "
            "Version/17.4 Safari/605.1.15"
        ),
        "Accept": (
            "text/html,application/xhtml+xml,"
            "application/xml;q=0.9,*/*;q=0.8"
        ),
        "Accept-Language": "en-GB,en;q=0.9",
        "Connection": "keep-alive",
    },
    {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) "
            "Gecko/20100101 Firefox/125.0"
        ),
        "Accept": (
            "text/html,application/xhtml+xml,"
            "application/xml;q=0.9,*/*;q=0.8"
        ),
        "Accept-Language": "en-US,en;q=0.7",
        "Connection": "keep-alive",
    },
]

# Junk email patterns
JUNK_EMAIL_PATTERNS = [
    "example", "test@", "noreply", "no-reply",
    "donotreply", "schema.org", "w3.org", "sentry",
    ".png", ".jpg", ".jpeg", ".gif", ".webp",
    "privacy@", "legal@", "support@b2b",
    "jane.doe", "john.doe", "jdoe", "jane@",
    "john@", "user@", "admin@example",
    "info@example", "hello@example",
    "test@test", "email@email",
    "yourname@", "youremail@",
    "name@domain", "sample@",
]

# Search engine / social domains to reject
SEARCH_ENGINE_DOMAINS = [
    "google.com", "bing.com", "yahoo.com",
    "duckduckgo.com", "baidu.com", "ask.com",
    "w3.org", "schema.org", "wikipedia.org",
    "facebook.com", "twitter.com", "instagram.com",
    "linkedin.com", "youtube.com",
]

# Extended list for website discovery rejection
SEARCH_ENGINE_DOMAINS_EXTENDED = [
    "google.com", "bing.com", "yahoo.com",
    "duckduckgo.com", "facebook.com",
    "instagram.com", "linkedin.com",
    "twitter.com", "x.com", "youtube.com",
    "wikipedia.org", "yelp.com",
    "yellowpages.com", "whitepages.com",
    "bbb.org", "manta.com", "hotfrog.com",
]


def get_headers() -> dict:
    return random.choice(HEADERS_POOL)


def human_pause(min_s: float = 1.0, max_s: float = 3.5):
    time.sleep(random.uniform(min_s, max_s))


# ─────────────────────────────────────────────────────────
# Website discovery engine
# ─────────────────────────────────────────────────────────

def normalize_domain(url: str) -> str:
    """
    Convert any URL to a clean root domain.

    Example:
    https://www.example.com/contact
    → example.com
    """
    if not url:
        return ""

    try:
        if not url.startswith("http"):
            url = "https://" + url

        parsed = urlparse(url)
        domain = parsed.netloc.lower()
        domain = domain.replace("www.", "")
        return domain.strip("/")

    except Exception:
        return ""


def is_bad_domain(domain: str) -> bool:
    """
    Reject search engines / social / directory domains.
    """
    if not domain:
        return True

    domain = domain.lower()

    for bad in SEARCH_ENGINE_DOMAINS_EXTENDED:
        if domain == bad or domain.endswith("." + bad):
            return True

    return False


def extract_domains_from_html(html: str) -> list:
    """
    Extract all domains from raw HTML.
    """
    if not html:
        return []

    pattern = (
        r'https?://([a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,})'
    )

    matches = re.findall(pattern, html)

    domains = []
    seen = set()

    for d in matches:
        d = d.lower().replace("www.", "")
        if d not in seen:
            seen.add(d)
            domains.append(d)

    return domains


def business_name_tokens(name: str) -> list:
    """
    Convert business name into meaningful tokens.

    Example:
    "Pillar Construction Inc"
    → ["pillar", "construction"]
    """
    if not name:
        return []

    ignore = {
        "inc", "llc", "ltd", "limited",
        "company", "corp", "corporation",
        "services", "group", "holdings",
        "solutions", "the", "and", "for",
    }

    words = re.findall(r"[a-zA-Z]{3,}", name.lower())

    return [w for w in words if w not in ignore]


def score_domain_relevance(
    domain: str,
    business_name: str,
) -> int:
    """
    Score how likely a domain belongs to the business.

    100 = exact match
    40  = token appears in domain
    20  = domain appears in token
    """
    if not domain:
        return 0

    score = 0
    domain = domain.lower()
    tokens = business_name_tokens(business_name)
    root = domain.split(".")[0]

    for token in tokens:
        if token == root:
            score += 100
        elif token in root:
            score += 40
        elif root in token:
            score += 20

    return score


def discover_business_website_google(
    business_name: str,
    location: str = "",
) -> str:
    """
    Find official website via Google search.
    """
    try:
        query = (
            f'"{business_name}" '
            f'{location} official website'
        ).strip()

        url = (
            "https://www.google.com/search?q="
            + query.replace(" ", "+")
        )

        human_pause(1.5, 3.0)

        resp = requests.get(
            url,
            headers=get_headers(),
            timeout=15,
        )

        if resp.status_code != 200:
            return ""

        domains = extract_domains_from_html(resp.text)

        scored = []

        for domain in domains:
            if is_bad_domain(domain):
                continue
            score = score_domain_relevance(
                domain, business_name
            )
            if score > 0:
                scored.append((domain, score))

        if not scored:
            return ""

        scored.sort(key=lambda x: x[1], reverse=True)

        best = scored[0][0]

        print(f"   🌐 Google website found: {best}")

        return "https://" + best

    except Exception:
        return ""


def discover_business_website_bing(
    business_name: str,
    location: str = "",
) -> str:
    """
    Find official website via Bing search.
    """
    try:
        query = (
            f'"{business_name}" '
            f'{location} official website'
        ).strip()

        url = (
            "https://www.bing.com/search?q="
            + query.replace(" ", "+")
        )

        human_pause(1.0, 2.5)

        resp = requests.get(
            url,
            headers=get_headers(),
            timeout=15,
        )

        if resp.status_code != 200:
            return ""

        domains = extract_domains_from_html(resp.text)

        scored = []

        for domain in domains:
            if is_bad_domain(domain):
                continue
            score = score_domain_relevance(
                domain, business_name
            )
            if score > 0:
                scored.append((domain, score))

        if not scored:
            return ""

        scored.sort(key=lambda x: x[1], reverse=True)

        best = scored[0][0]

        print(f"   🌐 Bing website found: {best}")

        return "https://" + best

    except Exception:
        return ""


def discover_business_website_duckduckgo(
    business_name: str,
    location: str = "",
) -> str:
    """
    Find official website via DuckDuckGo.
    """
    try:
        query = (
            f'"{business_name}" '
            f'{location} website'
        ).strip()

        url = (
            "https://html.duckduckgo.com/html/?q="
            + query.replace(" ", "+")
        )

        human_pause(1.0, 2.0)

        resp = requests.get(
            url,
            headers=get_headers(),
            timeout=15,
        )

        if resp.status_code != 200:
            return ""

        domains = extract_domains_from_html(resp.text)

        scored = []

        for domain in domains:
            if is_bad_domain(domain):
                continue
            score = score_domain_relevance(
                domain, business_name
            )
            if score > 0:
                scored.append((domain, score))

        if not scored:
            return ""

        scored.sort(key=lambda x: x[1], reverse=True)

        best = scored[0][0]

        print(f"   🌐 DDG website found: {best}")

        return "https://" + best

    except Exception:
        return ""


def discover_business_website(
    business_name: str,
    location: str = "",
) -> tuple:
    """
    Multi-source website discovery.

    Returns:
        (website_url, discovered_from_source)

    Example:
        ("https://pillarconstruction.com", "google")
    """
    website = discover_business_website_google(
        business_name, location
    )
    if website:
        return website, "google"

    website = discover_business_website_bing(
        business_name, location
    )
    if website:
        return website, "bing"

    website = discover_business_website_duckduckgo(
        business_name, location
    )
    if website:
        return website, "duckduckgo"

    return "", ""


# ─────────────────────────────────────────────────────────
# Email validation
# ─────────────────────────────────────────────────────────

def is_junk_email(email: str) -> bool:
    """Return True if this email should be rejected."""
    if not email or "@" not in email:
        return True

    email_lower = email.lower()

    for pattern in JUNK_EMAIL_PATTERNS:
        if pattern in email_lower:
            return True

    domain = email_lower.split("@")[-1]

    for bad_domain in SEARCH_ENGINE_DOMAINS:
        if domain == bad_domain or domain.endswith(
            "." + bad_domain
        ):
            return True

    return False


def email_matches_business(
    email: str,
    business_name: str,
    website: str = None,
) -> bool:
    """
    Return True if email plausibly belongs to this business.

    Checks:
    1. Email domain matches website domain exactly
    2. Email domain contains significant business name word
    3. Email local part contains significant business name word
    """
    if not email or "@" not in email:
        return False

    email_lower = email.lower()
    local_part, domain = email_lower.split("@", 1)

    # Check 1: Domain matches website domain
    if website:
        try:
            site_domain = urlparse(
                website
                if website.startswith("http")
                else "https://" + website
            ).netloc.lower()

            site_domain = site_domain.replace("www.", "")
            email_domain = domain.replace("www.", "")

            if site_domain and site_domain == email_domain:
                return True

            site_root = site_domain.split(".")[0]

            if site_root and len(site_root) > 3:
                if site_root in email_domain:
                    return True

        except Exception:
            pass

    # Check 2: Business name words in email
    if business_name:
        words = re.findall(r'[a-zA-Z]{4,}', business_name.lower())

        for word in words:
            if word in domain or word in local_part:
                return True

    return False


def score_email_confidence(
    email: str,
    business_name: str,
    website: str = None,
    source: str = "unknown",
) -> int:
    """
    Score confidence that email belongs to this business.

    100 = found on website with matching domain
    80  = found on website, partial domain match
    60  = found via search, domain matches business
    40  = found via search, name in email
    20  = found via search, no clear match
    0   = junk
    """
    if is_junk_email(email):
        return 0

    score = 20

    if source == "website":
        score += 40

    if email_matches_business(email, business_name, website):
        score += 40

    return min(score, 100)


# ─────────────────────────────────────────────────────────
# Extractors
# ─────────────────────────────────────────────────────────

def extract_emails_from_html(
    html: str,
    domain: str = None,
    business_name: str = None,
    source: str = "unknown",
    min_confidence: int = 20,
) -> list:
    """
    Extract valid emails from HTML.
    Returns sorted by confidence, highest first.
    """
    if not html:
        return []

    pattern = (
        r'\b([a-zA-Z0-9._%+\-]+@'
        r'[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})\b'
    )

    raw_emails = re.findall(pattern, html)

    seen = set()
    unique_emails = []

    for e in raw_emails:
        e_lower = e.lower()
        if e_lower not in seen:
            seen.add(e_lower)
            unique_emails.append(e_lower)

    website = f"https://{domain}" if domain else None

    scored = []

    for email in unique_emails:
        if is_junk_email(email):
            continue

        confidence = score_email_confidence(
            email,
            business_name or "",
            website,
            source,
        )

        if confidence >= min_confidence:
            scored.append((email, confidence))

    scored.sort(key=lambda x: x[1], reverse=True)

    return [email for email, _ in scored]


def extract_phones_from_html(html: str) -> list:
    """Extract phone numbers from HTML."""
    if not html:
        return []

    patterns = [
        r'\+1[\s\-\.]?\(?\d{3}\)?[\s\-\.]?\d{3}[\s\-\.]?\d{4}',
        r'\(?\d{3}\)?[\s\-\.]?\d{3}[\s\-\.]?\d{4}',
        r'\+234[\s\-]?\d{3}[\s\-]?\d{3}[\s\-]?\d{4}',
        r'0[789]\d{9}',
        r'\+\d{1,3}[\s\-]?\d{3,4}[\s\-]?\d{3,4}[\s\-]?\d{3,4}',
    ]

    found = []
    seen_digits = set()

    for pattern in patterns:
        matches = re.findall(pattern, html)

        for phone in matches:
            digits = re.sub(r'\D', '', phone)

            if (
                10 <= len(digits) <= 15
                and digits not in seen_digits
            ):
                seen_digits.add(digits)
                found.append(phone.strip())

    return found


def extract_phones_from_tel_links(
    soup: BeautifulSoup,
) -> list:
    """
    Extract phones from tel: href links.
    Most reliable phone source.
    """
    phones = []
    seen_digits = set()

    for a in soup.find_all("a", href=True):
        href = a.get("href", "")

        if href.startswith("tel:"):
            phone = href.replace("tel:", "").strip()
            digits = re.sub(r'\D', '', phone)

            if (
                9 <= len(digits) <= 15
                and digits not in seen_digits
            ):
                seen_digits.add(digits)
                phones.append(phone)

    return phones


def extract_emails_from_mailto_links(
    soup: BeautifulSoup,
) -> list:
    """
    Extract emails from mailto: href links.
    Most reliable email source.
    """
    emails = []
    seen = set()

    for a in soup.find_all("a", href=True):
        href = a.get("href", "")

        if href.startswith("mailto:"):
            email = (
                href
                .replace("mailto:", "")
                .split("?")[0]
                .strip()
                .lower()
            )

            if "@" in email and email not in seen:
                seen.add(email)
                emails.append(email)

    return emails


def extract_from_json_ld(soup: BeautifulSoup) -> dict:
    """
    Extract contact info from JSON-LD structured data.
    Many business websites embed this for SEO.
    """
    import json

    result = {
        "email": None,
        "phone": None,
        "address": None,
    }

    for script in soup.find_all(
        "script", type="application/ld+json"
    ):
        try:
            data = json.loads(script.string or "")

            items = data if isinstance(data, list) else [data]

            for item in items:
                if not isinstance(item, dict):
                    continue

                if not result["email"]:
                    email = item.get("email", "")
                    if email and "@" in email:
                        result["email"] = email.lower()

                if not result["phone"]:
                    phone = (
                        item.get("telephone", "")
                        or item.get("phone", "")
                    )
                    if phone:
                        result["phone"] = str(phone).strip()

                if not result["address"]:
                    addr = item.get("address", {})

                    if isinstance(addr, dict):
                        parts = [
                            addr.get("streetAddress", ""),
                            addr.get("addressLocality", ""),
                            addr.get("addressRegion", ""),
                            addr.get("postalCode", ""),
                        ]

                        address_str = ", ".join(
                            p for p in parts if p
                        )

                        if address_str:
                            result["address"] = address_str

        except Exception:
            continue

    return result


def extract_social_links(html: str) -> dict:
    """Extract social media links from HTML."""
    social = {
        "instagram": None,
        "facebook": None,
        "twitter": None,
        "linkedin": None,
        "whatsapp": None,
    }

    patterns = {
        "instagram": (
            r'https?://(?:www\.)?instagram\.com/'
            r'[A-Za-z0-9_.]+/?'
        ),
        "facebook": (
            r'https?://(?:www\.)?facebook\.com/'
            r'[A-Za-z0-9_.]+/?'
        ),
        "twitter": (
            r'https?://(?:www\.)?(?:twitter|x)\.com/'
            r'[A-Za-z0-9_]+/?'
        ),
        "linkedin": (
            r'https?://(?:www\.)?linkedin\.com/'
            r'(?:company|in)/[A-Za-z0-9_\-]+/?'
        ),
        "whatsapp": (
            r'https?://(?:wa\.me|api\.whatsapp\.com)/'
            r'[^\s"\'<>]+'
        ),
    }

    for platform, pattern in patterns.items():
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            social[platform] = match.group(0)

    return social


# ─────────────────────────────────────────────────────────
# Website health
# ─────────────────────────────────────────────────────────

def check_website_health(
    url: str,
    timeout: int = 10,
) -> dict:
    result = {
        "active": False,
        "status_code": None,
        "redirect_url": None,
        "has_ssl": False,
        "load_time": None,
        "error": None,
    }

    if not url:
        return result

    if not url.startswith("http"):
        url = "https://" + url

    result["has_ssl"] = url.startswith("https")

    try:
        start = time.time()

        resp = requests.get(
            url,
            headers=get_headers(),
            timeout=timeout,
            allow_redirects=True,
        )

        elapsed = time.time() - start

        result["status_code"] = resp.status_code
        result["active"] = resp.status_code < 400
        result["load_time"] = round(elapsed, 2)

        if resp.url != url:
            result["redirect_url"] = resp.url

    except requests.exceptions.SSLError:
        try:
            http_url = url.replace("https://", "http://")

            resp = requests.get(
                http_url,
                headers=get_headers(),
                timeout=timeout,
                allow_redirects=True,
            )

            result["status_code"] = resp.status_code
            result["active"] = resp.status_code < 400

        except Exception as e:
            result["error"] = str(e)

    except Exception as e:
        result["error"] = str(e)

    return result


# ─────────────────────────────────────────────────────────
# Website crawler
# ─────────────────────────────────────────────────────────

def crawl_page(url: str, timeout: int = 10):
    """
    Fetch a single page.
    Returns (html, soup) or (None, None).
    """
    try:
        resp = requests.get(
            url,
            headers=get_headers(),
            timeout=timeout,
            allow_redirects=True,
        )

        if resp.status_code < 400:
            soup = BeautifulSoup(resp.text, "lxml")
            return resp.text, soup

    except Exception:
        pass

    return None, None


def get_deep_contact_paths() -> list:
    """
    All contact page paths to crawl.
    """
    return [
        "",
        "/contact",
        "/contact-us",
        "/contactus",
        "/about",
        "/about-us",
        "/team",
        "/our-team",
        "/staff",
        "/management",
        "/leadership",
        "/support",
        "/help",
        "/locations",
        "/location",
        "/reach-us",
        "/get-in-touch",
        "/info",
    ]


def find_email_on_website(
    website_url: str,
    business_name: str = "",
) -> Optional[str]:
    """
    Deep crawl website for email.

    Priority:
    1. mailto: links
    2. JSON-LD structured data
    3. Text extraction with domain matching

    Crawls:
    homepage + all deep contact paths
    """
    if not website_url:
        return None

    if not website_url.startswith("http"):
        website_url = "https://" + website_url

    try:
        parsed = urlparse(website_url)
        base = f"{parsed.scheme}://{parsed.netloc}"
        domain = parsed.netloc.replace("www.", "")

        paths = get_deep_contact_paths()

        pages = [
            urljoin(base, path)
            for path in paths
        ]

        # Homepage always first
        if website_url not in pages:
            pages.insert(0, website_url)

        for page_url in pages:
            try:
                human_pause(0.3, 0.8)

                html, soup = crawl_page(page_url)

                if not html or not soup:
                    continue

                # Priority 1: mailto links
                mailto_emails = (
                    extract_emails_from_mailto_links(soup)
                )

                for email in mailto_emails:
                    if not is_junk_email(email):
                        print(
                            f"   📧 mailto found: {email}"
                        )
                        return email

                # Priority 2: JSON-LD
                structured = extract_from_json_ld(soup)

                if structured.get("email"):
                    email = structured["email"]
                    if not is_junk_email(email):
                        print(
                            f"   📧 JSON-LD found: {email}"
                        )
                        return email

                # Priority 3: Text extraction
                emails = extract_emails_from_html(
                    html,
                    domain=domain,
                    business_name=business_name,
                    source="website",
                    min_confidence=40,
                )

                if emails:
                    print(
                        f"   📧 Website text found: "
                        f"{emails[0]}"
                    )
                    return emails[0]

            except Exception:
                continue

    except Exception:
        pass

    return None


def find_phone_on_website(
    website_url: str,
) -> Optional[str]:
    """
    Crawl website for phone number.

    Priority:
    1. tel: links
    2. JSON-LD structured data
    3. Text extraction
    """
    if not website_url:
        return None

    if not website_url.startswith("http"):
        website_url = "https://" + website_url

    try:
        parsed = urlparse(website_url)
        base = f"{parsed.scheme}://{parsed.netloc}"

        pages = [
            website_url,
            urljoin(base, "/contact"),
            urljoin(base, "/contact-us"),
        ]

        for page_url in pages:
            try:
                human_pause(0.2, 0.6)

                html, soup = crawl_page(page_url)

                if not html or not soup:
                    continue

                # Priority 1: tel: links
                tel_phones = extract_phones_from_tel_links(soup)

                if tel_phones:
                    print(
                        f"   📞 tel: link found: {tel_phones[0]}"
                    )
                    return tel_phones[0]

                # Priority 2: JSON-LD
                structured = extract_from_json_ld(soup)

                if structured.get("phone"):
                    print(
                        f"   📞 JSON-LD found: "
                        f"{structured['phone']}"
                    )
                    return structured["phone"]

                # Priority 3: Text extraction
                phones = extract_phones_from_html(html)

                if phones:
                    print(f"   📞 Text found: {phones[0]}")
                    return phones[0]

            except Exception:
                continue

    except Exception:
        pass

    return None


# ─────────────────────────────────────────────────────────
# Search engine finders
# ─────────────────────────────────────────────────────────

def search_email_google(
    business_name: str,
    location: str = "",
    website: str = None,
) -> Optional[str]:
    if not business_name:
        return None

    try:
        query = (
            f'"{business_name}" {location} email contact'
        ).strip()

        url = (
            "https://www.google.com/search?q="
            + query.replace(" ", "+")
        )

        human_pause(1.5, 3.0)

        resp = requests.get(
            url,
            headers=get_headers(),
            timeout=15,
        )

        if resp.status_code == 200:
            emails = extract_emails_from_html(
                resp.text,
                business_name=business_name,
                source="search",
                min_confidence=40,
            )

            for email in emails:
                if email_matches_business(
                    email, business_name, website
                ):
                    print(f"   📧 Google found: {email}")
                    return email

    except Exception:
        pass

    return None


def search_email_bing(
    business_name: str,
    location: str = "",
    website: str = None,
) -> Optional[str]:
    if not business_name:
        return None

    try:
        query = (
            f'"{business_name}" {location} '
            f'email OR contact'
        ).strip()

        url = (
            "https://www.bing.com/search?q="
            + query.replace(" ", "+")
        )

        human_pause(1.0, 2.5)

        resp = requests.get(
            url,
            headers=get_headers(),
            timeout=15,
        )

        if resp.status_code == 200:
            emails = extract_emails_from_html(
                resp.text,
                business_name=business_name,
                source="search",
                min_confidence=40,
            )

            for email in emails:
                if email_matches_business(
                    email, business_name, website
                ):
                    print(f"   📧 Bing found: {email}")
                    return email

    except Exception:
        pass

    return None


def search_email_duckduckgo(
    business_name: str,
    location: str = "",
    website: str = None,
) -> Optional[str]:
    if not business_name:
        return None

    try:
        query = (
            f'"{business_name}" {location} email'
        ).strip()

        url = (
            "https://html.duckduckgo.com/html/?q="
            + query.replace(" ", "+")
        )

        human_pause(1.0, 2.5)

        resp = requests.get(
            url,
            headers=get_headers(),
            timeout=15,
        )

        if resp.status_code == 200:
            emails = extract_emails_from_html(
                resp.text,
                business_name=business_name,
                source="search",
                min_confidence=40,
            )

            for email in emails:
                if email_matches_business(
                    email, business_name, website
                ):
                    print(f"   📧 DDG found: {email}")
                    return email

    except Exception:
        pass

    return None


def search_phone_google(
    business_name: str,
    location: str = "",
) -> Optional[str]:
    """Search Google for business phone number."""
    if not business_name:
        return None

    try:
        query = (
            f'"{business_name}" {location} phone number'
        ).strip()

        url = (
            "https://www.google.com/search?q="
            + query.replace(" ", "+")
        )

        human_pause(1.5, 3.0)

        resp = requests.get(
            url,
            headers=get_headers(),
            timeout=15,
        )

        if resp.status_code == 200:
            phones = extract_phones_from_html(resp.text)

            if phones:
                print(
                    f"   📞 Google phone found: {phones[0]}"
                )
                return phones[0]

    except Exception:
        pass

    return None


# ─────────────────────────────────────────────────────────
# Multi-source finders
# ─────────────────────────────────────────────────────────

def find_email_multi_source(
    business_name: str,
    website: str = None,
    location: str = "",
    progress_callback=None,
) -> Optional[str]:
    """
    Find email in priority order:
    1. Website crawl
    2. Google
    3. Bing
    4. DuckDuckGo
    """
    if website:
        if progress_callback:
            progress_callback("Checking website...")
        email = find_email_on_website(website, business_name)
        if email:
            return email

    if progress_callback:
        progress_callback("Searching Google...")
    email = search_email_google(
        business_name, location, website
    )
    if email:
        return email

    if progress_callback:
        progress_callback("Searching Bing...")
    email = search_email_bing(
        business_name, location, website
    )
    if email:
        return email

    if progress_callback:
        progress_callback("Searching DuckDuckGo...")
    email = search_email_duckduckgo(
        business_name, location, website
    )
    if email:
        return email

    return None


def find_phone_multi_source(
    business_name: str,
    website: str = None,
    location: str = "",
) -> Optional[str]:
    """
    Find phone in priority order:
    1. Website crawl
    2. Google search
    """
    if website:
        phone = find_phone_on_website(website)
        if phone:
            return phone

    phone = search_phone_google(business_name, location)
    if phone:
        return phone

    return None


# ─────────────────────────────────────────────────────────
# Full lead enrichment
# ─────────────────────────────────────────────────────────

def enrich_lead(
    lead: dict,
    find_email: bool = True,
    find_phone: bool = True,
) -> dict:
    """
    Full lead enrichment pipeline.

    Step 1: Website discovery (if no website)
    Step 2: Website health check
    Step 3: Social links extraction
    Step 4: Phone discovery
    Step 5: Email discovery
    Step 6: Enrichment status update

    Tracks:
    - enrichment_status
    - last_enriched_at
    - email_confidence
    - phone_confidence
    - website_discovered_from
    - emails_found_count
    - phones_found_count
    """
    if not lead:
        return lead

    business_name = lead.get("business_name", "")
    website = lead.get("website") or ""
    city = lead.get("city") or lead.get("location") or ""
    country = lead.get("country") or ""
    location = f"{city}, {country}".strip(", ")

    enrichment_notes = []

    # Step 1: Website discovery
    if not website or str(website).strip() in ("", "None"):

        print(
            f"   🔍 No website — searching for: "
            f"{business_name}"
        )

        website, discovered_from = discover_business_website(
            business_name,
            location,
        )

        if website:
            lead["website"] = website
            lead["website_discovered_from"] = discovered_from
            enrichment_notes.append(
                f"Website found via {discovered_from}"
            )
            print(
                f"   ✅ Website discovered: {website}"
            )
        else:
            lead["website_discovered_from"] = "not_found"
            enrichment_notes.append("Website not found")

    # Normalize website
    if website and not website.startswith("http"):
        website = "https://" + website
        lead["website"] = website

    # Step 2: Website health + social + contacts
    if website:
        health = check_website_health(website)
        lead["website_active"] = 1 if health.get("active") else 0
        lead["has_website"] = 1

        if health.get("active"):
            try:
                html, soup = crawl_page(website)

                if html and soup:

                    # Social links
                    social = extract_social_links(html)
                    lead["has_instagram"] = (
                        1 if social.get("instagram") else 0
                    )
                    lead["has_facebook"] = (
                        1 if social.get("facebook") else 0
                    )
                    lead["has_twitter"] = (
                        1 if social.get("twitter") else 0
                    )

                    # Step 3: Phone discovery
                    if find_phone and not lead.get("phone"):

                        tel_phones = (
                            extract_phones_from_tel_links(soup)
                        )

                        if tel_phones:
                            lead["phone"] = tel_phones[0]
                            lead["phone_confidence"] = 90
                            lead["phones_found_count"] = len(
                                tel_phones
                            )
                            enrichment_notes.append(
                                "Phone via tel: link"
                            )
                            print(
                                f"   📞 tel: {tel_phones[0]}"
                            )
                        else:
                            structured = extract_from_json_ld(soup)

                            if structured.get("phone"):
                                lead["phone"] = structured["phone"]
                                lead["phone_confidence"] = 85
                                enrichment_notes.append(
                                    "Phone via JSON-LD"
                                )
                                print(
                                    f"   📞 JSON-LD: "
                                    f"{structured['phone']}"
                                )
                            else:
                                phones = extract_phones_from_html(
                                    html
                                )
                                if phones:
                                    lead["phone"] = phones[0]
                                    lead["phone_confidence"] = 60
                                    lead["phones_found_count"] = (
                                        len(phones)
                                    )
                                    enrichment_notes.append(
                                        "Phone via text"
                                    )
                                    print(
                                        f"   📞 Text: {phones[0]}"
                                    )

                    # Step 4: Email discovery from website
                    if find_email and not lead.get("email"):

                        mailto_emails = (
                            extract_emails_from_mailto_links(soup)
                        )

                        for email in mailto_emails:
                            if not is_junk_email(email):
                                lead["email"] = email
                                lead["email_confidence"] = 95
                                lead["emails_found_count"] = len(
                                    mailto_emails
                                )
                                enrichment_notes.append(
                                    "Email via mailto"
                                )
                                print(f"   📧 mailto: {email}")
                                break

                        if not lead.get("email"):
                            structured = extract_from_json_ld(soup)

                            if structured.get("email"):
                                email = structured["email"]
                                if not is_junk_email(email):
                                    lead["email"] = email
                                    lead["email_confidence"] = 90
                                    enrichment_notes.append(
                                        "Email via JSON-LD"
                                    )
                                    print(
                                        f"   📧 JSON-LD: {email}"
                                    )

                        if not lead.get("email"):
                            email = find_email_on_website(
                                website,
                                business_name,
                            )
                            if email:
                                lead["email"] = email
                                lead["email_confidence"] = 75
                                enrichment_notes.append(
                                    "Email via deep crawl"
                                )

            except Exception as e:
                enrichment_notes.append(
                    f"Crawl error: {str(e)[:50]}"
                )

        else:
            enrichment_notes.append(
                f"Website inactive: "
                f"{health.get('status_code', 'unknown')}"
            )

    else:
        lead["website_active"] = 0
        lead["has_website"] = 0

    # Step 5: Phone from web search if still missing
    if find_phone and not lead.get("phone"):
        phone = search_phone_google(business_name, location)
        if phone:
            lead["phone"] = phone
            lead["phone_confidence"] = 50
            enrichment_notes.append("Phone via Google search")

    # Step 6: Email from web search if still missing
    if find_email and not lead.get("email"):
        email = find_email_multi_source(
            business_name=business_name,
            website=website or None,
            location=location,
        )
        if email:
            lead["email"] = email
            lead["email_confidence"] = (
                lead.get("email_confidence") or 50
            )
            enrichment_notes.append("Email via web search")

    # Step 7: Mark enrichment complete
    from datetime import datetime

    lead["enrichment_status"] = "done"
    lead["last_enriched_at"] = datetime.utcnow().isoformat()

    if enrichment_notes:
        lead["enrichment_notes"] = (
            " | ".join(enrichment_notes)
        )

    return lead


# ─────────────────────────────────────────────────────────
# Re-enrichment engine
# ─────────────────────────────────────────────────────────

def reenrich_leads_missing_emails(
    limit: int = 50,
    progress_callback=None,
) -> dict:
    """
    Re-enrich all leads in DB that are missing emails.
    Does NOT re-scrape. Just improves existing leads.

    Returns:
    {
        "processed": int,
        "emails_found": int,
        "websites_found": int,
        "phones_found": int,
    }
    """
    from database import (
        get_leads_missing_emails,
        update_lead_email,
        get_connection,
    )

    leads = get_leads_missing_emails(limit=limit)

    results = {
        "processed": 0,
        "emails_found": 0,
        "websites_found": 0,
        "phones_found": 0,
    }

    total = len(leads)

    print(
        f"\n🔄 Re-enriching {total} leads missing emails...\n"
    )

    for i, lead in enumerate(leads):

        name = lead.get("business_name", "...")

        if progress_callback:
            progress_callback(i, total, name)

        print(
            f"[{i + 1}/{total}] {name}"
        )

        had_website = bool(lead.get("website"))

        enriched = enrich_lead(
            lead,
            find_email=True,
            find_phone=True,
        )

        results["processed"] += 1

        if enriched.get("email"):
            results["emails_found"] += 1

            # Update DB
            update_lead_email(
                enriched["id"],
                enriched["email"],
            )

        if not had_website and enriched.get("website"):
            results["websites_found"] += 1

        if enriched.get("phone"):
            results["phones_found"] += 1

        # Update enrichment metadata in DB
        try:
            conn = get_connection()
            conn.execute(
                """
                UPDATE leads
                SET
                    website = COALESCE(
                        NULLIF(website, ''), ?
                    ),
                    phone = COALESCE(
                        NULLIF(phone, ''), ?
                    ),
                    enrichment_status = ?,
                    last_enriched_at = ?,
                    email_confidence = ?,
                    phone_confidence = ?,
                    website_discovered_from = COALESCE(
                        NULLIF(
                            website_discovered_from, ''
                        ), ?
                    ),
                    enrichment_notes = ?,
                    updated_at = datetime('now')
                WHERE id = ?
                """,
                (
                    enriched.get("website") or "",
                    enriched.get("phone") or "",
                    enriched.get(
                        "enrichment_status", "done"
                    ),
                    enriched.get("last_enriched_at"),
                    enriched.get("email_confidence", 0),
                    enriched.get("phone_confidence", 0),
                    enriched.get(
                        "website_discovered_from", ""
                    ),
                    enriched.get("enrichment_notes", ""),
                    enriched["id"],
                )
            )
            conn.commit()
            conn.close()

        except Exception as e:
            print(f"   ⚠️ DB update error: {e}")

        human_pause(0.5, 1.5)

    print(
        f"\n✅ Re-enrichment complete:\n"
        f"   Processed:      {results['processed']}\n"
        f"   Emails found:   {results['emails_found']}\n"
        f"   Websites found: {results['websites_found']}\n"
        f"   Phones found:   {results['phones_found']}\n"
    )

    return results


# ─────────────────────────────────────────────────────────
# Contact completeness helper
# ─────────────────────────────────────────────────────────

def get_contact_completeness(lead: dict) -> int:
    """
    Return contact completeness percentage.
    Used in lead scoring.
    """
    score = 0

    if lead.get("phone"):
        score += 40

    if lead.get("email"):
        score += 35

    if lead.get("website"):
        score += 15

    if lead.get("address"):
        score += 10

    return min(score, 100)
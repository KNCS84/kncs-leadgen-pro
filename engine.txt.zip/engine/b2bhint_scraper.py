# engine/b2bhint_scraper.py
"""
B2BHint scraper.
Global jurisdiction support.
Page tracking (continues from last scraped page).
Debug mode prints raw HTML to identify card structure.
"""

import re
import time
import random
import requests
from bs4 import BeautifulSoup
from database import get_connection

BASE_URL = "https://b2bhint.com"

# ─────────────────────────────────────────────────────────
# Jurisdiction maps
# ─────────────────────────────────────────────────────────

US_CITY_TO_STATE = {
    "chicago":          "Illinois",
    "houston":          "Texas",
    "new york":         "New York",
    "los angeles":      "California",
    "dallas":           "Texas",
    "atlanta":          "Georgia",
    "miami":            "Florida",
    "phoenix":          "Arizona",
    "seattle":          "Washington",
    "denver":           "Colorado",
    "boston":           "Massachusetts",
    "detroit":          "Michigan",
    "philadelphia":     "Pennsylvania",
    "san francisco":    "California",
    "san diego":        "California",
    "las vegas":        "Nevada",
    "portland":         "Oregon",
    "nashville":        "Tennessee",
    "charlotte":        "North Carolina",
    "austin":           "Texas",
    "san antonio":      "Texas",
    "jacksonville":     "Florida",
    "fort worth":       "Texas",
    "columbus":         "Ohio",
    "indianapolis":     "Indiana",
    "memphis":          "Tennessee",
    "louisville":       "Kentucky",
    "baltimore":        "Maryland",
    "milwaukee":        "Wisconsin",
    "albuquerque":      "New Mexico",
    "tucson":           "Arizona",
    "fresno":           "California",
    "sacramento":       "California",
    "mesa":             "Arizona",
    "kansas city":      "Missouri",
    "omaha":            "Nebraska",
    "raleigh":          "North Carolina",
    "virginia beach":   "Virginia",
    "colorado springs": "Colorado",
    "minneapolis":      "Minnesota",
    "tampa":            "Florida",
    "new orleans":      "Louisiana",
    "cleveland":        "Ohio",
    "pittsburgh":       "Pennsylvania",
    "cincinnati":       "Ohio",
    "orlando":          "Florida",
}

UK_CITY_TO_JURISDICTION = {
    "london":       "England",
    "manchester":   "England",
    "birmingham":   "England",
    "leeds":        "England",
    "liverpool":    "England",
    "sheffield":    "England",
    "bristol":      "England",
    "nottingham":   "England",
    "leicester":    "England",
    "coventry":     "England",
    "edinburgh":    "Scotland",
    "glasgow":      "Scotland",
    "cardiff":      "Wales",
    "belfast":      "Northern Ireland",
}

CA_CITY_TO_PROVINCE = {
    "toronto":      "Ontario",
    "ottawa":       "Ontario",
    "hamilton":     "Ontario",
    "mississauga":  "Ontario",
    "vancouver":    "British Columbia",
    "surrey":       "British Columbia",
    "calgary":      "Alberta",
    "edmonton":     "Alberta",
    "montreal":     "Quebec",
    "quebec city":  "Quebec",
    "halifax":      "Nova Scotia",
    "winnipeg":     "Manitoba",
}

AU_CITY_TO_STATE = {
    "sydney":    "New South Wales",
    "melbourne": "Victoria",
    "brisbane":  "Queensland",
    "perth":     "Western Australia",
    "adelaide":  "South Australia",
    "canberra":  "Australian Capital Territory",
    "darwin":    "Northern Territory",
    "hobart":    "Tasmania",
}

HEADERS_POOL = [
    {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": (
            "text/html,application/xhtml+xml,application/xml;"
            "q=0.9,image/avif,image/webp,*/*;q=0.8"
        ),
        "Accept-Language":           "en-US,en;q=0.9",
        "Accept-Encoding":           "gzip, deflate, br",
        "Connection":                "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Cache-Control":             "max-age=0",
    },
    {
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/605.1.15 (KHTML, like Gecko) "
            "Version/17.4 Safari/605.1.15"
        ),
        "Accept": (
            "text/html,application/xhtml+xml,application/xml;"
            "q=0.9,*/*;q=0.8"
        ),
        "Accept-Language": "en-GB,en;q=0.9",
        "Connection":      "keep-alive",
    },
]


def get_headers() -> dict:
    return random.choice(HEADERS_POOL)


def human_pause(min_s: float = 2.0, max_s: float = 5.0):
    time.sleep(random.uniform(min_s, max_s))


def clean_text(text: str) -> str:
    if not text:
        return ""
    return re.sub(r"\s+", " ", text).strip()


def is_blocked(resp) -> bool:
    if resp.status_code in [403, 429, 503]:
        return True
    indicators = [
        "just a moment", "cloudflare", "access denied",
        "captcha", "security check", "enable javascript",
        "ray id",
    ]
    return any(i in resp.text.lower() for i in indicators)


# ─────────────────────────────────────────────────────────
# Global jurisdiction resolver
# ─────────────────────────────────────────────────────────

def detect_jurisdiction(location: str) -> str:
    """
    Resolve any city/country string to a B2BHint jurisdiction.
    No script changes needed — just type any location in the UI.
    """
    if not location:
        return None

    loc_lower = location.lower().strip()

    # United States
    if "united states" in loc_lower or ", us" in loc_lower:
        for city, state in US_CITY_TO_STATE.items():
            if city in loc_lower:
                return state
        return "United+States"

    # United Kingdom
    if any(
        x in loc_lower
        for x in ["united kingdom", " uk", "england", "scotland"]
    ):
        for city, jur in UK_CITY_TO_JURISDICTION.items():
            if city in loc_lower:
                return jur
        return "England"

    # Canada
    if "canada" in loc_lower:
        for city, prov in CA_CITY_TO_PROVINCE.items():
            if city in loc_lower:
                return prov
        return "Ontario"

    # Australia
    if "australia" in loc_lower:
        for city, state in AU_CITY_TO_STATE.items():
            if city in loc_lower:
                return state
        return "New+South+Wales"

    # African / Middle East countries
    country_direct = {
        "nigeria":      "Nigeria",
        "ghana":        "Ghana",
        "south africa": "South+Africa",
        "kenya":        "Kenya",
        "india":        "India",
        "germany":      "Germany",
        "france":       "France",
        "dubai":        "Dubai",
        "uae":          "Dubai",
        "united arab":  "Dubai",
        "singapore":    "Singapore",
        "malaysia":     "Malaysia",
        "pakistan":     "Pakistan",
        "bangladesh":   "Bangladesh",
    }
    for keyword, jurisdiction in country_direct.items():
        if keyword in loc_lower:
            return jurisdiction

    # Generic fallback — extract last part of location string
    # e.g. "Nairobi, Kenya" → "Kenya"
    parts = [p.strip() for p in location.split(",")]
    if len(parts) >= 2:
        country_part = parts[-1].strip()
        if country_part and len(country_part) > 2:
            return country_part.replace(" ", "+")

    return None


# ─────────────────────────────────────────────────────────
# URL builder
# ─────────────────────────────────────────────────────────

def build_search_urls(
    keyword: str,
    location: str = "",
    max_pages: int = 5,
    start_page: int = 1,
) -> list:
    """
    Build B2BHint search URLs.
    start_page lets us continue from where we left off.
    Hard cap: 5 pages per run.
    """
    max_pages       = min(max_pages, 5)
    keyword_encoded = keyword.strip().replace(" ", "+")
    jurisdiction    = detect_jurisdiction(location)
    urls            = []

    end_page = start_page + max_pages - 1

    for page in range(start_page, end_page + 1):
        if jurisdiction:
            url = (
                f"{BASE_URL}/en/search"
                f"?q={keyword_encoded}"
                f"&type=companies"
                f"&jurisdiction={jurisdiction}"
                f"&page={page}"
            )
        else:
            url = (
                f"{BASE_URL}/en/search"
                f"?q={keyword_encoded}"
                f"&type=companies"
                f"&page={page}"
            )
        urls.append(url)

    return urls


def build_nigeria_urls(
    keyword: str, location: str, max_pages: int = 5
) -> list:
    return build_search_urls(keyword, location, max_pages)


# ─────────────────────────────────────────────────────────
# Page tracking
# ─────────────────────────────────────────────────────────

def _ensure_scrape_log(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scrape_page_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            keyword     TEXT,
            location    TEXT,
            page_num    INTEGER,
            leads_found INTEGER DEFAULT 0,
            scraped_at  TEXT DEFAULT (datetime('now')),
            UNIQUE(keyword, location, page_num)
        )
    """)
    conn.commit()


def get_last_scraped_page(keyword: str, location: str) -> int:
    """Return highest page already scraped. 0 if never."""
    conn = get_connection()
    try:
        _ensure_scrape_log(conn)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT MAX(page_num) FROM scrape_page_log
            WHERE keyword = ? AND location = ?
        """, (keyword.lower().strip(), location.lower().strip()))
        row = cursor.fetchone()
        return row[0] or 0
    finally:
        conn.close()


def log_scraped_page(
    keyword: str,
    location: str,
    page_num: int,
    leads_found: int,
):
    conn = get_connection()
    try:
        _ensure_scrape_log(conn)
        conn.execute("""
            INSERT OR REPLACE INTO scrape_page_log
            (keyword, location, page_num, leads_found)
            VALUES (?, ?, ?, ?)
        """, (
            keyword.lower().strip(),
            location.lower().strip(),
            page_num,
            leads_found,
        ))
        conn.commit()
    finally:
        conn.close()


def reset_scrape_log(keyword: str, location: str):
    conn = get_connection()
    try:
        _ensure_scrape_log(conn)
        conn.execute("""
            DELETE FROM scrape_page_log
            WHERE keyword = ? AND location = ?
        """, (keyword.lower().strip(), location.lower().strip()))
        conn.commit()
    finally:
        conn.close()


# ─────────────────────────────────────────────────────────
# HTML debug printer
# ─────────────────────────────────────────────────────────

def print_html_debug(resp_text: str, soup: BeautifulSoup):
    """
    Print targeted debug info so we can identify
    exactly what B2BHint is returning.
    """
    print("\n" + "=" * 60)
    print("B2BHINT HTML DEBUG")
    print("=" * 60)
    print(f"Response size: {len(resp_text):,} chars")

    title = soup.find("title")
    print(f"Page title: {title.get_text() if title else 'None'}")

    # Count key elements
    for tag in ["div", "a", "li", "article", "ul"]:
        print(f"  <{tag}>: {len(soup.find_all(tag))}")

    # All unique CSS classes
    all_classes = set()
    for el in soup.find_all(True):
        for cls in (el.get("class") or []):
            all_classes.add(cls)

    interesting = [
        c for c in sorted(all_classes)
        if any(
            kw in c.lower()
            for kw in [
                "card", "item", "result", "company",
                "entity", "list", "row", "search",
                "business", "org", "entry", "hit",
            ]
        )
    ]
    print(f"\nInteresting CSS classes ({len(interesting)}):")
    for c in interesting[:20]:
        print(f"  .{c}")

    # Links matching company pattern
    slug_links = soup.find_all(
        "a",
        href=re.compile(r'/en/[a-z]{2}/[a-z0-9\-]+', re.I)
    )
    print(f"\nSlug-style links (/en/XX/slug): {len(slug_links)}")
    for a in slug_links[:5]:
        print(
            f"  {a.get('href','')} → "
            f"{a.get_text(strip=True)[:50]}"
        )

    # All meaty links (5-120 chars of text)
    meaty = [
        a for a in soup.find_all("a", href=True)
        if 5 < len(a.get_text(strip=True)) < 120
    ]
    print(f"\nMeaty links (text 5-120 chars): {len(meaty)}")
    for a in meaty[:8]:
        print(
            f"  [{a.get_text(strip=True)[:60]}] "
            f"→ {a.get('href','')[:70]}"
        )

    # Raw HTML body first 3000 chars
    body = soup.find("body")
    print(f"\n--- First 3000 chars of <body> ---")
    if body:
        print(str(body)[:3000])
    else:
        print(resp_text[:3000])
    print("--- End ---")
    print("=" * 60 + "\n")


# ─────────────────────────────────────────────────────────
# Card finder
# ─────────────────────────────────────────────────────────

_NAV_NAMES = {
    "pricing", "login", "sign up", "contact us",
    "data & coverage", "export data", "search",
    "home", "about", "features", "blog", "help",
    "terms", "privacy", "sign in", "register",
    "company", "companies", "results", "back",
    "next", "previous", "more", "less", "all",
    "data", "coverage", "export", "contact",
}


def is_nav_element(text: str) -> bool:
    return text.lower().strip() in _NAV_NAMES


def find_listing_cards(soup: BeautifulSoup) -> list:
    """
    8 strategies to find business listing cards.
    Strategy 1 (slug links) confirmed working for Illinois.
    """

    # Strategy 1: /en/XX/slug links — CONFIRMED WORKING
    slug_links = soup.find_all(
        "a",
        href=re.compile(
            r'/en/[a-z]{2}/[a-z0-9][a-z0-9\-]+',
            re.I
        )
    )
    if slug_links and len(slug_links) >= 2:
        print(f"   S1: {len(slug_links)} slug links")
        return slug_links

    # Strategy 2: Known CSS card class patterns
    for pattern in [
        re.compile(r'search.?result', re.I),
        re.compile(r'company.?card',  re.I),
        re.compile(r'entity.?card',   re.I),
        re.compile(r'result.?card',   re.I),
        re.compile(r'listing.?item',  re.I),
        re.compile(r'org.?card',      re.I),
        re.compile(r'company.?item',  re.I),
        re.compile(r'result.?item',   re.I),
        re.compile(r'hit',            re.I),
    ]:
        cards = soup.find_all(True, class_=pattern)
        if cards and len(cards) >= 2:
            print(f"   S2 ({pattern.pattern}): {len(cards)}")
            return cards

    # Strategy 3: /company/ links
    company_links = soup.find_all(
        "a", href=re.compile(r'/company/', re.I)
    )
    if company_links and len(company_links) >= 2:
        print(f"   S3: {len(company_links)} /company/ links")
        return company_links

    # Strategy 4: <li> with headings
    li_cards = [
        li for li in soup.find_all("li")
        if li.find(["strong", "b", "h2", "h3", "h4"])
        and 5 < len(li.get_text(strip=True)) < 500
    ]
    if li_cards and len(li_cards) >= 2:
        print(f"   S4: {len(li_cards)} li cards")
        return li_cards

    # Strategy 5: divs with address text
    div_cards  = []
    seen_texts = set()
    for div in soup.find_all("div"):
        text = div.get_text(" ", strip=True)
        if (
            div.find_all("a", href=True)
            and re.search(
                r'\b(st|ave|blvd|rd|dr|ln|way|ct)\b',
                text, re.I
            )
            and 20 < len(text) < 600
        ):
            snippet = text[:60]
            if snippet not in seen_texts:
                seen_texts.add(snippet)
                div_cards.append(div)
    if div_cards and len(div_cards) >= 2:
        print(f"   S5: {len(div_cards)} div+address")
        return div_cards[:60]

    # Strategy 6: article / section
    articles = soup.find_all(["article", "section"])
    if articles and len(articles) >= 1:
        print(f"   S6: {len(articles)} articles/sections")
        return articles

    # Strategy 7: table rows
    rows = soup.find_all("tr")
    if rows and len(rows) >= 2:
        print(f"   S7: {len(rows)} table rows")
        return rows[1:]

    # Strategy 8: any meaty links (last resort)
    skip_nav = {
        "pricing", "login", "signup", "sign up",
        "contact", "about", "home", "register",
        "terms", "privacy", "features", "blog",
        "help", "export", "data", "coverage",
    }
    meaty = []
    seen  = set()
    for a in soup.find_all("a", href=True):
        href = a.get("href", "")
        text = clean_text(a.get_text())
        if (
            5 < len(text) < 120
            and text.lower() not in skip_nav
            and not any(
                skip in href.lower()
                for skip in [
                    "javascript", "mailto", "#",
                    "twitter", "facebook", "linkedin",
                    "instagram", "login", "signup",
                    "pricing", "blog",
                ]
            )
        ):
            key = text.lower()
            if key not in seen:
                seen.add(key)
                meaty.append(a)
    if meaty and len(meaty) >= 3:
        print(f"   S8: {len(meaty)} meaty links")
        return meaty[:80]

    print("   ❌ No cards found with any strategy")
    return []


# ─────────────────────────────────────────────────────────
# Lead extractor
# ─────────────────────────────────────────────────────────

def extract_lead_from_element(
    el,
    source_url: str = "",
    city: str = "",
    country: str = "",
    location: str = "",
    industry: str = "",
) -> dict:
    lead = {
        "business_name": "",
        "phone":         "",
        "email":         "",
        "website":       "",
        "address":       "",
        "rating":        0.0,
        "reviews":       0,
        "has_instagram": 0,
        "has_facebook":  0,
        "has_twitter":   0,
        "source":        "b2bhint",
        "source_url":    source_url,
        "industry":      industry,
        "location":      location,
        "city":          city,
        "country":       country,
    }

    try:
        # ── <a> link element ─────────────────────────────
        if el.name == "a":
            text = clean_text(el.get_text())
            if not text or len(text) < 3 or len(text) > 150:
                return {}
            if is_nav_element(text):
                return {}
            lead["business_name"] = text
            href = el.get("href", "")
            if href:
                lead["source_url"] = (
                    BASE_URL + href
                    if href.startswith("/")
                    else href
                )
            return lead

        # ── Container element ─────────────────────────────
        full_text = el.get_text(" ", strip=True)

        # Name from headings
        for tag in ["h1", "h2", "h3", "h4", "strong", "b"]:
            name_el = el.find(tag)
            if name_el:
                name = clean_text(name_el.get_text())
                if (
                    name
                    and 3 <= len(name) <= 150
                    and not is_nav_element(name)
                ):
                    lead["business_name"] = name
                    break

        # Fallback: first meaty link
        if not lead["business_name"]:
            for a in el.find_all("a", href=True):
                href = a.get("href", "")
                t    = clean_text(a.get_text())
                if (
                    t
                    and 4 <= len(t) <= 120
                    and not is_nav_element(t)
                    and not any(
                        skip in href.lower()
                        for skip in [
                            "pricing", "login", "#",
                            "twitter", "facebook",
                            "javascript", "mailto",
                        ]
                    )
                ):
                    lead["business_name"] = t
                    break

        if not lead["business_name"]:
            return {}

        # Address
        addr_match = re.search(
            r'\d+\s+[A-Z][A-Z\s]+'
            r'(?:AVE|ST|BLVD|RD|DR|LN|WAY|CT|PL|PKWY|HWY'
            r'|STREET|AVENUE)'
            r'[A-Z\s,]*\d{5}',
            full_text, re.I
        )
        if addr_match:
            lead["address"] = addr_match.group(0).strip()

        # Phone
        for a in el.find_all("a", href=True):
            if a.get("href", "").startswith("tel:"):
                lead["phone"] = (
                    a["href"].replace("tel:", "").strip()
                )
                break

        # Email
        for a in el.find_all("a", href=True):
            if a.get("href", "").startswith("mailto:"):
                email = (
                    a["href"]
                    .replace("mailto:", "")
                    .split("?")[0].strip().lower()
                )
                if "@" in email:
                    lead["email"] = email
                    break

        # Website
        skip_domains = [
            "b2bhint", "google", "facebook",
            "instagram", "twitter", "linkedin",
            "whatsapp", "wa.me", "javascript", "#",
        ]
        for a in el.find_all("a", href=True):
            href = a.get("href", "")
            if (
                href.startswith("http")
                and not any(
                    x in href.lower() for x in skip_domains
                )
            ):
                lead["website"] = href
                break

        # Source URL
        for a in el.find_all("a", href=True):
            href = a.get("href", "")
            if href.startswith("/en/") or "/company/" in href:
                lead["source_url"] = (
                    BASE_URL + href
                    if href.startswith("/")
                    else href
                )
                break

        return lead

    except Exception as e:
        print(f"   Extract error: {e}")
        return {}


# ─────────────────────────────────────────────────────────
# Main scraper
# ─────────────────────────────────────────────────────────

def scrape_b2bhint(
    keyword: str,
    location: str = "Houston, United States",
    max_results: int = 50,
    max_pages: int = 5,
    force_restart: bool = False,
) -> list:
    """
    Main B2BHint scraper.

    Features:
    - Global jurisdiction (any country via UI)
    - Page tracking (continues from last scraped page)
    - Debug HTML dump when cards not found
    - Smart session management
    """
    leads = []
    seen  = set()

    parts   = [p.strip() for p in location.split(",")]
    city    = parts[0] if parts else location
    country = parts[-1].strip() if len(parts) > 1 else ""

    max_pages    = min(max_pages, 5)
    jurisdiction = detect_jurisdiction(location)

    # Page continuation
    if force_restart:
        reset_scrape_log(keyword, location)
        start_page = 1
        print("   🔄 Force restart — page 1")
    else:
        last_page  = get_last_scraped_page(keyword, location)
        start_page = last_page + 1
        if last_page > 0:
            print(
                f"   ⏩ Continuing from page {start_page} "
                f"(pages 1–{last_page} already scraped)"
            )

    urls = build_search_urls(
        keyword, location, max_pages, start_page
    )

    print(f"\n🔍 B2BHint: '{keyword}' | {location}")
    print(
        f"   Jurisdiction: "
        f"{jurisdiction if jurisdiction else 'global (none)'}"
    )
    print(
        f"   Pages: {start_page}–{start_page + len(urls) - 1}"
        f" | Target: {max_results}\n"
    )

    session = requests.Session()
    session.headers.update(get_headers())

    # Warm-up — establishes session cookie
    try:
        print("🌐 Connecting to B2BHint...")
        home = session.get(BASE_URL + "/en", timeout=20)
        if is_blocked(home):
            print("⚠️  Warm-up blocked — continuing anyway")
        else:
            print("✅ Connected")
        human_pause(2.0, 3.5)
    except Exception as e:
        print(f"⚠️  Connection warning: {e}")

    for page_idx, url in enumerate(urls):
        page_num = start_page + page_idx

        if len(leads) >= max_results:
            break

        print(f"\n📄 Page {page_num}: {url}")

        try:
            session.headers.update(get_headers())
            resp = session.get(url, timeout=30)

            print(
                f"   HTTP {resp.status_code} | "
                f"{len(resp.text):,} chars"
            )

            if is_blocked(resp):
                print("   🚫 Blocked — waiting 20s...")
                time.sleep(20)
                continue

            if resp.status_code != 200:
                print("   ⚠️  Bad status — skipping")
                continue

            soup  = BeautifulSoup(resp.text, "lxml")

            # Always debug on first page so we can
            # see exactly what B2BHint returns
            if page_idx == 0:
                print_html_debug(resp.text, soup)

            cards = find_listing_cards(soup)

            if not cards:
                print("   📭 No cards found — stopping")
                break

            page_new = 0

            for card in cards:
                if len(leads) >= max_results:
                    break

                lead = extract_lead_from_element(
                    card,
                    source_url=url,
                    city=city,
                    country=country,
                    location=location,
                    industry=keyword,
                )

                if not lead or not lead.get("business_name"):
                    continue

                key = lead["business_name"].lower().strip()
                if key in seen:
                    continue
                seen.add(key)

                leads.append(lead)
                page_new += 1

                print(
                    f"   ✅ {lead['business_name']}"
                    f" | {city}"
                    f" | {lead.get('address', '—')[:35]}"
                )

                human_pause(0.05, 0.15)

            log_scraped_page(keyword, location, page_num, page_new)
            print(f"   Page {page_num}: {page_new} new leads")

            if page_new == 0:
                print("   📭 No new leads this page")

            human_pause(3.0, 6.0)

        except Exception as e:
            print(f"   ❌ Page error: {e}")
            import traceback
            traceback.print_exc()
            continue

    print(
        f"\n✅ B2BHint done: {len(leads)} leads"
    )
    return leads[:max_results]


# ─────────────────────────────────────────────────────────
# Compatibility aliases
# ─────────────────────────────────────────────────────────

def extract_b2b_lead(card) -> dict:
    return extract_lead_from_element(card)


def extract_card_lead(card, source_url: str = "") -> dict:
    return extract_lead_from_element(card, source_url)


def find_detail_url(el) -> str:
    try:
        for a in el.find_all("a", href=True):
            href = a.get("href", "")
            if "/en/" in href or "/company/" in href:
                return (
                    BASE_URL + href
                    if href.startswith("/")
                    else href
                )
    except Exception:
        pass
    return ""


def scrape_b2bhint_company_page(url: str) -> dict:
    try:
        resp = requests.get(
            url, headers=get_headers(), timeout=15
        )
        if resp.status_code != 200:
            return {}
        soup  = BeautifulSoup(resp.text, "lxml")
        cards = find_listing_cards(soup)
        if cards:
            return extract_lead_from_element(
                cards[0], source_url=url
            )
        return {}
    except Exception:
        return {}
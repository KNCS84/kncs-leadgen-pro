# engine/companies_house_scraper.py
"""
Companies House UK API Scraper for KNCS LeadGen Pro.

Official UK government business registry.
4M+ active companies with official data.
FREE API - 600 requests per 5 minutes.
No blocking risk - official government API.
"""

import os
import time
import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY  = os.getenv("COMPANIES_HOUSE_API_KEY", "")
BASE_URL = "https://api.company-information.service.gov.uk"

# Rate limiting — safe for 600 req/5min limit
REQUEST_DELAY = 0.6


# ─────────────────────────────────────────────────────────
# API helpers
# ─────────────────────────────────────────────────────────

def _get(url: str, params: dict = None) -> dict:
    """
    Make a safe authenticated API request.
    Handles rate limits and errors gracefully.
    """
    if not API_KEY:
        print("❌ COMPANIES_HOUSE_API_KEY not found in .env")
        return {}

    try:
        time.sleep(REQUEST_DELAY)

        resp = requests.get(
            url,
            auth=(API_KEY, ""),
            params=params or {},
            timeout=30,
        )

        if resp.status_code == 200:
            return resp.json()

        elif resp.status_code == 429:
            print("⚠️ Rate limit hit — waiting 60 seconds...")
            time.sleep(60)
            return _get(url, params)

        elif resp.status_code == 401:
            print("❌ Invalid API key — check .env file")
            return {}

        else:
            print(f"⚠️ API status {resp.status_code}")
            return {}

    except requests.exceptions.Timeout:
        print("⚠️ Request timed out")
        return {}

    except Exception as e:
        print(f"⚠️ Request error: {e}")
        return {}


# ─────────────────────────────────────────────────────────
# Search
# ─────────────────────────────────────────────────────────

def search_companies(
    keyword: str,
    location: str = "",
    max_results: int = 20,
    active_only: bool = True,
) -> list:
    """
    Search Companies House for companies.

    Args:
        keyword:     Business type e.g. 'restaurant', 'dental'
        location:    City e.g. 'London' or 'London, United Kingdom'
        max_results: Max companies to return
        active_only: Only return active companies (recommended)

    Returns:
        List of raw company dicts from API
    """
    # Build search query — include city for better targeting
    city = location.split(",")[0].strip() if location else ""
    query = f"{keyword} {city}".strip() if city else keyword

    print(f"🔍 Searching: '{query}' | Target: {max_results}")

    all_items  = []
    page_size  = 20
    start      = 0

    while len(all_items) < max_results:
        data = _get(
            f"{BASE_URL}/search/companies",
            params={
                "q":              query,
                "items_per_page": page_size,
                "start_index":    start,
            },
        )

        if not data:
            break

        items = data.get("items", [])

        if not items:
            break

        # Filter active only
        if active_only:
            items = [
                c for c in items
                if c.get("company_status", "").lower() == "active"
            ]

        all_items.extend(items)

        total_available = data.get("total_results", 0)
        start          += page_size

        print(f"  📄 Fetched {len(all_items)} active companies so far...")

        # Stop if we've gone through all available results
        if start >= total_available:
            break

    print(f"  ✅ Total found: {len(all_items[:max_results])}")
    return all_items[:max_results]


# ─────────────────────────────────────────────────────────
# Company details
# ─────────────────────────────────────────────────────────

def get_company_profile(company_number: str) -> dict:
    """
    Get full company profile including registered address.
    """
    return _get(f"{BASE_URL}/company/{company_number}")


def get_company_officers(company_number: str) -> list:
    """
    Get company directors and officers.
    Useful for personalising call scripts.
    """
    data = _get(
        f"{BASE_URL}/company/{company_number}/officers"
    )
    return data.get("items", []) if data else []


# ─────────────────────────────────────────────────────────
# Address formatting
# ─────────────────────────────────────────────────────────

def _format_address(addr: dict) -> str:
    """Format Companies House address dict into string."""
    if not addr:
        return ""

    parts = [
        addr.get("premises",       ""),
        addr.get("address_line_1", ""),
        addr.get("address_line_2", ""),
        addr.get("locality",       ""),
        addr.get("region",         ""),
        addr.get("postal_code",    ""),
    ]

    return ", ".join(p for p in parts if p).strip()


def _extract_city(addr: dict) -> str:
    """Extract best city name from address."""
    return (
        addr.get("locality", "")
        or addr.get("region", "")
        or ""
    )


# ─────────────────────────────────────────────────────────
# Lead conversion
# ─────────────────────────────────────────────────────────

def _company_to_lead(
    company:  dict,
    profile:  dict = None,
    officers: list = None,
    keyword:  str  = "",
) -> dict:
    """
    Convert Companies House company data to lead format.
    """
    data = profile if profile else company

    # Address
    addr_obj = data.get("registered_office_address", {})
    address  = _format_address(addr_obj)
    city     = _extract_city(addr_obj)
    postcode = addr_obj.get("postal_code", "")

    # Company info
    name    = (
        data.get("title")
        or data.get("company_name", "Unknown")
    ).title()

    number  = data.get("company_number", "")
    status  = data.get("company_status", "active")
    c_type  = data.get("type", "")
    created = data.get("date_of_creation", "")

    # SIC codes → industry
    sic_codes = data.get("sic_codes", [])
    industry  = keyword if keyword else (
        sic_codes[0] if sic_codes else "unknown"
    )

    # Officers → director names for call script
    director_note = ""
    if officers:
        directors = [
            o.get("name", "").title()
            for o in officers
            if o.get("officer_role", "") == "director"
            and not o.get("resigned_on")  # Only active directors
        ]
        if directors:
            director_note = f"Directors: {', '.join(directors[:3])}"

    # Opportunity score
    # Active + has address + has company number = higher score
    base_score = 40
    if status == "active":
        base_score += 15
    if address:
        base_score += 10
    if postcode:
        base_score += 10
    if director_note:
        base_score += 10
    if created and int(created[:4]) >= 2015:
        base_score += 5   # Newer companies more likely to need services

    return {
        # Core lead fields
        "business_name":      name,
        "phone":              None,
        "email":              None,
        "website":            None,
        "address":            address,
        "city":               city,
        "location":           f"{city}, United Kingdom" if city else "United Kingdom",
        "country":            "United Kingdom",
        "postcode":           postcode,

        # Scores
        "rating":             0,
        "reviews":            0,
        "opportunity_score":  min(base_score, 85),
        "contact_score":      0,

        # Flags
        "has_website":        0,
        "website_active":     0,
        "has_instagram":      0,
        "has_facebook":       0,
        "has_twitter":        0,

        # Classification
        "industry":           industry,
        "source":             "companies_house",
        "source_url":         f"https://find-and-update.company-information.service.gov.uk/company/{number}",
        "contact_status":     "new",

        # Companies House specific
        "company_number":     number,
        "company_status":     status,
        "company_type":       c_type,
        "incorporation_date": created,

        # Notes
        "notes":              director_note,
        "enrichment_status":  "pending",
        "enrichment_notes":   "Needs phone, email and website enrichment",
    }


# ─────────────────────────────────────────────────────────
# Main scraper
# ─────────────────────────────────────────────────────────

def scrape_companies_house(
    keyword:         str,
    location:        str  = "United Kingdom",
    max_results:     int  = 20,
    get_details:     bool = True,
    get_officers:    bool = True,
    active_only:     bool = True,
) -> list:
    """
    Main Companies House scraper function.

    Args:
        keyword:      Business type e.g. 'restaurant', 'dental clinic'
        location:     City, UK e.g. 'London, United Kingdom'
        max_results:  Max leads to return
        get_details:  Fetch full company profile (better data)
        get_officers: Fetch directors (for call script personalization)
        active_only:  Only return active companies

    Returns:
        List of lead dicts ready for database insertion
    """
    from engine.scrape_guard import log_request

    if not API_KEY:
        print("❌ Companies House API key not configured")
        print("   Add COMPANIES_HOUSE_API_KEY to .env file")
        print("   Get free key: https://developer.company-information.service.gov.uk/")
        return []

    print(f"\n{'='*60}")
    print(f"🇬🇧  COMPANIES HOUSE UK SCRAPER")
    print(f"{'='*60}")
    print(f"  Keyword:     {keyword}")
    print(f"  Location:    {location}")
    print(f"  Target:      {max_results} companies")
    print(f"  Active only: {active_only}")
    print(f"{'='*60}\n")

    # Step 1: Search
    companies = search_companies(
        keyword=keyword,
        location=location,
        max_results=max_results,
        active_only=active_only,
    )

    if not companies:
        print("⚠️ No companies found")
        log_request("companies_house", keyword, location, 0)
        return []

    print(f"\n📋 Processing {len(companies)} companies...")

    leads = []

    for i, company in enumerate(companies, 1):
        try:
            number = company.get("company_number", "")
            name   = (
                company.get("title")
                or company.get("company_name", "Unknown")
            ).title()

            print(f"\n  [{i}/{len(companies)}] {name}")

            # Get full profile
            profile = None
            if get_details and number:
                profile = get_company_profile(number)
                if profile:
                    print(f"    ✅ Profile fetched")

            # Get officers
            officers = []
            if get_officers and number:
                officers = get_company_officers(number)
                active_directors = [
                    o for o in officers
                    if o.get("officer_role") == "director"
                    and not o.get("resigned_on")
                ]
                if active_directors:
                    names = [
                        o.get("name", "").title()
                        for o in active_directors[:3]
                    ]
                    print(f"    👔 Directors: {', '.join(names)}")

            # Convert to lead
            lead = _company_to_lead(
                company=company,
                profile=profile,
                officers=officers,
                keyword=keyword,
            )

            leads.append(lead)

            addr_display = lead.get("address", "No address")[:60]
            print(f"    📍 {addr_display}")
            print(f"    ⭐ Score: {lead.get('opportunity_score', 0)}")

        except Exception as e:
            print(f"    ⚠️ Error: {e}")
            continue

    # Log to scrape guard
    log_request("companies_house", keyword, location, len(leads))

    print(f"\n{'='*60}")
    print(f"✅ COMPLETE: {len(leads)} leads ready")
    print(f"{'='*60}\n")

    return leads